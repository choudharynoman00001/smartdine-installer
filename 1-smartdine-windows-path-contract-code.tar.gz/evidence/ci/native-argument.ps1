function QuoteNativeArgument([string]$value){
 # Windows/.NET command-line contract: double backslashes before closing quote.
 return '"'+[regex]::Replace($value,'(\\+)$','$1$1')+'"'
}
