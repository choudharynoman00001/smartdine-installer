import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';import crypto from 'node:crypto';import {DatabaseSync} from 'node:sqlite';
const [phase,root,stateFile]=process.argv.slice(2),base='http://127.0.0.1:'+(process.env.SD_EVIDENCE_PORT||'8080'),pin='69834127';
let token;const call=async(p,body,method=body?'POST':'GET',expected=200)=>{const r=await fetch(base+p,{method,headers:{'content-type':'application/json',...(token?{authorization:'Bearer '+token}:{})},body:body===undefined?undefined:JSON.stringify(body),signal:AbortSignal.timeout(5000)});assert.equal(r.status,expected,p);return r.json();};
const dbfile=path.join(root,'app','data','smartdine.db');
const login=async()=>{token=(await call('/api/auth/login',{pin})).token;assert.ok(token);};
if(phase==='seed'){
 assert.equal((await call('/api/setup')).setup_required,true);token=(await call('/api/setup',{name:'Synthetic Windows owner',pin},'POST',201)).token;
 const category=(await call('/api/menu/categories',{name_en:'Old meals'},'POST',201)).category.id;
 const item=(await call('/api/menu/items',{name_en:'Old item',category_id:category,price:450},'POST',201)).item.id;
 const order=(await call('/api/orders',{items:[{menu_item_id:item,qty:1}]},'POST',201)).order;
 assert.ok(fs.existsSync(dbfile));assert.ok(!fs.existsSync(path.join(root,'app','runtime-app','data')));
 fs.writeFileSync(stateFile,JSON.stringify({orderId:order.id,name:'Old item',total:order.total,itemId:item},null,2));console.log('PASS legacy default DB path, PIN, menu and order seed');
}else if(phase==='fresh'){
 assert.equal((await call('/api/setup')).setup_required,true);token=(await call('/api/setup',{name:'Fresh synthetic owner',pin},'POST',201)).token;assert.ok(token);assert.ok(fs.existsSync(dbfile));assert.ok(!fs.existsSync(path.join(root,'app','runtime-app','data')));console.log('PASS fresh current setup correct DB and no alternate');
}else if(phase==='verify'||phase==='reinstall'){
 const state=JSON.parse(fs.readFileSync(stateFile));await login();assert.equal((await call('/api/setup')).setup_required,false);
 const order=(await call('/api/orders/'+state.orderId)).order;assert.equal(order.total,state.total);assert.equal(order.items[0].name_snapshot,state.name);
 const settings=(await call('/api/settings')).settings;assert.ok(settings.database_id);assert.ok(!fs.existsSync(path.join(root,'app','runtime-app','data')));
 if(phase==='verify'){
  await call('/api/orders/'+state.orderId+'/payments',{amount:100,method:'cash'},'POST',400);
  const key=crypto.randomUUID(),payment={amount:100,method:'cash',idempotency_key:key,database_id:settings.database_id};
  await call('/api/orders/'+state.orderId+'/payments',payment,'POST',201);const replay=await call('/api/orders/'+state.orderId+'/payments',payment);assert.equal(replay.deduped,true);
  const u=(await call('/api/users',{name:'Synthetic staff',role:'waiter',pin:'74612381'},'POST',201)).user;
  const id=crypto.randomUUID(),shift={id,user_id:u.id,starts_at:1000,ends_at:2000,status:'planned',note:'Windows synthetic'};
  await call('/api/staff-shifts',shift,'POST',201);await call('/api/staff-shifts',{...shift,id:id.toUpperCase()},'POST',400);
  await call('/api/users/'+u.id+'/active',{active:false},'PUT');await call('/api/staff-shifts/'+id,{...shift,version:1,status:'cancelled'},'PUT');
  await call('/api/settings',{default_language:'ur'},'PUT');assert.deepEqual(await call('/api/language'),{default_language:'ur'});await call('/api/settings',{default_language:'en'},'PUT');
  const backup=await fetch(base+'/api/backup',{headers:{authorization:'Bearer '+token},signal:AbortSignal.timeout(10000)});assert.equal(backup.status,200);const backupPath=path.join(root,'app','data','ci-snapshot.db');fs.writeFileSync(backupPath,Buffer.from(await backup.arrayBuffer()));const d=new DatabaseSync(backupPath,{readOnly:true});try{assert.equal(d.prepare('SELECT count(*) n FROM local_payment_intents WHERE idempotency_key=?').get(key).n,1);assert.equal(d.prepare('SELECT status FROM local_staff_shifts WHERE id=?').get(id).status,'cancelled');}finally{d.close();}
  state.databaseId=settings.database_id;state.shiftId=id;state.paymentKey=key;fs.writeFileSync(stateFile,JSON.stringify(state,null,2));
 }else{assert.equal(settings.database_id,state.databaseId);const shift=(await call('/api/staff-shifts')).shifts.find(s=>s.id===state.shiftId);assert.equal(shift.status,'cancelled');const p=order.payments.filter(p=>p.amount===100);assert.equal(p.length,1);}
 console.log('PASS '+phase+' legacy order/snapshot/PIN, current identity'+(phase==='verify'?', payment replay guards, inactive shift closure and backup contents':''));
}else if(phase==='checkpoint'){
 const d=new DatabaseSync(dbfile);try{const r=d.prepare('PRAGMA wal_checkpoint(TRUNCATE)').get();assert.equal(r.busy,0);}finally{d.close();}console.log('PASS stopped DB checkpoint');
}else throw Error('unknown phase');
