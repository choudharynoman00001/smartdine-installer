import test from 'node:test';import assert from 'node:assert/strict';
// Windows/.NET documented quote/backslash rule, no operating-system execution claim.
function quote(s){return '"'+s.replace(/(\\+)$/,'$1$1')+'"';}
function parse(s){let out='',quoted=false;for(let i=0;i<s.length;){if(s[i]==='\\'){let j=i;while(s[j]==='\\')j++;if(s[j]==='"'){out+='\\'.repeat(Math.floor((j-i)/2));if((j-i)%2)out+='"';else quoted=!quoted;i=j+1;}else{out+=s.slice(i,j);i=j;}}else if(s[i]==='"'){quoted=!quoted;i++;}else{if(!quoted&&/\s/.test(s[i]))break;out+=s[i++];}}return out;}
const paths=['C:\\','C:\\SmartDine;bad','\\\\localhost\\share\\SmartDine','C:\\SmartDine bad ','C:\\SmartDine bad \\','C:\\SmartDine bad \\child','C:\\SmartDine Test','C:\\SmartDine Test\\','C:\\SmartDine Test\\\\'];
test('literal bytes retained by quote contract including terminal slash and space',()=>{for(const p of paths)assert.equal(parse(quote(p)),p);});
test('old single trailing backslash consumes delimiter, produces literal quote',()=>{assert.equal(parse('"C:\\"'),'C:"');assert.notEqual(parse('"C:\\"'),'C:\\');});
test('raw validation rejects root, UNC, punctuation, terminal separator and space-ended segments',()=>{function allowed(p){return /^[A-Za-z]:\\[A-Za-z0-9 _-]+(?:\\[A-Za-z0-9 _-]+)*$/.test(p)&&!p.split('\\').some(s=>s.endsWith(' '));}for(const p of paths.slice(0,6))assert.equal(allowed(p),false,p);assert.equal(allowed('C:\\SmartDine Test'),true);assert.equal(allowed('C:\\SmartDine Test\\'),false);});
