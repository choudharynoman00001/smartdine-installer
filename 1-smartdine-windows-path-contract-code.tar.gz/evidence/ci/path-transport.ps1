# Native read-only argv proof, under Windows PowerShell, no install paths created.
$ErrorActionPreference='Stop'
. "$PSScriptRoot\native-argument.ps1"
$private=Join-Path $env:RUNNER_TEMP 'smartdine-argv-probe'
New-Item -ItemType Directory -Force $private|Out-Null
$echo=Join-Path $private 'echo.ps1'
@'
param([Parameter(Mandatory)][string]$InstallDir)
[Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($InstallDir))
'@|Set-Content $echo
$paths=@('C:\','C:\SmartDine;bad','\\localhost\share\SmartDine','C:\SmartDine bad ','C:\SmartDine bad \','C:\SmartDine bad \child','C:\SmartDine Test','C:\SmartDine Test\','C:\SmartDine Test\\')
try{
 foreach($path in $paths){
  $out=Join-Path $private 'out.txt';$err=Join-Path $private 'err.txt'
  $p=Start-Process powershell.exe -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$echo`" -InstallDir $(QuoteNativeArgument $path)" -PassThru -RedirectStandardOutput $out -RedirectStandardError $err
  try{if(!$p.WaitForExit(10000)){& taskkill.exe /PID $p.Id /T /F|Out-Null;throw 'argv probe deadline'};$p.Refresh();if($p.ExitCode -ne 0){throw 'argv child failure'};$actual=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String((Get-Content $out -Raw).Trim()));if($actual -cne $path){throw 'literal argument byte mismatch'}}finally{$p.Dispose()}
 }
 Write-Output 'PASS native harness Windows PowerShell literal argv9cases including terminal slashes and spaces'
}finally{Remove-Item -LiteralPath $private -Recurse -Force}
