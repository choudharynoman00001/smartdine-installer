param([Parameter(Mandatory)][string]$InstallDir)
[Console]::Write('<'+$InstallDir+'>')
