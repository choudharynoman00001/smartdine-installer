# CI-only child supervisor. Never use on customer installations.
function Invoke-BoundedProcess {
  param([Parameter(Mandatory)][string]$FilePath,[string]$Arguments='',[int]$Seconds=90,[Parameter(Mandatory)][string]$Label)
  if ($Seconds -lt 1 -or $Seconds -gt 180) { throw 'invalid process deadline' }
  if ($Label -notmatch '^[a-z0-9-]+$') { throw 'invalid evidence label' }
  $evidence = Join-Path $env:RUNNER_TEMP 'smartdine-ci-evidence'
  New-Item -ItemType Directory -Force $evidence | Out-Null
  $stdout=Join-Path $evidence "$Label.stdout.log"
  $stderr=Join-Path $evidence "$Label.stderr.log"
  $p=Start-Process -FilePath $FilePath -ArgumentList $Arguments -PassThru -RedirectStandardOutput $stdout -RedirectStandardError $stderr
  try {
    Write-Host "START $Label pid=$($p.Id) deadline=$Seconds"
    if (-not $p.WaitForExit($Seconds*1000)) {
      "TIMEOUT $Label pid=$($p.Id)" | Add-Content (Join-Path $evidence 'checkpoints.log')
      # Only the child tree this helper launched, never all node/browser processes.
      & taskkill.exe /PID $p.Id /T /F 2>&1 | Out-Null
      throw "bounded process timed out: $Label"
    }
    $p.Refresh()
    "EXIT $Label code=$($p.ExitCode)" | Add-Content (Join-Path $evidence 'checkpoints.log')
    if ($p.ExitCode -ne 0) { throw "bounded process failed: $Label exit=$($p.ExitCode)" }
  } finally { $p.Dispose() }
}
