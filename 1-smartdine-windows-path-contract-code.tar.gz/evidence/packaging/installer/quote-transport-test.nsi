; Compile/run independently, no production installation. Uses exact shipped helper.
Name "SmartDine literal argv test"
OutFile "quote-transport-test.exe"
RequestExecutionLevel user
SilentInstall silent
!include "quote-install-dir.nsh"
Section
 InitPluginsDir
 File /oname=echo.ps1 "quote-echo.ps1"
 StrCpy $INSTDIR "C:\"
 Call CheckLiteral
 StrCpy $INSTDIR "C:\SmartDine Test"
 Call CheckLiteral
 StrCpy $INSTDIR "C:\SmartDine Test\"
 Call CheckLiteral
 StrCpy $INSTDIR "C:\SmartDine bad "
 Call CheckLiteral
 StrCpy $INSTDIR "C:\SmartDine bad \"
 Call CheckLiteral
 StrCpy $INSTDIR "C:\SmartDine bad \child"
 Call CheckLiteral
 StrCpy $INSTDIR "C:\SmartDine;bad"
 Call CheckLiteral
 StrCpy $INSTDIR "\\localhost\share\SmartDine"
 Call CheckLiteral
 SetErrorLevel 0
SectionEnd
Function CheckLiteral
 Call QuoteInstallDir
 nsExec::ExecToStack '"$SYSDIR\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "$PLUGINSDIR\echo.ps1" -InstallDir $2'
 Pop $0
 Pop $1
 StrCmp $0 "0" 0 fail
 ; Delimit path inside markers so stdout trimming cannot hide terminal spaces.
 StrCpy $6 "<$INSTDIR>"
 StrCmp $1 $6 done
 fail:
 SetErrorLevel 1
 Quit
 done:
FunctionEnd
