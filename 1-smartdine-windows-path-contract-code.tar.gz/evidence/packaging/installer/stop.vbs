' Stop only this installation's exact Node executable and quoted entrypoint.
Option Explicit
Dim fso, base, svc, procs, p, killed, exe, entry
Set fso = CreateObject("Scripting.FileSystemObject")
base = fso.GetParentFolderName(WScript.ScriptFullName)
exe = LCase(base & "\node\node.exe")
entry = Chr(34) & LCase(base & "\app\runtime-app\launch.mjs") & Chr(34)
killed = False
Set svc = GetObject("winmgmts:root\cimv2")
Set procs = svc.ExecQuery("SELECT ProcessId, ExecutablePath, CommandLine FROM Win32_Process WHERE Name='node.exe'")
For Each p In procs
  If Not IsNull(p.ExecutablePath) And Not IsNull(p.CommandLine) Then
    If LCase(p.ExecutablePath) = exe And InStr(LCase(p.CommandLine), entry) > 0 Then
      p.Terminate()
      killed = True
    End If
  End If
Next
If WScript.Arguments.Named.Exists("quiet") Then WScript.Quit 0
If killed Then
  WScript.Echo "SmartDine server stopped."
Else
  WScript.Echo "This installation's server is not running."
End If
