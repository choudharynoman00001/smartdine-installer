; Preparation only. No build or dispatch performed.
!include "MUI2.nsh"
Name "SmartDine POS"
OutFile "SmartDinePOS-Setup.exe"
InstallDir "$LOCALAPPDATA\SmartDine"
RequestExecutionLevel user
!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_DIRECTORY
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_PAGE_FINISH
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES
!insertmacro MUI_LANGUAGE "English"
!include "quote-install-dir.nsh"
Section "Install"
  InitPluginsDir
  SetOutPath "$PLUGINSDIR"
  File "preflight.ps1"
  Call QuoteInstallDir
  nsExec::ExecToStack '"$SYSDIR\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "$PLUGINSDIR\preflight.ps1" -InstallDir $2'
  Pop $0
  Pop $1
  StrCmp $0 "0" preflight_ok
  MessageBox MB_OK "Upgrade preflight failed. Stop this installation and reconcile alternate databases before retrying. No payload files were copied." /SD IDOK
  SetErrorLevel 1
  Abort
  preflight_ok:
  ; Preflight refuses target Node processes; it never terminates them.
  ; Candidate payload contains no app/data, so existing DB is not overwritten.
  SetOutPath "$INSTDIR"
  File /r "stage\*"
  File "launcher.vbs"
  File "stop.vbs"
  File "preflight.ps1"
  CreateDirectory "$INSTDIR\app\data"
  CreateDirectory "$SMPROGRAMS\SmartDine"
  CreateShortcut "$SMPROGRAMS\SmartDine\SmartDine POS.lnk" "$SYSDIR\wscript.exe" '"$INSTDIR\launcher.vbs"' "$INSTDIR\node\node.exe" 0
  CreateShortcut "$DESKTOP\SmartDine POS.lnk" "$SYSDIR\wscript.exe" '"$INSTDIR\launcher.vbs"' "$INSTDIR\node\node.exe" 0
  CreateShortcut "$SMPROGRAMS\SmartDine\Stop SmartDine.lnk" "$SYSDIR\wscript.exe" '"$INSTDIR\stop.vbs"' "$INSTDIR\node\node.exe" 0
  ; Disable old launch paths after the new payload is installed, not data files.
  Delete "$INSTDIR\SmartDine.bat"
  Delete "$INSTDIR\app\server.mjs"
  WriteUninstaller "$INSTDIR\Uninstall.exe"
SectionEnd
Section "Uninstall"
  Call un.QuoteInstallDir
  nsExec::ExecToStack '"$SYSDIR\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "$INSTDIR\preflight.ps1" -InstallDir $2 -Uninstall'
  Pop $0
  Pop $1
  StrCmp $0 "0" uninstall_preflight_ok
  MessageBox MB_OK "Uninstall refused: stop this installation and preserve or reconcile alternate data first. No files removed." /SD IDOK
  SetErrorLevel 1
  Abort
  uninstall_preflight_ok:
  Delete "$SMPROGRAMS\SmartDine\SmartDine POS.lnk"
  Delete "$SMPROGRAMS\SmartDine\Stop SmartDine.lnk"
  RMDir "$SMPROGRAMS\SmartDine"
  Delete "$DESKTOP\SmartDine POS.lnk"
  ; Preserve restaurant DB, backups, browser profile and logs by default.
  RMDir /r "$INSTDIR\node"
  RMDir /r "$INSTDIR\app\runtime-app"
  RMDir /r "$INSTDIR\app\lib"
  Delete "$INSTDIR\app\*.mjs"
  Delete "$INSTDIR\app\package.json"
  Delete "$INSTDIR\launcher.vbs"
  Delete "$INSTDIR\stop.vbs"
  Delete "$INSTDIR\preflight.ps1"
  ; Preserve owned layout marker so retained-data reinstall remains recognized.
  Delete "$INSTDIR\Uninstall.exe"
SectionEnd
