' SmartDine POS launcher - starts the local server if needed and opens the app.
' Opens a dedicated app window via Edge/Chrome --app mode when a Chromium browser is
' installed (browser-engine app window, not a native app); falls back to the default
' browser window otherwise. SMARTDINE_NO_BROWSER=1: automation mode, opens nothing.
' SMARTDINE_LAUNCH_LOG_ONLY=1: records the chosen launch command to
' app\data\last-launch.txt and opens nothing (CI proof of the selection logic).
Option Explicit
Dim sh, base, url, ok, i, fso, env
Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
base = fso.GetParentFolderName(WScript.ScriptFullName)
Set env = sh.Environment("PROCESS")
env("SMARTDINE_DB") = base & "\app\data\smartdine.db"
env("SMARTDINE_HOST") = "127.0.0.1"
env("PORT") = "8080"
url = "http://127.0.0.1:8080/"
ok = False
For i = 1 To 40
  If HealthOk(url) Then
    If Not OwnedServer(base) Then
      WScript.Echo "Port 8080 belongs to another process or install. Stop that server first."
      WScript.Quit 1
    End If
    ok = True : Exit For
  End If
  If i = 1 Then StartServer base
  WScript.Sleep 1000
Next
If ok Then
  If sh.ExpandEnvironmentStrings("%SMARTDINE_NO_BROWSER%") = "1" And sh.ExpandEnvironmentStrings("%SMARTDINE_LAUNCH_LOG_ONLY%") <> "1" Then
    ' automation mode: never open a window
  Else
    OpenApp url
  End If
Else
  If sh.ExpandEnvironmentStrings("%SMARTDINE_NO_BROWSER%") = "1" Then
    WScript.Echo "SmartDine server failed to start within wait window (automation mode, no dialog)"
    WScript.Quit 1
  Else
    MsgBox "SmartDine abhi start nahi ho saka. Dobara koshish karein; agar masla rahe to Alpha Blue Digital se rabta karein.", 48, "SmartDine POS"
  End If
End If

Function HealthOk(u)
  Dim http
  On Error Resume Next
  Set http = CreateObject("MSXML2.ServerXMLHTTP.6.0")
  http.Open "GET", u & "api/health", False
  http.setTimeouts 2000, 2000, 2000, 2000
  http.Send
  HealthOk = (Err.Number = 0 And http.Status = 200)
  Err.Clear
  On Error GoTo 0
End Function

Sub StartServer(b)
  Dim fso, cmd
  Set fso = CreateObject("Scripting.FileSystemObject")
  If Not fso.FolderExists(b & "\app\data") Then fso.CreateFolder(b & "\app\data")
  cmd = "cmd /c cd /d """ & b & "\app"" && """ & b & "\node\node.exe"" """ & b & "\app\runtime-app\launch.mjs"" > """ & b & "\app\data\server.log"" 2>&1"
  sh.Run cmd, 0, False
End Sub

Function OwnedServer(b)
  Dim svc, procs, p, expectedExe, expectedScript
  OwnedServer = False
  expectedExe = LCase(b & "\node\node.exe")
  expectedScript = Chr(34) & LCase(b & "\app\runtime-app\launch.mjs") & Chr(34)
  Set svc = GetObject("winmgmts:root\cimv2")
  Set procs = svc.ExecQuery("SELECT ExecutablePath, CommandLine FROM Win32_Process WHERE Name='node.exe'")
  For Each p In procs
    If Not IsNull(p.ExecutablePath) And Not IsNull(p.CommandLine) Then
      If LCase(p.ExecutablePath) = expectedExe And InStr(LCase(p.CommandLine), expectedScript) > 0 Then OwnedServer = True
    End If
  Next
End Function

Sub OpenApp(u)
  Dim b, cmdLine, mode
  b = FindChromium()
  If b <> "" Then
    Dim profile
    profile = sh.ExpandEnvironmentStrings("%SMARTDINE_APP_PROFILE%")
    If profile = "%SMARTDINE_APP_PROFILE%" Or profile = "" Then profile = base & "\browser-profile"
    cmdLine = """" & b & """ --app=" & u & " --user-data-dir=""" & profile & """ --no-first-run --no-default-browser-check"
    mode = "app-window (Chromium --app; browser engine, no tabs/address bar)"
  Else
    cmdLine = "explorer.exe """ & u & """"
    mode = "fallback default-browser window (no Edge/Chrome found)"
  End If
  LogLaunch mode & " :: " & cmdLine
  If sh.ExpandEnvironmentStrings("%SMARTDINE_LAUNCH_LOG_ONLY%") = "1" Then Exit Sub
  sh.Run cmdLine, 1, False
End Sub

Function FindChromium()
  Dim fso, p
  Set fso = CreateObject("Scripting.FileSystemObject")
  For Each p In Array( _
    sh.ExpandEnvironmentStrings("%ProgramFiles(x86)%") & "\Microsoft\Edge\Application\msedge.exe", _
    sh.ExpandEnvironmentStrings("%ProgramFiles%") & "\Microsoft\Edge\Application\msedge.exe", _
    sh.ExpandEnvironmentStrings("%ProgramFiles%") & "\Google\Chrome\Application\chrome.exe", _
    sh.ExpandEnvironmentStrings("%ProgramFiles(x86)%") & "\Google\Chrome\Application\chrome.exe", _
    sh.ExpandEnvironmentStrings("%LOCALAPPDATA%") & "\Google\Chrome\Application\chrome.exe")
    If fso.FileExists(p) Then FindChromium = p : Exit Function
  Next
  FindChromium = ""
End Function

Sub LogLaunch(m)
  On Error Resume Next
  Dim fso, f
  Set fso = CreateObject("Scripting.FileSystemObject")
  If Not fso.FolderExists(base & "\app\data") Then fso.CreateFolder(base & "\app\data")
  Set f = fso.OpenTextFile(base & "\app\data\last-launch.txt", 8, True)
  f.WriteLine Now & " " & m
  f.Close
  On Error GoTo 0
End Sub
