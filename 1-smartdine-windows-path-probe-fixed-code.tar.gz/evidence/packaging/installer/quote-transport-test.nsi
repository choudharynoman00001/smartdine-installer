; Compile/run independently, no production installation. Uses exact shipped helper.
Name "SmartDine literal argv test"
OutFile "quote-transport-test.exe"
RequestExecutionLevel user
SilentInstall silent
!include "quote-install-dir.nsh"
Section
 InitPluginsDir
 SetOutPath "$PLUGINSDIR"
 ReadEnvStr $9 "RUNNER_TEMP"
 FileOpen $9 "$9\smartdine-ci-evidence\nsis-argv-status.txt" w
 StrCpy $R0 0
 File /oname=echo.ps1 "quote-echo.ps1"
 StrCpy $8 "C:\"
 StrCpy $INSTDIR $8
 Call CheckLiteral
 StrCpy $8 "C:\SmartDine Test"
 StrCpy $INSTDIR $8
 Call CheckLiteral
 StrCpy $8 "C:\SmartDine Test\"
 StrCpy $INSTDIR $8
 Call CheckLiteral
 StrCpy $8 "C:\SmartDine bad "
 StrCpy $INSTDIR $8
 Call CheckLiteral
 StrCpy $8 "C:\SmartDine bad \"
 StrCpy $INSTDIR $8
 Call CheckLiteral
 StrCpy $8 "C:\SmartDine bad \child"
 StrCpy $INSTDIR $8
 Call CheckLiteral
 StrCpy $8 "C:\SmartDine;bad"
 StrCpy $INSTDIR $8
 Call CheckLiteral
 StrCpy $8 "\\localhost\share\SmartDine"
 StrCpy $INSTDIR $8
 Call CheckLiteral
 FileClose $9
 SetErrorLevel 0
SectionEnd
Function CheckLiteral
 IntOp $R0 $R0 + 1
 ; Snapshot effective special-path variable before invoking helper/plugin.
 StrCpy $7 $INSTDIR
 StrCpy $R1 0
 StrCmp $7 $8 0 +2
 StrCpy $R1 1
 FileWrite $9 "case=$R0 rawEqualsEffective=$R1$\r$\n"
 IfFileExists "$PLUGINSDIR\echo.ps1" script_ok script_missing
 script_missing:
 FileWrite $9 "case=$R0 scriptExists=0$\r$\n"
 Goto fail
 script_ok:
 FileWrite $9 "case=$R0 scriptExists=1$\r$\n"
 Call QuoteInstallDir
 nsExec::ExecToStack '"$SYSDIR\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "$PLUGINSDIR\echo.ps1" -InstallDir $2'
 Pop $0
 Pop $1
 StrCmp $0 "0" child_ok child_failed
 child_failed:
 FileWrite $9 "case=$R0 childExitZero=0 compareEffective=unverified$\r$\n"
 Goto fail
 child_ok:
 FileWrite $9 "case=$R0 childExitZero=1$\r$\n"
 ; Delimit path inside markers so stdout trimming cannot hide terminal spaces.
 StrCpy $6 "<$7>"
 StrCmp $1 $6 match
 FileWrite $9 "case=$R0 compareEffective=0$\r$\n"
 Goto fail
 match:
 FileWrite $9 "case=$R0 compareEffective=1$\r$\n"
 Goto done
 fail:
 FileClose $9
 SetErrorLevel 1
 Quit
 done:
FunctionEnd
