# Synthetic ephemeral CI only. Refuses existing default/custom installations.
param([Parameter(Mandatory)][string]$Candidate,[Parameter(Mandatory)][string]$Legacy)
$ErrorActionPreference='Stop'
if($env:GITHUB_ACTIONS -ne 'true' -or $env:RUNNER_OS -ne 'Windows'){throw 'disposable Windows Actions only'}
$ev=Join-Path $env:RUNNER_TEMP 'smartdine-ci-evidence'
New-Item -ItemType Directory -Force $ev | Out-Null
Start-Transcript -Path (Join-Path $ev 'accept-transcript.txt')
. "$PSScriptRoot\..\packaging\installer\bounded-process.ps1"
$driverNode=(Resolve-Path "$PSScriptRoot\..\packaging\installer\stage\node\node.exe").Path
$private=Join-Path $env:RUNNER_TEMP ('sd-private-'+[guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory $private|Out-Null
$check=Join-Path $PSScriptRoot 'api-check.mjs'
$preflight=Join-Path $PSScriptRoot '..\packaging\installer\preflight.ps1'
$default=Join-Path $env:LOCALAPPDATA 'SmartDine'
$custom=Join-Path ([IO.Path]::GetPathRoot($env:RUNNER_TEMP)) 'SmartDine Evidence Custom'
$roots=@($default,$custom)
$created=[Collections.Generic.List[string]]::new()
$env:SMARTDINE_NO_BROWSER='1'
Remove-Item Env:SMARTDINE_DB,Env:SMARTDINE_DEMO -ErrorAction SilentlyContinue
$env:SMARTDINE_HOST='127.0.0.1';$env:PORT='8080'
function Note($s){$s|Tee-Object -FilePath (Join-Path $ev 'matrix.log') -Append}
function Hash($p){(Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLower()}
function NodeOwned($root){@(Get-CimInstance Win32_Process -Filter "Name='node.exe'" |Where-Object{$_.ExecutablePath -and [string]::Equals($_.ExecutablePath,(Join-Path $root 'node\node.exe'),[StringComparison]::OrdinalIgnoreCase)})}
function StopOwned($root){
 foreach($p in (NodeOwned $root)){Stop-Process -Id $p.ProcessId -Force -ErrorAction SilentlyContinue}
 for($i=0;$i -lt 30;$i++){if(!(NodeOwned $root).Count){return};Start-Sleep -Milliseconds 200};throw 'owned Node did not stop'
}
function RunCheck($root,$phase,$state,$label){Invoke-BoundedProcess -FilePath $driverNode -Arguments "`"$check`" $phase `"$root`" `"$state`"" -Seconds 45 -Label $label}
function Install($exe,$root,$label){
 # NSIS /D is deliberately last and unquoted per NSIS silent-install contract.
 $args='/S';if($root -ne $default){$args+=" /D=$root"}
 Invoke-BoundedProcess -FilePath $exe -Arguments $args -Seconds 75 -Label $label
 if(!(Test-Path -LiteralPath "$root\node\node.exe")){throw 'installer actual root differs from selected/default root'}
}
function CurrentLaunch($root,$label){
 Push-Location $env:RUNNER_TEMP
 try{Invoke-BoundedProcess -FilePath 'cscript.exe' -Arguments "//nologo `"$root\launcher.vbs`"" -Seconds 65 -Label $label}finally{Pop-Location}
 $owned=NodeOwned $root
 if(!$owned.Count -or !($owned|Where-Object{$_.CommandLine.Contains('"'+$root+'\app\runtime-app\launch.mjs"')})){throw 'current exact executable/quoted entry process missing'}
 AssertInstalled $root
 $owned|Select-Object ProcessId,ExecutablePath,CommandLine|ConvertTo-Json|Set-Content (Join-Path $ev "$label-process.json")
}
function CheckShortcuts($root,$label){
 $sh=New-Object -ComObject WScript.Shell
 $link=$sh.CreateShortcut((Join-Path ([Environment]::GetFolderPath('Desktop')) 'SmartDine POS.lnk'))
 if($link.TargetPath -notmatch '\\wscript.exe$' -or $link.Arguments -ne ('"'+$root+'\launcher.vbs"')){throw 'wrong installed shortcut destination'}
 @($link.TargetPath,$link.Arguments)|Set-Content (Join-Path $ev "$label-shortcut.txt")
}
function AssertInstalled($root){
 $m=Get-Content "$root\app\MANIFEST.json" -Raw|ConvertFrom-Json
 $expected=Get-Content "$PSScriptRoot\..\packaging\installer\stage\app\MANIFEST.json" -Raw
 if((Get-Content "$root\app\MANIFEST.json" -Raw) -ne $expected){throw 'installed manifest differs from staged manifest'}
 foreach($f in $m.files){$file=Join-Path "$root\app" $f.path;if(!(Test-Path -LiteralPath $file) -or (Get-Item -LiteralPath $file).Length -ne $f.bytes -or (Hash $file) -ne $f.sha256){throw "installed manifest byte mismatch: $($f.path)"}}
 if((Hash "$root\node\node.exe") -ne (Hash $driverNode)){throw 'installed Node differs from verified official Node'}
 Note "PASS installed46file manifest and official Node equality: $root"
}
function ExpectedPreflight($root,$reason,$label){
 $output=Join-Path $ev "$label-preflight.txt";$err=Join-Path $ev "$label-preflight-error.txt"
 $p=Start-Process powershell.exe -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$preflight`" -InstallDir `"$root`"" -PassThru -RedirectStandardOutput $output -RedirectStandardError $err
 try{if(!$p.WaitForExit(15000)){& taskkill.exe /PID $p.Id /T /F|Out-Null;throw 'preflight deadline'};$p.Refresh();$text=(Get-Content $output,$err -Raw -ErrorAction SilentlyContinue)-join "`n";if($p.ExitCode -eq 0 -or $text -notmatch [regex]::Escape($reason)){throw "wrong refusal reason: $label"}}finally{$p.Dispose()}
}
function StateHash($root){
 # Stable owned payload and stopped/checkpointed DB, no folder-time comparisons.
 $r=@{};foreach($rel in @('app\data\smartdine.db','smartdine-install.json','launcher.vbs','app\runtime-app\server.mjs','app\server.mjs')){if(Test-Path -LiteralPath (Join-Path $root $rel)){$r[$rel]=Hash (Join-Path $root $rel)}}
 $r|ConvertTo-Json -Compress
}
function Refusal($root,$label){
 ExpectedPreflight $root 'Alternate runtime-app data directory exists' $label
 $before=StateHash $root
 $p=Start-Process -FilePath $Candidate -ArgumentList "/S /D=$root" -PassThru
 try{if(!$p.WaitForExit(20000)){& taskkill.exe /PID $p.Id /T /F |Out-Null;throw "refusal installer hung: $label"};$p.Refresh();if($p.ExitCode -eq 0){throw "expected refusal: $label"}}finally{$p.Dispose()}
 if((StateHash $root) -ne $before){throw "refusal changed owned files: $label"};Note "PASS refusal $label, stopped/payload hashes unchanged"
}
function Uninstall($root,$label){
 # NSIS _?= forces in-place synchronous uninstaller; must be last/unquoted.
 Invoke-BoundedProcess -FilePath "$root\Uninstall.exe" -Arguments "/S _?=$root" -Seconds 45 -Label $label
}
try{
 foreach($root in $roots){if(Test-Path -LiteralPath $root){throw "pre-existing target refused: $root"}}
 if(Get-NetTCPConnection -LocalPort 8080 -State Listen -ErrorAction SilentlyContinue){throw '8080 already occupied; no process killed'}
 # Fresh default once, then genuine old->new default and custom, serially on 8080.
 $created.Add($default)
 Install $Candidate $default 'fresh-default-install';CurrentLaunch $default 'fresh-default-launch';CheckShortcuts $default 'fresh-default'
 RunCheck $default 'fresh' (Join-Path $ev 'unused.json') 'fresh-default-api';StopOwned $default
 # Unrelated healthy listener must not be adopted or killed by the shipped launcher.
 $dummyScript=Join-Path $ev 'unrelated-http.cjs'
 Set-Content $dummyScript "require('http').createServer((q,r)=>{r.writeHead(200,{'content-type':'application/json'});r.end(JSON.stringify({ok:true}))}).listen(8080,'127.0.0.1');"
 $dummy=Start-Process -FilePath (Get-Command node.exe).Source -ArgumentList "`"$dummyScript`"" -PassThru
 try{
  $up=$false;for($i=0;$i -lt 30;$i++){try{$null=Invoke-RestMethod http://127.0.0.1:8080/api/health -TimeoutSec 1;$up=$true;break}catch{};Start-Sleep -Milliseconds 100};if(!$up){throw 'dummy listener not ready'}
  $p=Start-Process cscript.exe -ArgumentList "//nologo `"$default\launcher.vbs`"" -PassThru
  if(!$p.WaitForExit(15000)){& taskkill.exe /PID $p.Id /T /F|Out-Null;throw 'port refusal timeout'};$p.Refresh();$dummy.Refresh();if($p.ExitCode -eq 0 -or $dummy.HasExited){throw 'unrelated healthy port wrongly adopted/killed'};$p.Dispose();Note 'PASS unrelated healthy8080 listener refused and not killed'
 }finally{if(!$dummy.HasExited){Stop-Process -Id $dummy.Id -Force};$dummy.Dispose()}
 foreach($bad in @('C:\','C:\SmartDine;bad','\\localhost\share\SmartDine')){ExpectedPreflight $bad 'Unsupported install path' 'unsafe-path'};Note 'PASS root/UNC/punctuation refusal reasons'


 RunCheck $default 'checkpoint' (Join-Path $ev 'unused.json') 'fresh-default-checkpoint';Uninstall $default 'fresh-default-uninstall'
 # Only our just-created synthetic root, after fresh outcome recorded. Upgrade roots never reset below.
 Remove-Item -LiteralPath $default -Recurse -Force
 foreach($spec in @(@{root=$default;tag='default'},@{root=$custom;tag='custom'})){
  $root=$spec.root;$tag=$spec.tag;$state=Join-Path $private "$tag-state.json"
  if(!$created.Contains($root)){$created.Add($root)}
  Install $Legacy $root "$tag-legacy-install"
  $node=Join-Path $root 'node\node.exe';$server=Join-Path $root 'app\server.mjs'
  if(!(Test-Path $node) -or (Get-Item $node).Length -lt 1000000){throw 'actual installed legacy Node missing/truncated'}
  if((Hash $server) -ne '52a3902e515ebb4700da7015551a2b5e04a719bdbfa05c3d5df38e49aaa47f4e'){throw 'installed legacy server not exact run5'}
  @("node=$node","sha256=$(Hash $node)","size=$((Get-Item $node).Length)","version=$(& $node --version)")|Set-Content (Join-Path $ev "$tag-legacy-node.txt")
  # Inspect and invoke the ACTUAL installed launcher, not direct server invocation.
  $sh=New-Object -ComObject WScript.Shell
  $lnk=Join-Path ([Environment]::GetFolderPath('Desktop')) 'SmartDine POS.lnk'
  if(!(Test-Path $lnk)){throw 'actual legacy desktop shortcut missing'}
  $link=$sh.CreateShortcut($lnk)
  @("target=$($link.TargetPath)","args=$($link.Arguments)","cwd=$($link.WorkingDirectory)")|Set-Content (Join-Path $ev "$tag-legacy-shortcut.txt")
  $bat=Join-Path $root 'SmartDine.bat'
  if(Test-Path $bat){
   $batText=Get-Content $bat -Raw
   # Inspect actual cwd/env privately. No raw launcher body or possible secrets in artifacts.
   @("sha256=$(Hash $bat)","setsDB=$([bool]($batText -match 'SMARTDINE_DB'))","usesLocalAppData=$([bool]($batText -match 'LOCALAPPDATA'))","usesScriptRoot=$([bool]($batText -match '%~dp0'))")|Set-Content (Join-Path $ev "$tag-legacy-launcher-shape.txt")
  }
  # WScript resolves the installed shortcut, including its own target/cwd/environment.
  # No wait on browser or old persistent command shell; bounded health+owned-node wait below.
  $sh.Run(('"'+$lnk+'"'),0,$false)|Out-Null
  $ready=$false;for($i=0;$i -lt 40;$i++){try{$h=Invoke-RestMethod http://127.0.0.1:8080/api/health -TimeoutSec 2;if($h.ok -and (NodeOwned $root).Count){$ready=$true;break}}catch{};Start-Sleep -Milliseconds 250};if(!$ready){throw 'actual installed legacy launcher did not boot owned server at expected root (custom path may be unsupported by legacy launcher)'}
  NodeOwned $root|Select-Object ProcessId,ExecutablePath,CommandLine|ConvertTo-Json|Set-Content (Join-Path $ev "$tag-legacy-process.json")
  RunCheck $root 'seed' $state "$tag-legacy-seed";StopOwned $root;RunCheck $root 'checkpoint' $state "$tag-old-checkpoint"
  Copy-Item "$root\app\data\smartdine.db" (Join-Path $private "$tag-preupgrade.db")
  Install $Candidate $root "$tag-upgrade";CurrentLaunch $root "$tag-current-launch";CheckShortcuts $root "$tag-current"
  RunCheck $root 'verify' $state "$tag-current-api"
  $payload=Hash "$root\app\runtime-app\server.mjs"
  ExpectedPreflight $root 'Target Node process still running' "$tag-active"
  if((Hash "$root\app\runtime-app\server.mjs") -ne $payload){throw 'active refusal changed payload'};Note "PASS $tag active preflight reason"
  Invoke-BoundedProcess -FilePath cscript.exe -Arguments "//nologo `"$root\stop.vbs`" /quiet" -Seconds 15 -Label "$tag-shipped-stop"
  for($i=0;$i -lt 30 -and (NodeOwned $root).Count;$i++){Start-Sleep -Milliseconds 200};if((NodeOwned $root).Count){throw 'shipped stop failed'}
  RunCheck $root 'checkpoint' $state "$tag-current-checkpoint"
  $alternate=Join-Path $root 'app\runtime-app\data';New-Item -ItemType Directory $alternate|Out-Null;Set-Content (Join-Path $alternate 'sentinel.txt') 'synthetic alternate preserve'
  Refusal $root "$tag-alternate-install"
  $before=StateHash $root;$p=Start-Process -FilePath "$root\Uninstall.exe" -ArgumentList "/S _?=$root" -PassThru
  if(!$p.WaitForExit(20000)){& taskkill.exe /PID $p.Id /T /F|Out-Null;throw 'uninstall refusal hung'};$p.Refresh();if($p.ExitCode -eq 0 -or (StateHash $root) -ne $before -or !(Test-Path "$alternate\sentinel.txt")){throw 'alternate uninstall refusal failed'};$p.Dispose();Note "PASS $tag alternate install/uninstall refusal"
  Remove-Item -LiteralPath $alternate -Recurse -Force # Only the synthetic directory created above, before preservation test.
  New-Item -ItemType Directory -Force "$root\browser-profile"|Out-Null;Set-Content "$root\browser-profile\ci-sentinel.txt" 'profile retained'
  $dbhash=Hash "$root\app\data\smartdine.db";$snap=Hash "$root\app\data\ci-snapshot.db";$profile=Hash "$root\browser-profile\ci-sentinel.txt"
  Uninstall $root "$tag-current-uninstall"
  if((Hash "$root\app\data\smartdine.db") -ne $dbhash -or (Hash "$root\app\data\ci-snapshot.db") -ne $snap -or (Hash "$root\browser-profile\ci-sentinel.txt") -ne $profile){throw 'uninstall lost retained data/profile'}
  foreach($rel in @('node','app\runtime-app','launcher.vbs','stop.vbs','preflight.ps1')){if(Test-Path (Join-Path $root $rel)){throw "uninstall retained owned runtime $rel"}}
  Note "PASS $tag uninstall preserves exact DB/snapshot/profile hashes and removes owned runtime"
  if(!(Test-Path "$root\smartdine-install.json")){throw 'retained ownership marker missing'}
  Install $Candidate $root "$tag-retained-reinstall"
  CurrentLaunch $root "$tag-reinstalled-launch";RunCheck $root 'reinstall' $state "$tag-reinstalled-api";StopOwned $root
 }
 Note 'PASS FINITE-WINDOWS-MATRIX'
 }finally{
 # Only fixed classifications/booleans and known relative hashes. No raw paths/argv/logs.
 try{
  foreach($root in $created){
   $tag=if($root -eq $default){'default'}else{'custom'}
   $safe=@("rootRole=$tag")
   foreach($rel in @('node\node.exe','app\runtime-app\launch.mjs','app\runtime-app\server.mjs','app\MANIFEST.json','launcher.vbs','app\data\smartdine.db')){
    $f=Join-Path $root $rel;$safe+=("exists[$rel]="+(Test-Path -LiteralPath $f));if($rel -ne 'app\data\smartdine.db' -and (Test-Path -LiteralPath $f)){$safe+=("sha256[$rel]="+(Hash $f))}
   }
   $safe|Set-Content (Join-Path $ev "$tag-startup-paths.txt")
   $owned=@(NodeOwned $root);@("ownedNodeCount="+$owned.Count)|Set-Content (Join-Path $ev "$tag-startup-process-shape.txt")
   foreach($p in $owned){@("role=node pid="+$p.ProcessId+" exeEqualsOwned=true quotedEntryMatches="+$p.CommandLine.Contains('"'+$root+'\app\runtime-app\launch.mjs"'))|Add-Content (Join-Path $ev "$tag-startup-process-shape.txt")}
   foreach($kind in @('cscript.exe','cmd.exe')){
    $items=@(Get-CimInstance Win32_Process -Filter "Name='$kind'"|Where-Object{$_.CommandLine -and $_.CommandLine.Contains($root)})
    foreach($p in $items){("role=$kind pid="+$p.ProcessId+" rootMention=true")|Add-Content (Join-Path $ev "$tag-startup-process-shape.txt")}
   }
   $log=Join-Path $root 'app\data\server.log';$classes=@('MODULE_NOT_FOUND','ERR_MODULE_NOT_FOUND','SyntaxError','EADDRINUSE','SQLITE_BUSY','SQLITE_ERROR','EACCES','EPERM','ENOENT')
   $text=if(Test-Path -LiteralPath $log){Get-Content -LiteralPath $log -Raw}else{''}
   $summary=@("startupLogExists="+(Test-Path -LiteralPath $log),"listeningMarker="+$text.Contains('SmartDine API listening'))
   foreach($class in $classes){$summary+=("class[$class]="+[bool]($text -match [regex]::Escape($class)))}
   $summary|Set-Content (Join-Path $ev "$tag-startup-fixed-classes.txt")
  }
  try{$h=Invoke-WebRequest http://127.0.0.1:8080/api/health -TimeoutSec 3;("status="+$h.StatusCode)|Set-Content (Join-Path $ev 'final-health-status.txt')}catch{
   $kind=if($_.Exception -is [System.Net.Http.HttpRequestException]){'HttpRequestException'}elseif($_.Exception -is [System.Threading.Tasks.TaskCanceledException]){'TaskCanceledException'}else{'OtherHealthException'}
   $kind|Set-Content (Join-Path $ev 'final-health-status.txt')
  }
 }catch{Write-Warning 'Startup diagnostic capture failed; original error retained'}
 try{foreach($root in $created){try{StopOwned $root}catch{Write-Warning ('Scoped cleanup failed: '+$_.Exception.Message)}}}
 finally{try{if(Test-Path $private){Remove-Item -LiteralPath $private -Recurse -Force}}catch{Write-Warning 'Private synthetic cleanup failed; never uploaded'};try{Stop-Transcript|Out-Null}catch{Write-Warning 'Transcript stop failed'}}
}
