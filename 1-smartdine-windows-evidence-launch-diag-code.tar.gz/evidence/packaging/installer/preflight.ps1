# Read-only target verification, also used before uninstall. Never deletes files.
param([Parameter(Mandatory)][string]$InstallDir,[switch]$Uninstall)
$ErrorActionPreference='Stop'
$root=[IO.Path]::GetFullPath($InstallDir).TrimEnd('\')
# cmd/VBS launch quoting and root-drive ambiguity: fail closed instead of rewriting.
if($root -notmatch '^[A-Za-z]:\\[A-Za-z0-9 _-]+(?:\\[A-Za-z0-9 _-]+)*$' -or $root.Split('\')[-1].EndsWith(' ')){throw 'Unsupported install path. Use a local non-root folder with letters, numbers, spaces, underscores or dashes.'}
if(Test-Path $root){
  $current=Get-Item -LiteralPath $root
  while($current){if($current.Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Reparse-point install path refused'};$current=$current.Parent}
  $children=@(Get-ChildItem -LiteralPath $root -Force)
  if($children.Count -gt 0){
    $permitted=@('app','node','launcher.vbs','stop.vbs','SmartDine.bat','Uninstall.exe','browser-profile','smartdine-install.json','smoke-order.txt','smoke-pin.txt','err.log','preflight.ps1')
    if(@($children|Where-Object{$_.Name -notin $permitted}).Count -gt 0){throw 'Folder contains unrelated top-level files. Review manually; no files changed.'}
    $marker=Join-Path $root 'smartdine-install.json'
    if(Test-Path -LiteralPath $marker){$m=Get-Content -LiteralPath $marker -Raw|ConvertFrom-Json;if($m.product -ne 'SmartDine POS' -or $m.layout -ne 2){throw 'Unknown installation marker'}}
    else{
      # Legacy run5 structure/content signatures, not merely app/node folder names.
      $server=Join-Path $root 'app\server.mjs';$pkg=Join-Path $root 'app\package.json';$node=Join-Path $root 'node\node.exe'
      if(!(Test-Path -LiteralPath $server) -or !(Test-Path -LiteralPath $pkg) -or !(Test-Path -LiteralPath $node)){throw 'Nonempty folder is not a recognized SmartDine installation'}
      if((Get-FileHash -LiteralPath $server -Algorithm SHA256).Hash.ToLower() -ne '52a3902e515ebb4700da7015551a2b5e04a719bdbfa05c3d5df38e49aaa47f4e'){throw 'Unrecognized legacy server. Review manually; no files changed.'}
      $p=Get-Content -LiteralPath $pkg -Raw|ConvertFrom-Json;if($p.name -ne 'smartdine'){throw 'Unrecognized legacy package'}
      if((Get-Item -LiteralPath $node).Length -lt 1000000){throw 'Legacy Node runtime is missing or truncated'}
    }
  }
}
$exe=Join-Path $root 'node\node.exe'
$owned=Get-CimInstance Win32_Process -Filter "Name='node.exe'" | Where-Object { $_.ExecutablePath -and [string]::Equals($_.ExecutablePath,$exe,[StringComparison]::OrdinalIgnoreCase) }
if($owned){throw 'Target Node process still running. Stop this installation and retry.'}
$alternate=Join-Path $root 'app\runtime-app\data'
if(Test-Path -LiteralPath $alternate){throw 'Alternate runtime-app data directory exists. Reconcile or preserve it manually; no deletion/copy performed.'}
Write-Output 'PREFLIGHT-OK: recognized or empty path, no target Node process, no alternate data.'
