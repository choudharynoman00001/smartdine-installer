# SOURCE ONLY. Portable official compiler, no admin install or arbitrary package manager.
param([Parameter(Mandatory)][string]$Source,[Parameter(Mandatory)][string]$Stage,[Parameter(Mandatory)][string]$Work)
$ErrorActionPreference='Stop'
if($env:GITHUB_ACTIONS -ne 'true' -or $env:RUNNER_OS -ne 'Windows'){throw 'ephemeral Windows Actions only'}
$inputLock=Get-Content (Join-Path $PSScriptRoot 'nsis-input.json') -Raw|ConvertFrom-Json
$archive=Join-Path $Work 'nsis.zip'
Invoke-WebRequest -UseBasicParsing -Uri $inputLock.sourceUrl -OutFile $archive -TimeoutSec 90
if((Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash.ToLowerInvariant() -ne $inputLock.sha256){throw 'compiler pin mismatch'}
Expand-Archive -LiteralPath $archive -DestinationPath (Join-Path $Work 'compiler')
$compiler=Join-Path $Work 'compiler\nsis-3.11\makensis.exe'
# Check actual source parse in both native shells before compiling anything.
foreach($shell in @("$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe",(Get-Command pwsh.exe -ErrorAction Stop).Source)){
 & $shell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot 'parse-probe.ps1') -Source $Source
 if($LASTEXITCODE -ne 0){throw 'native PowerShell source parse failed'}
}
Push-Location (Join-Path $Source 'windows')
try{
 & $compiler /V2 (('/DPAYLOAD_STAGE='+$Stage)) installer.nsi
 if($LASTEXITCODE -ne 0){throw 'NSIS compile failed'}
 Move-Item -LiteralPath SmartDinePG-Setup.exe -Destination (Join-Path $Work 'SmartDinePG-Setup.exe')
}finally{Pop-Location}
# Compiler and EXE remain ephemeral Work, never uploaded or published.

exit 0
