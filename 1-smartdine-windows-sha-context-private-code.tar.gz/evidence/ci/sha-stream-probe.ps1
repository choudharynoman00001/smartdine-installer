# Test actual production helper without executing product/preflight top-level code.
$ErrorActionPreference='Stop'
$tokens=$null;$errors=$null
$script=Join-Path $PSScriptRoot '..\packaging\installer\preflight.ps1'
$ast=[Management.Automation.Language.Parser]::ParseFile($script,[ref]$tokens,[ref]$errors)
if($errors.Count){throw 'preflight parse failed'}
$fn=@($ast.FindAll({param($n)$n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -eq 'LegacyFileSha256'},$true))
if($fn.Count -ne 1){throw 'unique production SHA helper required'}
. ([scriptblock]::Create($fn[0].Extent.Text))
$temp=Join-Path $env:RUNNER_TEMP ('sd-sha-'+[guid]::NewGuid().ToString('N'))
[IO.Directory]::CreateDirectory($temp)|Out-Null
try{
 $file=Join-Path $temp 'bytes.bin'
 [IO.File]::WriteAllBytes($file,[byte[]](97,98,99))
 if((LegacyFileSha256 $file) -cne 'ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad'){throw 'SHA known vector failed'}
 $stream=[IO.File]::Open($file,[IO.FileMode]::Open,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None);$stream.Dispose()
 [IO.File]::WriteAllBytes($file,[byte[]]@())
 if((LegacyFileSha256 $file) -cne 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'){throw 'SHA empty vector failed'}
 $refused=$false;try{LegacyFileSha256 (Join-Path $temp 'missing.bin')|Out-Null}catch{$refused=$true};if(!$refused){throw 'missing read accepted'}
 $legacy=Join-Path $PSScriptRoot '..\packaging\installer\stage\app\runtime-app\server.mjs'
 # Real bytes agreement with independently verified Node SHA, no emitted paths/digests.
 $expected=& (Join-Path $PSScriptRoot '..\packaging\installer\stage\node\node.exe') -e "const fs=require('fs'),c=require('crypto');console.log(c.createHash('sha256').update(fs.readFileSync(process.argv[1])).digest('hex'))" $legacy
 if($LASTEXITCODE -ne 0 -or (LegacyFileSha256 $legacy) -cne $expected){throw 'actual file SHA agreement failed'}
 Write-Output ('context process64='+[Environment]::Is64BitProcess+' psMajor='+$PSVersionTable.PSVersion.Major)
 Write-Output 'PASS production SHA helper knownvectors/readrefusal/disposal/actualbytes agreement'
}finally{[IO.Directory]::Delete($temp,$true)}
