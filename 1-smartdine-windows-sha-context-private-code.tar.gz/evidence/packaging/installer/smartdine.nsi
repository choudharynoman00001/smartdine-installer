; Preparation only. No build or dispatch performed.
!include "MUI2.nsh"
!include "StrFunc.nsh"
${StrStr}
Name "SmartDine POS"
OutFile "SmartDinePOS-Setup.exe"
InstallDir "$LOCALAPPDATA\SmartDine"
RequestExecutionLevel user
!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_DIRECTORY
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_PAGE_FINISH
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES
!insertmacro MUI_LANGUAGE "English"
!include "quote-install-dir.nsh"
; Fixed diagnostic classes only on disposable Windows Actions. No stack text/path emitted.
Function RecordPreflightClass
 ReadEnvStr $R0 "GITHUB_ACTIONS"
 StrCmp $R0 "true" 0 diag_done
 ReadEnvStr $R0 "RUNNER_TEMP"
 StrCmp $R0 "" diag_done
 StrCpy $R3 "numeric-nonzero"
 StrCmp $0 "0" 0 +2
 StrCpy $R3 "zero"
 StrCmp $0 "error" 0 +2
 StrCpy $R3 "launch-error"
 StrCmp $0 "timeout" 0 +2
 StrCpy $R3 "timeout"
 StrCpy $R1 "unclassified"
 StrCmp $0 "0" 0 +3
 StrCpy $R1 "ok"
 Goto diag_write
 ${StrStr} $R2 $1 "Unsupported install path"
 StrCmp $R2 "" +3
 StrCpy $R1 "guard-0"
 Goto diag_write
 ${StrStr} $R2 $1 "Reparse-point install path refused"
 StrCmp $R2 "" +3
 StrCpy $R1 "guard-1"
 Goto diag_write
 ${StrStr} $R2 $1 "Folder contains unrelated top-level files"
 StrCmp $R2 "" +3
 StrCpy $R1 "guard-2"
 Goto diag_write
 ${StrStr} $R2 $1 "Unknown installation marker"
 StrCmp $R2 "" +3
 StrCpy $R1 "guard-3"
 Goto diag_write
 ${StrStr} $R2 $1 "Nonempty folder is not a recognized SmartDine installation"
 StrCmp $R2 "" +3
 StrCpy $R1 "guard-4"
 Goto diag_write
 ${StrStr} $R2 $1 "Unrecognized legacy server"
 StrCmp $R2 "" +3
 StrCpy $R1 "guard-5"
 Goto diag_write
 ${StrStr} $R2 $1 "Unrecognized legacy package"
 StrCmp $R2 "" +3
 StrCpy $R1 "guard-6"
 Goto diag_write
 ${StrStr} $R2 $1 "Legacy Node runtime is missing or truncated"
 StrCmp $R2 "" +3
 StrCpy $R1 "guard-7"
 Goto diag_write
 ${StrStr} $R2 $1 "Target Node process still running"
 StrCmp $R2 "" +3
 StrCpy $R1 "guard-8"
 Goto diag_write
 ${StrStr} $R2 $1 "Alternate runtime-app data directory exists"
 StrCmp $R2 "" +3
 StrCpy $R1 "guard-9"
 Goto diag_write
 diag_write:
 FileOpen $R2 "$R0\smartdine-ci-evidence\installer-preflight-fixed.txt" w
 FileWrite $R2 "phase=before-payload preflightClass=$R1 launcherStatus=$R3$\r$\n"
 FileClose $R2
 diag_done:
FunctionEnd
Section "Install"
  InitPluginsDir
  SetOutPath "$PLUGINSDIR"
  File "preflight.ps1"
  ReadEnvStr $R0 "GITHUB_ACTIONS"
  StrCmp $R0 "true" 0 diag_clear_done
  ReadEnvStr $R0 "RUNNER_TEMP"
  StrCmp $R0 "" diag_clear_done
  Delete "$R0\smartdine-ci-evidence\preflight-phase-fixed.txt"
  diag_clear_done:
  Call QuoteInstallDir
  nsExec::ExecToStack '"$SYSDIR\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "$PLUGINSDIR\preflight.ps1" -InstallDir $2'
  Pop $0
  Pop $1
  Call RecordPreflightClass
  StrCmp $0 "0" preflight_ok
  MessageBox MB_OK "Upgrade preflight failed. Stop this installation and reconcile alternate databases before retrying. No payload files were copied." /SD IDOK
  SetErrorLevel 1
  Abort
  preflight_ok:
  ; Preflight refuses target Node processes; it never terminates them.
  ; Candidate payload contains no app/data, so existing DB is not overwritten.
  SetOutPath "$INSTDIR"
  File /r "stage\*"
  File "launcher.vbs"
  File "stop.vbs"
  File "preflight.ps1"
  CreateDirectory "$INSTDIR\app\data"
  CreateDirectory "$SMPROGRAMS\SmartDine"
  CreateShortcut "$SMPROGRAMS\SmartDine\SmartDine POS.lnk" "$SYSDIR\wscript.exe" '"$INSTDIR\launcher.vbs"' "$INSTDIR\node\node.exe" 0
  CreateShortcut "$DESKTOP\SmartDine POS.lnk" "$SYSDIR\wscript.exe" '"$INSTDIR\launcher.vbs"' "$INSTDIR\node\node.exe" 0
  CreateShortcut "$SMPROGRAMS\SmartDine\Stop SmartDine.lnk" "$SYSDIR\wscript.exe" '"$INSTDIR\stop.vbs"' "$INSTDIR\node\node.exe" 0
  ; Disable old launch paths after the new payload is installed, not data files.
  Delete "$INSTDIR\SmartDine.bat"
  Delete "$INSTDIR\app\server.mjs"
  WriteUninstaller "$INSTDIR\Uninstall.exe"
SectionEnd
Section "Uninstall"
  Call un.QuoteInstallDir
  nsExec::ExecToStack '"$SYSDIR\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "$INSTDIR\preflight.ps1" -InstallDir $2 -Uninstall'
  Pop $0
  Pop $1
  StrCmp $0 "0" uninstall_preflight_ok
  MessageBox MB_OK "Uninstall refused: stop this installation and preserve or reconcile alternate data first. No files removed." /SD IDOK
  SetErrorLevel 1
  Abort
  uninstall_preflight_ok:
  Delete "$SMPROGRAMS\SmartDine\SmartDine POS.lnk"
  Delete "$SMPROGRAMS\SmartDine\Stop SmartDine.lnk"
  RMDir "$SMPROGRAMS\SmartDine"
  Delete "$DESKTOP\SmartDine POS.lnk"
  ; Preserve restaurant DB, backups, browser profile and logs by default.
  RMDir /r "$INSTDIR\node"
  RMDir /r "$INSTDIR\app\runtime-app"
  RMDir /r "$INSTDIR\app\lib"
  Delete "$INSTDIR\app\*.mjs"
  Delete "$INSTDIR\app\package.json"
  Delete "$INSTDIR\launcher.vbs"
  Delete "$INSTDIR\stop.vbs"
  Delete "$INSTDIR\preflight.ps1"
  ; Preserve owned layout marker so retained-data reinstall remains recognized.
  Delete "$INSTDIR\Uninstall.exe"
SectionEnd
