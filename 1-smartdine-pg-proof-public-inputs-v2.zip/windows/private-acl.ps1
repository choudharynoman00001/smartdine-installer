param([Parameter(Mandatory)][string]$Path,[switch]$Set)
$ErrorActionPreference='Stop'
$identity=[System.Security.Principal.WindowsIdentity]::GetCurrent()
$sid=$identity.User
if(!(Test-Path -LiteralPath $Path)){throw 'private path missing'}
$item=Get-Item -LiteralPath $Path
if(($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0){throw 'reparse point refused'}
if($Set){
 $acl=Get-Acl -LiteralPath $Path
 $acl.SetAccessRuleProtection($true,$false)
 foreach($rule in @($acl.Access)){[void]$acl.RemoveAccessRuleSpecific($rule)}
 $acl.SetOwner($sid)
 $inherit=if($item.PSIsContainer){[Security.AccessControl.InheritanceFlags]'ContainerInherit,ObjectInherit'}else{[Security.AccessControl.InheritanceFlags]::None}
 $rule=New-Object Security.AccessControl.FileSystemAccessRule($sid,[Security.AccessControl.FileSystemRights]::FullControl,$inherit,[Security.AccessControl.PropagationFlags]::None,[Security.AccessControl.AccessControlType]::Allow)
 [void]$acl.AddAccessRule($rule)
 Set-Acl -LiteralPath $Path -AclObject $acl
}
$acl=Get-Acl -LiteralPath $Path
if(!$acl.AreAccessRulesProtected){throw 'inherited private ACL refused'}
if($acl.GetOwner([System.Security.Principal.SecurityIdentifier]).Value -ne $sid.Value){throw 'private owner mismatch'}
foreach($rule in $acl.Access){if($rule.AccessControlType -eq [Security.AccessControl.AccessControlType]::Allow -and $rule.IdentityReference.Translate([System.Security.Principal.SecurityIdentifier]).Value -ne $sid.Value){throw 'private ACL grants another identity'}}
Write-Output 'PASS current-user protected private ACL'
