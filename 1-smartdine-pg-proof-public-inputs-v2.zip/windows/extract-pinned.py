# Build-only archive extraction. Reject links/traversal, no network or execution.
import sys,zipfile,tarfile,pathlib,hashlib,json,os
lock=json.load(open(sys.argv[1]));dest=pathlib.Path(sys.argv[2]);dest.mkdir(exist_ok=False)
try:
 for item in lock['inputs']:
  archive=pathlib.Path(item['archivePath']);assert hashlib.sha256(archive.read_bytes()).hexdigest()==item['archiveSha256'],'pin mismatch'
  target=dest/item['name'];target.mkdir()
  if zipfile.is_zipfile(archive):
   with zipfile.ZipFile(archive) as z:
    for info in z.infolist():
     name=pathlib.PurePosixPath(info.filename);assert not name.is_absolute() and '..' not in name.parts and '\\' not in info.filename,'archive traversal'
     assert (info.external_attr>>16)&0o170000!=0o120000,'archive link'
     parts=list(name.parts)
     if item['name']=='pgsql':
      if not parts or parts[0]!='pgsql':continue
      parts=parts[1:]
      if not parts or parts[0] not in ['bin','lib','share','server_license.txt','commandlinetools_3rd_party_licenses.txt']:continue
     elif item['name']=='node':
      if len(parts)<2:continue
      parts=parts[1:]
      if not parts or parts[0] not in ['node.exe','LICENSE','README.md']:continue
     out=target.joinpath(*parts)
     if info.is_dir():out.mkdir(parents=True,exist_ok=True)
     else:out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(z.read(info))
  else:
   with tarfile.open(archive) as t:
    for info in t.getmembers():
     name=pathlib.PurePosixPath(info.name);assert not name.is_absolute() and '..' not in name.parts,'archive traversal';assert info.isfile() or info.isdir(),'archive link/device'
     out=target.joinpath(*name.parts)
     if info.isdir():out.mkdir(parents=True,exist_ok=True)
     else:out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(t.extractfile(info).read())
  item['directory']=str(target.resolve())
 print(json.dumps(lock))
except:
 import shutil;shutil.rmtree(dest);raise
