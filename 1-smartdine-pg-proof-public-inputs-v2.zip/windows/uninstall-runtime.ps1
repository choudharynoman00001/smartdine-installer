param([Parameter(Mandatory)][string]$Root)
$ErrorActionPreference='Stop'
& (Join-Path $PSScriptRoot 'preflight.ps1') -Root $Root -Uninstall
if($LASTEXITCODE -ne 0){throw 'uninstall preflight refused'}
# Explicit preserved-only layout. Never recurse over root/private or unknown paths.
$versions=Join-Path $Root 'versions'
if(Test-Path -LiteralPath $versions){
 foreach($v in Get-ChildItem -LiteralPath $versions -Directory){
  if($v.Name -notmatch '^[a-f0-9]{64}$' -or ($v.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0){throw 'foreign version refused'}
  $manifest=Join-Path $v.FullName 'payload-manifest.json'
  if(!(Test-Path -LiteralPath $manifest)){throw 'unowned version refused'}
  $sha=[Security.Cryptography.SHA256]::Create();$stream=[IO.File]::OpenRead($manifest)
  try{$digest=([BitConverter]::ToString($sha.ComputeHash($stream))).Replace('-','').ToLowerInvariant()}finally{$stream.Dispose();$sha.Dispose()}
  if($digest -ne $v.Name){throw 'version identity mismatch'}
  $m=Get-Content -LiteralPath $manifest -Raw | ConvertFrom-Json
  $allowed=@{};$allowed['payload-manifest.json']=$true
  foreach($f in $m.files){if($f.path -notmatch '^[A-Za-z0-9_ +./-]+$' -or $f.path -match '(^|/)\.\.(/|$)'){throw 'manifest path refused'};$allowed[$f.path.Replace('/','\')]=$true}
  foreach($item in Get-ChildItem -LiteralPath $v.FullName -Force -Recurse){if(($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0){throw 'linked payload refused'};if(!$item.PSIsContainer){$rel=$item.FullName.Substring($v.FullName.Length+1);if(!$allowed.ContainsKey($rel)){throw 'unknown payload file; preserve for review'}}}

 }
 # After all versions validate, remove only these payload dirs. Private state retained.
 foreach($v in Get-ChildItem -LiteralPath $versions -Directory){Remove-Item -LiteralPath $v.FullName -Recurse -Force}
 Remove-Item -LiteralPath $versions -Force
}
# Keep marker/selected/private so retained reinstall cannot initialize by mistake.
Write-Output 'Runtime payload removed; private PostgreSQL data/config/backups/logs retained.'
