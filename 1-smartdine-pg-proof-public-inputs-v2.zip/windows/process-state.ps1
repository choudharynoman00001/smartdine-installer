param([Parameter(Mandatory)][string]$Root,[switch]$Recover,[switch]$Stop,[switch]$Stamp,[ValidateSet('private','private.init')][string]$PrivateName='private')
$ErrorActionPreference='Stop'
# CIM failure is not proof of death. Process snapshots and PID/start/exe/command identity required.
if($Root -notmatch '^[A-Za-z]:\\(?:[A-Za-z0-9 _-]+\\)*[A-Za-z0-9 _-]+$'){throw 'dedicated local root required'}
$all=@(Get-CimInstance Win32_Process -ErrorAction Stop)
if($Stamp){$p=$all|Where-Object ProcessId -eq $PID; $p|Select-Object ProcessId,CreationDate|ConvertTo-Json -Compress;exit 0}
# Use Windows argv tokenization, never substring matching as ownership proof.
Add-Type -TypeDefinition @'
using System;using System.Runtime.InteropServices;
public static class SmartDineArgv {
 [DllImport("shell32.dll",SetLastError=true)] static extern IntPtr CommandLineToArgvW([MarshalAs(UnmanagedType.LPWStr)] string s,out int n);
 [DllImport("kernel32.dll")] static extern IntPtr LocalFree(IntPtr p);
 public static string[] Parse(string s){int n;IntPtr p=CommandLineToArgvW(s,out n);if(p==IntPtr.Zero)throw new Exception("argv unavailable");try{string[] a=new string[n];for(int i=0;i<n;i++)a[i]=Marshal.PtrToStringUni(Marshal.ReadIntPtr(p,i*IntPtr.Size));return a;}finally{LocalFree(p);}}
}
'@
function Norm([string]$p){if(!$p){throw 'path identity unavailable'};return [IO.Path]::GetFullPath($p.Replace('/','\')).TrimEnd('\').ToLowerInvariant()}
function Args($p){if(!$p.CommandLine){throw 'command ownership unreadable'};return @([SmartDineArgv]::Parse($p.CommandLine))}
function HasPath($a,[string]$expected){foreach($t in $a){if($t -match '^[A-Za-z]:[\\/]'){if((Norm $t) -eq (Norm $expected)){return $true}}};return $false}
function RootExe($p){if(!$p.ExecutablePath){return $false};return (Norm $p.ExecutablePath).StartsWith((Norm $Root)+'\versions\',[StringComparison]::Ordinal)}
function Ticks($p){return ([DateTime]$p.CreationDate).ToUniversalTime().Ticks}
$private=Join-Path $Root $PrivateName;$record=Join-Path $private 'supervisor.pid'
function InspectRecord([string]$record) {
 if(!(Test-Path -LiteralPath $record)){return $null}
 $r=Get-Content -LiteralPath $record -Raw|ConvertFrom-Json
 if(!$r.pid -or !$r.startedTicks -or !$r.exe -or !$r.script){throw 'invalid ownership record; preserve for review'}
 $p=$all|Where-Object ProcessId -eq $r.pid
 if(!$p){if($Recover){Remove-Item -LiteralPath $record};return $null}
 if((Ticks $p) -gt [long]$r.startedTicks){if($Recover){Remove-Item -LiteralPath $record};return $null}
 if(!$p.ExecutablePath -or (Norm $p.ExecutablePath) -ne (Norm $r.exe) -or !(HasPath (Args $p) $r.script) -or (Ticks $p) -ne [long]$r.startedTicks){throw 'PID identity conflict; no signal or cleanup'}
 return $p
}
$s=InspectRecord $record
$startLock=Join-Path $private 'start.lock';$starting=InspectRecord $startLock
if($starting){Write-Output 'SMARTDINE_STARTUP_IN_PROGRESS';exit 22}
$parentId=($all|Where-Object ProcessId -eq $PID).ParentProcessId
foreach($q in $all){
 if($q.ProcessId -eq $PID -or $q.ProcessId -eq $parentId){continue}
 if(RootExe $q){
  if(!$q.CommandLine){throw 'root-owned executable command unreadable; preserve'}
  $a=Args $q
  if($PrivateName -eq 'private.init' -and (HasPath $a (Join-Path $private 'operator.json'))){throw 'initialization still active'}
  if(!$s -and ([IO.Path]::GetFileName($q.ExecutablePath) -ieq 'node.exe') -and ((HasPath $a $Root) -or (HasPath $a (Join-Path $private 'runtime.json')))){throw 'orphan or concurrent app lifecycle; inspect exact process'}
 }
}
$pglock=Join-Path $private 'pgdata\postmaster.pid'
$ownedPg=$null
if(Test-Path -LiteralPath $pglock){
 $lines=@(Get-Content -LiteralPath $pglock);$pgid=0;$epoch=0L
 if($lines.Count -lt 3 -or ![int]::TryParse($lines[0],[ref]$pgid) -or ![long]::TryParse($lines[2],[ref]$epoch) -or $pgid -le 0){throw 'unrecognized PG lock; preserve'}
 $p=$all|Where-Object ProcessId -eq $pgid
 $data=Join-Path $private 'pgdata'
 if($p){
  $prefix=$Root.TrimEnd('\')+'\versions\'
  if(!(RootExe $p) -or [IO.Path]::GetFileName($p.ExecutablePath) -ine 'postgres.exe' -or !(HasPath (Args $p) $data) -or [Math]::Abs(([DateTimeOffset]([DateTime]$p.CreationDate)).ToUnixTimeSeconds()-$epoch) -gt 3){throw 'PG PID identity conflict; preserve lock'}
  $ownedPg=$p
 }elseif($Recover){
  # Do not unlink a potentially live cluster lock, including changed-PID processes.
  foreach($q in $all){if($q.Name -ieq 'postgres.exe'){if(!$q.ExecutablePath){throw 'postgres executable identity unreadable; preserve'};if(RootExe $q){if(!$q.CommandLine -or (HasPath (Args $q) $data)){throw 'possible root-owned PG; preserve lock'}}}}
  if(Get-CimInstance Win32_Process -Filter ('ProcessId='+$pgid) -ErrorAction Stop){throw 'PID changed during recovery; preserve'}
  Remove-Item -LiteralPath $pglock
 }
}
if($Stop){
 if($s){
  $request=Join-Path $private 'stop.request';[IO.File]::WriteAllText($request,'stop')
  $until=(Get-Date).AddSeconds(75)
  while((Test-Path -LiteralPath $record) -and (Get-Date) -lt $until){Start-Sleep -Milliseconds 250}
  if(Test-Path -LiteralPath $record){throw 'supervisor stop not confirmed'}
 }elseif($ownedPg){
  $ctl=Join-Path ([IO.Path]::GetDirectoryName($ownedPg.ExecutablePath)) 'pg_ctl.exe'
  & $ctl -D (Join-Path $private 'pgdata') -w -t 60 -m fast stop
  if($LASTEXITCODE -ne 0){throw 'exact owned cluster stop failed'}
 }
 if(Test-Path -LiteralPath $pglock){throw 'PG stop not confirmed'}
 exit 0
}
if($s -or $ownedPg){Write-Output 'SMARTDINE_STARTUP_IN_PROGRESS';exit 22}
if($Recover){foreach($name in @('stop.request','ready.json')){$f=Join-Path $private $name;if(Test-Path -LiteralPath $f){Remove-Item -LiteralPath $f}}}

exit 0
