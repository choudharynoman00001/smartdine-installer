; Quote the complete literal path for Windows PowerShell/.NET argv parsing.
; Valid paths contain no quotes; duplicate terminal backslashes before delimiter.
Function QuoteInstallDir
  StrCpy $2 $INSTDIR
  StrCpy $3 ""
  StrLen $4 $2
  quote_tail:
    IntCmp $4 0 quote_done
    IntOp $4 $4 - 1
    StrCpy $5 $2 1 $4
    StrCmp $5 "\" 0 quote_done
    StrCpy $3 "$3\"
    Goto quote_tail
  quote_done:
  StrCpy $2 '$\"$INSTDIR$3$\"'
FunctionEnd
Function un.QuoteInstallDir
  StrCpy $2 $INSTDIR
  StrCpy $3 ""
  StrLen $4 $2
  quote_tail:
    IntCmp $4 0 quote_done
    IntOp $4 $4 - 1
    StrCpy $5 $2 1 $4
    StrCmp $5 "\" 0 quote_done
    StrCpy $3 "$3\"
    Goto quote_tail
  quote_done:
  StrCpy $2 '$\"$INSTDIR$3$\"'
FunctionEnd
