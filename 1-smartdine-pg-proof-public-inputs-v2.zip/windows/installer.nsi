; SOURCE ONLY. Build requires complete pinned vendor stage, no release/CI authority.
!include "MUI2.nsh"
Name "SmartDine PostgreSQL"
OutFile "SmartDinePG-Setup.exe"
InstallDir "$LOCALAPPDATA\SmartDinePG"
RequestExecutionLevel user
!insertmacro MUI_PAGE_DIRECTORY
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES
!insertmacro MUI_LANGUAGE "English"
!include "quote-install-dir.nsh"
Section "Install"
 InitPluginsDir
 SetOutPath "$PLUGINSDIR\payload"
!ifndef PAYLOAD_STAGE
 !error "Explicit verified PAYLOAD_STAGE required"
!endif
 File /r "${PAYLOAD_STAGE}\*"
 Call QuoteInstallDir
 ; Strict quoted root; Node lifecycle uses argv arrays thereafter.
 nsExec::ExecToStack '"$PLUGINSDIR\payload\node\node.exe" "$PLUGINSDIR\payload\windows\activate.mjs" $2 "$PLUGINSDIR\payload"'
 Pop $0
 Pop $1
 StrCmp $0 "0" activated
 MessageBox MB_OK "PostgreSQL package activation refused. Private data and earlier payload are retained. Check dependencies, stop state and private operator logs. No automatic reset." /SD IDOK
 SetErrorLevel 1
 Abort
 activated:
 ; Stable scripts outside version dirs are narrow install-owned entry files.
 SetOutPath "$INSTDIR\entry"
 ; Entry files copied from verified payload by activate.mjs, covered by root ACL.
 CreateDirectory "$SMPROGRAMS\SmartDine PostgreSQL"
 CreateShortcut "$SMPROGRAMS\SmartDine PostgreSQL\SmartDine PostgreSQL.lnk" "$SYSDIR\wscript.exe" '"$INSTDIR\entry\launcher.vbs" start'
 CreateShortcut "$SMPROGRAMS\SmartDine PostgreSQL\Stop SmartDine PostgreSQL.lnk" "$SYSDIR\wscript.exe" '"$INSTDIR\entry\launcher.vbs" stop'
 WriteUninstaller "$INSTDIR\Uninstall.exe"
SectionEnd
Section "Uninstall"
 Call un.QuoteInstallDir
 nsExec::ExecToStack '"$SYSDIR\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "$INSTDIR\entry\uninstall-runtime.ps1" -Root $2'
 Pop $0
 Pop $1
 StrCmp $0 "0" removed
 MessageBox MB_OK "Uninstall refused; stop and inspect this PostgreSQL installation. Private data is retained." /SD IDOK
 SetErrorLevel 1
 Abort
 removed:
 Delete "$SMPROGRAMS\SmartDine PostgreSQL\SmartDine PostgreSQL.lnk"
 Delete "$SMPROGRAMS\SmartDine PostgreSQL\Stop SmartDine PostgreSQL.lnk"
 RMDir "$SMPROGRAMS\SmartDine PostgreSQL"
 Delete "$INSTDIR\entry\process-state.ps1"
 Delete "$INSTDIR\entry\process-state.mjs"
 Delete "$INSTDIR\entry\private-acl.ps1"
 Delete "$INSTDIR\entry\paths.mjs"
 Delete "$INSTDIR\entry\verify-payload.mjs"
 Delete "$INSTDIR\entry\launch-selected.mjs"
 Delete "$INSTDIR\entry\preflight.ps1"
 Delete "$INSTDIR\entry\uninstall-runtime.ps1"
 Delete "$INSTDIR\entry\launcher.vbs"
 RMDir "$INSTDIR\entry"
 Delete "$INSTDIR\Uninstall.exe"
 ; Marker, selection and private database/config/keys/logs/backups remain.
SectionEnd
