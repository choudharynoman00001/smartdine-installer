Option Explicit
Dim fso, sh, home, text, re, matches, version, action, cmd, i, http, ok
Set fso=CreateObject("Scripting.FileSystemObject")
Set sh=CreateObject("WScript.Shell")
home=fso.GetParentFolderName(fso.GetParentFolderName(WScript.ScriptFullName))
If WScript.Arguments.Count<>1 Then WScript.Quit 1
action=WScript.Arguments(0)
If action<>"start" And action<>"stop" Then WScript.Quit 1
If action="stop" Then
 cmd="powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -File """ & home & "\entry\process-state.ps1"" -Root """ & home & """ -Recover -Stop"
 WScript.Quit sh.Run(cmd,0,True)
End If
text=fso.OpenTextFile(home & "\selected.json",1).ReadAll
Set re=New RegExp
re.Pattern="""version""\s*:\s*""([a-f0-9]{64})"""
Set matches=re.Execute(text)
If matches.Count<>1 Then WScript.Quit 1
version=matches(0).SubMatches(0)
cmd="""" & home & "\versions\" & version & "\node\node.exe"" """ & home & "\entry\launch-selected.mjs"" """ & home & """ " & action
If action="stop" Then
 WScript.Quit sh.Run(cmd,0,True)
Else
 sh.Run cmd,0,False
 ok=False
 For i=1 To 50
  If fso.FileExists(home & "\private\ready.json") Then
   On Error Resume Next
   Set http=CreateObject("MSXML2.ServerXMLHTTP.6.0")
   http.setTimeouts 1000,1000,1000,1000
   http.Open "GET","http://127.0.0.1:8081/api/setup",False
   http.Send
   If Err.Number=0 And http.Status=200 Then ok=True
   Err.Clear
   On Error GoTo 0
   If ok Then Exit For
  End If
  WScript.Sleep 1000
 Next
 If ok Then
  sh.Run "http://127.0.0.1:8081/",1,False
 Else
  MsgBox "SmartDine PostgreSQL did not confirm startup. Preserve data and inspect private logs.",48,"SmartDine PostgreSQL"
  WScript.Quit 1
 End If
End If
