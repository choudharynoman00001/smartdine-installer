param([Parameter(Mandatory)][string]$Root,[switch]$Uninstall)
$ErrorActionPreference='Stop'
if($Root -notmatch '^[A-Za-z]:\\(?:[A-Za-z0-9 _-]+\\)*[A-Za-z0-9 _-]+$' -or $Root.EndsWith(' ') -or $Root.EndsWith('.')){throw 'dedicated local path required'}
if(!(Test-Path -LiteralPath $Root)){exit 0}
$current=(Get-Item -LiteralPath $Root).FullName
while($current){$part=$current;if(((Get-Item -LiteralPath $part).Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0){throw 'linked root refused'};$parent=[IO.Directory]::GetParent($current);if($parent){$parent=$parent.FullName};if($parent -eq $current){break};$current=$parent}
if(Test-Path -LiteralPath (Join-Path $Root 'app\data\smartdine.db')){throw 'SQLite root refused'}
$marker=Join-Path $Root 'smartdine-pg-install.json'
if(!(Test-Path -LiteralPath $marker)){if(@(Get-ChildItem -LiteralPath $Root -Force).Count -ne 0){throw 'foreign nonempty root refused'};exit 0}
$m=Get-Content -LiteralPath $marker -Raw | ConvertFrom-Json
if($m.product -ne 'SmartDine PostgreSQL' -or $m.layout -ne 1){throw 'ownership marker mismatch'}
& (Join-Path $PSScriptRoot 'process-state.ps1') -Root $Root -Recover
if($LASTEXITCODE -ne 0){throw 'process ownership recovery refused'}
# Refuse any exact executable under this install root; do not stop other apps.
$prefix=$Root.TrimEnd('\')+'\'
foreach($p in Get-CimInstance Win32_Process){if($p.ExecutablePath -and $p.ExecutablePath.StartsWith($prefix,[StringComparison]::OrdinalIgnoreCase)){throw 'installed process running; no payload changes'}}
exit 0
