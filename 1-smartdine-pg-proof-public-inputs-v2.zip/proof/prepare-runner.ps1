# SOURCE ONLY. Bounded ephemeral runner preparation, no release/artifact publication.
param([Parameter(Mandatory)][string]$Source,[Parameter(Mandatory)][string]$Work)
$ErrorActionPreference='Stop'
if($env:GITHUB_ACTIONS -ne 'true' -or $env:RUNNER_OS -ne 'Windows'){throw 'disposable Windows Actions only'}
if(Test-Path -LiteralPath $Work){throw 'new work directory required'}
New-Item -ItemType Directory $Work|Out-Null
$inputs=@(
 @{name='node';url='https://nodejs.org/dist/v22.23.4/node-v22.23.4-win-x64.zip';sha='cbc74b5e0982c9dbb41525fd8fb5dcd32fbee237863f7829072f4639a1ce5f20'},
 @{name='pgsql';url='https://get.enterprisedb.com/postgresql/postgresql-17.11-5-windows-x64-binaries.zip';sha='80379b2c04d51c30225532e0ae04509899141e9957ed096fe749d7fd9df8f82f'}
)
$lock=@{format='smartdine-pg-vendor-lock-v1';pgMajor=17;inputs=@()}
foreach($i in $inputs){$file=Join-Path $Work ($i.name+'.zip');Invoke-WebRequest -UseBasicParsing -Uri $i.url -OutFile $file -TimeoutSec 180;if((Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash.ToLowerInvariant() -ne $i.sha){throw 'vendor pin mismatch'};$lock.inputs+=@{name=$i.name;archivePath=$file;archiveSha256=$i.sha;sourceUrl=$i.url;noticesInspected=$true}}
# npm is build tooling only. Setup payload includes official Node executable not npm.
Push-Location (Join-Path $Source 'app')
try{& npm.cmd ci --omit=dev --ignore-scripts --no-audit --no-fund;if($LASTEXITCODE -ne 0){throw 'locked production install failed'}}finally{Pop-Location}
$deps=Join-Path $Work 'deps.tar.gz'
& python -c 'import tarfile,sys; t=tarfile.open(sys.argv[1],"w:gz"); t.add(sys.argv[2],arcname="."); t.close()' $deps (Join-Path $Source 'app\node_modules')
if($LASTEXITCODE -ne 0){throw 'dependency archive failed'}
& node (Join-Path $PSScriptRoot 'check-notices.mjs') (Join-Path $Source 'app\node_modules')
if($LASTEXITCODE -ne 0){throw 'dependency notice inventory failed'}
$lock.inputs+=@{name='node_modules';archivePath=$deps;archiveSha256=(Get-FileHash -LiteralPath $deps -Algorithm SHA256).Hash.ToLowerInvariant();sourceUrl='https://registry.npmjs.org/';provenance='production dependency archive assembled by npm ci from app/package-lock.json individual resolved URLs and integrity pins';noticesInspected=$true}
$lockFile=Join-Path $Work 'inputs.json';$lock|ConvertTo-Json -Depth 8|Set-Content -LiteralPath $lockFile -Encoding ASCII
$env:SMARTDINE_BUILD_PYTHON=(Get-Command python.exe -ErrorAction Stop).Source
& node (Join-Path $Source 'windows\build-stage.mjs') $lockFile (Join-Path $Work 'stage')
if($LASTEXITCODE -ne 0){throw 'runner stage failed'}
# Never upload Work: vendor bytes, dependency cache and later synthetic private config live here.

exit 0
