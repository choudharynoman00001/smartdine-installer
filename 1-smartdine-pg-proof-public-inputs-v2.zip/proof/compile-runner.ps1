# SOURCE ONLY. Portable official compiler, no admin install or arbitrary package manager.
param([Parameter(Mandatory)][string]$Source,[Parameter(Mandatory)][string]$Stage,[Parameter(Mandatory)][string]$Work)
$ErrorActionPreference='Stop'
if($env:GITHUB_ACTIONS -ne 'true' -or $env:RUNNER_OS -ne 'Windows'){throw 'ephemeral Windows Actions only'}
$inputLock=Get-Content (Join-Path $PSScriptRoot 'nsis-input.json') -Raw|ConvertFrom-Json
$archive=Join-Path $Work 'nsis.zip'
try{Invoke-WebRequest -UseBasicParsing -Uri $inputLock.sourceUrl -OutFile $archive -TimeoutSec 90}catch{
 $status=0;if($_.Exception.Response -and $_.Exception.Response.StatusCode){$status=[int]$_.Exception.Response.StatusCode}
 @{format='smartdine-tool-download-v1';tool='nsis';category='HTTP_DOWNLOAD_FAILED';status=$status}|ConvertTo-Json -Compress|Write-Output
 throw 'compiler download failed'
}
$actualSha=(Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash.ToLowerInvariant()
$actualBytes=(Get-Item -LiteralPath $archive).Length
$stream=[IO.File]::OpenRead($archive);try{$magic=New-Object byte[] 4;[void]$stream.Read($magic,0,4)}finally{$stream.Dispose()}
# Safe diagnostics only: no response body, headers, signed redirect query or raw exception.
if($actualSha -ne $inputLock.sha256 -or $actualBytes -ne $inputLock.bytes){
 @{format='smartdine-tool-pin-v1';tool='nsis';bytes=$actualBytes;sha256=$actualSha;magic=([BitConverter]::ToString($magic)).Replace('-','').ToLowerInvariant();classification=if($magic[0] -eq 80 -and $magic[1] -eq 75 -and $magic[2] -eq 3 -and $magic[3] -eq 4){'ZIP_HEADER'}else{'OTHER_HEADER'}}|ConvertTo-Json -Compress|Write-Output
 throw 'compiler pin mismatch'
}
Expand-Archive -LiteralPath $archive -DestinationPath (Join-Path $Work 'compiler')
$compiler=Join-Path $Work 'compiler\nsis-3.11\makensis.exe'
# Check actual source parse in both native shells before compiling anything.
foreach($shell in @("$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe",(Get-Command pwsh.exe -ErrorAction Stop).Source)){
 & $shell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot 'parse-probe.ps1') -Source $Source
 if($LASTEXITCODE -ne 0){throw 'native PowerShell source parse failed'}
}
Push-Location (Join-Path $Source 'windows')
try{
 & $compiler /V2 (('/DPAYLOAD_STAGE='+$Stage)) installer.nsi
 if($LASTEXITCODE -ne 0){throw 'NSIS compile failed'}
 Move-Item -LiteralPath SmartDinePG-Setup.exe -Destination (Join-Path $Work 'SmartDinePG-Setup.exe')
}finally{Pop-Location}
# Compiler and EXE remain ephemeral Work, never uploaded or published.

exit 0
