# SOURCE ONLY. No blanket transcript. Explicit evidence fields only.
param([Parameter(Mandatory)][string]$Stage,[Parameter(Mandatory)][string]$Evidence,[Parameter(Mandatory)][string]$Installer)
$ErrorActionPreference='Stop'
if($env:GITHUB_ACTIONS -ne 'true' -or $env:RUNNER_OS -ne 'Windows'){throw 'ephemeral Windows Actions only'}
if(Test-Path -LiteralPath $Evidence){throw 'new evidence directory required'}
New-Item -ItemType Directory $Evidence|Out-Null
$phase='preflight';$script:lastReason=$null
$results=[Collections.Generic.List[object]]::new()
function Note([string]$phase,[string]$status){$results.Add(@{phase=$phase;status=$status})}
function Run([string]$exe,[string[]]$argv,[int]$seconds=120){
 # .NET process argument quoting for supported paths, no shell prose.
 $p=New-Object Diagnostics.Process;$p.StartInfo.FileName=$exe
 $p.StartInfo.Arguments=($argv|ForEach-Object{if($_.StartsWith('/D=') -or $_.StartsWith('_?=')){$_}else{'"'+($_ -replace '(\\*)"','$1$1\"' -replace '(\\+)$','$1$1')+'"'}}) -join ' '
 $p.StartInfo.UseShellExecute=$false;$p.StartInfo.CreateNoWindow=$true
 $p.StartInfo.RedirectStandardOutput=$true;$p.StartInfo.RedirectStandardError=$true
 [void]$p.Start();$out=$p.StandardOutput.ReadToEndAsync();$err=$p.StandardError.ReadToEndAsync()
 if(!$p.WaitForExit($seconds*1000)){$p.Kill();throw 'bounded child timeout'}
 $out.Wait();$err.Wait();$script:lastReason=$null;foreach($line in (($out.Result+"`n"+$err.Result) -split "`r?`n")){try{$v=$line|ConvertFrom-Json -ErrorAction Stop;if($v.format -eq 'smartdine-refusal-v1' -and $v.reason -in @('PAYLOAD_EXTRA_FILE','STARTUP_IN_PROGRESS','FOREIGN_PORT_OCCUPIED','LIFECYCLE_UNVERIFIED')){$script:lastReason=$v.reason}}catch{}};$code=$p.ExitCode;$p.Dispose()
 # Output intentionally discarded: lifecycle error text must not leak private context.
 return $code
}
$epochDeltas=[Collections.Generic.List[long]]::new()
$node=Join-Path $Stage 'node\node.exe';$activate=Join-Path $Stage 'windows\activate.mjs'
$roots=@((Join-Path $env:LOCALAPPDATA 'SmartDinePG'),(Join-Path ([IO.Path]::GetPathRoot($env:RUNNER_TEMP)) 'SmartDine PG Synthetic'))
try{
 foreach($root in $roots){if(Test-Path -LiteralPath $root){throw 'existing install target refused'}}
 foreach($port in @(8081,15432)){if(Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue){throw 'occupied port preserved'}}
 foreach($root in $roots){
  $phase='fresh-installer'
  if((Run $Installer @('/S',('/D='+$root)) 180) -ne 0){throw 'fresh installer refused'};Note 'fresh-activation' 'PASS'
  $phase='bound-start';$launch=Join-Path $root 'entry\launcher.vbs'
  $phase='bound-start';if((Run "$env:SystemRoot\System32\cscript.exe" @('//nologo',$launch,'start') 75) -ne 0){throw 'bound startup refused'}
  if(!(Test-Path -LiteralPath (Join-Path $root 'private\ready.json'))){throw 'ready identity absent'};Note 'bound-start' 'PASS'
  $phase='PG-epoch';$pgpid=Get-Content -LiteralPath (Join-Path $root 'private\pgdata\postmaster.pid');$pgproc=Get-CimInstance Win32_Process -Filter ('ProcessId='+[int]$pgpid[0]) -ErrorAction Stop
  $delta=[Math]::Abs(([DateTimeOffset]([DateTime]$pgproc.CreationDate)).ToUnixTimeSeconds()-[long]$pgpid[2]);if($delta -gt 3){throw 'PG creation epoch tolerance mismatch'};$epochDeltas.Add([long]$delta);Note 'PG-epoch-CIM-tolerance' 'PASS'
  $phase='owned-stop';if((Run "$env:SystemRoot\System32\cscript.exe" @('//nologo',$launch,'stop') 90) -ne 0){throw 'owned stop refused'};Note 'stop' 'PASS'
  $phase='retained-installer';$before=Get-Content -LiteralPath (Join-Path $root 'private\state.json') -Raw|ConvertFrom-Json
  if((Run $Installer @('/S',('/D='+$root)) 180) -ne 0){throw 'retained installer refused'}
  $after=Get-Content -LiteralPath (Join-Path $root 'private\state.json') -Raw|ConvertFrom-Json
  if($before.sourceId -ne $after.sourceId -or !(Get-ChildItem -LiteralPath (Join-Path $root 'private') -Filter 'preupgrade-*.sdpg')){throw 'retained UUID/backup proof absent'};Note 'retained-activation' 'PASS'
 }
 # Finite adversarial probes on synthetic default root only.
 $root=$roots[0];$launch=Join-Path $root 'entry\launcher.vbs';$private=Join-Path $root 'private'
 $selected=Get-Content (Join-Path $root 'selected.json') -Raw|ConvertFrom-Json
 $payload=Join-Path $root ('versions\'+$selected.version)
 $phase='PS51-PS7-process-probes';$psScript=Join-Path $payload 'windows\process-state.ps1'
 $probe=Join-Path $PSScriptRoot 'process-probe.ps1'
 foreach($shell in @("$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe",(Get-Command pwsh.exe -ErrorAction Stop).Source)){
  $pr=Join-Path $env:RUNNER_TEMP ('SDProbe-'+[guid]::NewGuid().ToString('N'))
  if((Run $shell @('-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',$probe,'-Script',$psScript,'-Root',$pr) 45) -ne 0){throw 'PS identity probe refused'}
 };Note 'PS51-PS7-dead-record-explicit-success' 'PASS'
 $phase='extra-DLL-refusal';$extra=Join-Path $payload 'node\proof-extra.dll';[IO.File]::WriteAllText($extra,'synthetic not executable')
 if((Run $node @((Join-Path $payload 'windows\supervisor.mjs'),'start',$root) 30) -ne 21 -or $script:lastReason -ne 'PAYLOAD_EXTRA_FILE'){throw 'extra DLL not refused'}
 Remove-Item -LiteralPath $extra;Note 'DLL-injection' 'PASS'
 $phase='damaged-payload-stop';if((Run "$env:SystemRoot\System32\cscript.exe" @('//nologo',$launch,'start') 75) -ne 0){throw 'start before damage failed'}
 # Damage manifest bytes only after a running owned supervisor is established.
 $manifest=Join-Path $payload 'payload-manifest.json';$saved=[IO.File]::ReadAllBytes($manifest)
 try{[IO.File]::WriteAllText($manifest,'damaged synthetic');if((Run "$env:SystemRoot\System32\cscript.exe" @('//nologo',$launch,'stop') 90) -ne 0){throw 'stop depended on healthy payload'}}finally{[IO.File]::WriteAllBytes($manifest,$saved)}
 Note 'payload-stop-bypass' 'PASS'
 # Actual live supervisor ownership is checked by stop already. Additional concurrent launch must fail.
 $phase='concurrent-start-refusal';$first=New-Object Diagnostics.Process;$first.StartInfo.FileName=$node
 $first.StartInfo.Arguments='"'+(Join-Path $payload 'windows\supervisor.mjs')+'" start "'+$root+'"'
 $first.StartInfo.UseShellExecute=$false;$first.StartInfo.CreateNoWindow=$true;[void]$first.Start()
 try{
  $until=(Get-Date).AddSeconds(20);while(!(Test-Path (Join-Path $private 'start.lock')) -and !(Test-Path (Join-Path $private 'supervisor.pid')) -and (Get-Date) -lt $until){if($first.HasExited){throw 'first startup failed before overlap'};Start-Sleep -Milliseconds 50}
 $second=Run $node @((Join-Path $payload 'windows\supervisor.mjs'),'start',$root) 60
  if($second -ne 22 -or $script:lastReason -ne 'STARTUP_IN_PROGRESS'){throw 'concurrent launch wrongly accepted'}
  $until=(Get-Date).AddSeconds(55);while(!(Test-Path (Join-Path $private 'ready.json')) -and (Get-Date) -lt $until){if($first.HasExited){throw 'first startup lost race'};Start-Sleep -Milliseconds 250}
  if(!(Test-Path (Join-Path $private 'ready.json'))){throw 'concurrent startup never ready'}
  if((Run "$env:SystemRoot\System32\cscript.exe" @('//nologo',$launch,'stop') 90) -ne 0){throw 'concurrent first stop failed'}
  if(!$first.WaitForExit(15000)){throw 'first startup not stopped'}
 }finally{$first.Dispose()};Note 'doubleclick-refusal-live-identity' 'PASS'
 $phase='foreign-listener-refusal';$foreign=New-Object Diagnostics.Process;$foreign.StartInfo.FileName=$node
 $foreign.StartInfo.Arguments='"'+(Join-Path $PSScriptRoot 'foreign-listener.mjs')+'"'
 $foreign.StartInfo.UseShellExecute=$false;$foreign.StartInfo.CreateNoWindow=$true;[void]$foreign.Start()
 try{
  $until=(Get-Date).AddSeconds(10);while(!(Get-NetTCPConnection -LocalPort 8081 -State Listen -ErrorAction SilentlyContinue) -and (Get-Date) -lt $until){Start-Sleep -Milliseconds 100}
  if($foreign.HasExited){throw 'foreign synthetic listener failed'}
  if((Run $node @((Join-Path $payload 'windows\supervisor.mjs'),'start',$root) 45) -ne 23 -or $script:lastReason -ne 'FOREIGN_PORT_OCCUPIED'){throw 'foreign port adopted'}
  $foreign.Refresh();if($foreign.HasExited){throw 'foreign listener stopped by app'}
 }finally{if(!$foreign.HasExited){$foreign.Kill();$foreign.WaitForExit()};$foreign.Dispose()};Note 'foreign-listener-preserved' 'PASS'
 # Interrupted init is synthetic partial pendingtree, no business database deletion.
 $phase='interrupted-init-quarantine';$retry=Join-Path $env:RUNNER_TEMP ('SDRetry-'+[guid]::NewGuid().ToString('N'))
 New-Item -ItemType Directory (Join-Path $retry 'private.init')|Out-Null
 [IO.File]::WriteAllText((Join-Path $retry 'private.init\synthetic-canary'),'retained')
 # Fresh root marker required by lifecycle. Pendingtree is protected through native ACL helper.
 [IO.File]::WriteAllText((Join-Path $retry 'smartdine-pg-install.json'),'{"product":"SmartDine PostgreSQL","layout":1}')
 foreach($dir in @($retry,(Join-Path $retry 'private.init'))){if((Run 'powershell.exe' @('-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',(Join-Path $payload 'windows\private-acl.ps1'),'-Path',$dir,'-Set') 20) -ne 0){throw 'retry ACL failed'}}
 if((Run $node @((Join-Path $payload 'windows\supervisor.mjs'),'recover-init',$retry) 90) -ne 0){throw 'pending quarantine failed'}
 if(!(Get-ChildItem -LiteralPath $retry -Directory -Filter 'private.failed-*') -or (Test-Path (Join-Path $retry 'private.init'))){throw 'pending preservation not proved'}
 Note 'interrupted-init-quarantine' 'PASS'
 foreach($root in $roots){
  $phase='uninstall-retained-reinstall';$before=Get-Content (Join-Path $root 'private\state.json') -Raw|ConvertFrom-Json
  $dbVersion=Get-FileHash -LiteralPath (Join-Path $root 'private\pgdata\PG_VERSION') -Algorithm SHA256
  # _?= must be final token. Never remove private data after uninstall.
  if((Run (Join-Path $root 'Uninstall.exe') @('/S',('_?='+$root)) 90) -ne 0){throw 'uninstall refused'}
  if(!(Test-Path (Join-Path $root 'private\state.json')) -or (Test-Path (Join-Path $root 'versions'))){throw 'uninstall retention mismatch'}
  if((Get-FileHash -LiteralPath (Join-Path $root 'private\pgdata\PG_VERSION') -Algorithm SHA256).Hash -ne $dbVersion.Hash){throw 'uninstall changed retained PG identity'}
  if((Run $Installer @('/S',('/D='+$root)) 180) -ne 0){throw 'retained reinstall refused'}
  $after=Get-Content (Join-Path $root 'private\state.json') -Raw|ConvertFrom-Json
  if($after.sourceId -ne $before.sourceId){throw 'retained reinstall UUID changed'}
  Note 'NSIS-uninstall-retained-reinstall' 'PASS'
 }
 foreach($phase in @('actual-reboot','foreign-SYSTEM-pg')){Note $phase 'NOT_PROVED'}

}catch{Note $phase 'FAIL';throw 'native proof stopped; sanitized phase summary only'}finally{
 $summary=@{format='smartdine-pg-proof-v1';results=@($results);nativeCompleted=$false;failingPhase=if(@($results|Where-Object status -eq 'FAIL').Count){$phase}else{$null};pgEpochDeltaSeconds=@($epochDeltas)}
 $json=$summary|ConvertTo-Json -Depth 5
 if($json -match '(?i)postgres:|password|connectionString|BEGIN.*PRIVATE KEY'){throw 'unsafe evidence refused'}
 [IO.File]::WriteAllText((Join-Path $Evidence 'evidence-summary.json'),$json)
 # No namekill/delete cleanup. Private synthetic runner state remains until ephemeral runner destruction.
}
