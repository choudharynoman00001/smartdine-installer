param([Parameter(Mandatory)][string]$Script,[Parameter(Mandatory)][string]$Root)
$ErrorActionPreference='Stop'
if(Test-Path -LiteralPath $Root){throw 'new probe root required'}
New-Item -ItemType Directory (Join-Path $Root 'private')|Out-Null
& $Script -Root $Root -Recover
if($LASTEXITCODE -ne 0){throw 'explicit success failed'}
# A deliberately impossible PID is provably dead, never targets an actual process.
$r=@{pid=2147483647;startedTicks='1';exe='C:\never\node.exe';script='C:\never\supervisor.mjs'}
$r|ConvertTo-Json|Set-Content (Join-Path $Root 'private\supervisor.pid') -Encoding ASCII
& $Script -Root $Root -Recover
if($LASTEXITCODE -ne 0 -or (Test-Path (Join-Path $Root 'private\supervisor.pid'))){throw 'dead record not recovered'}
# Separate child invocation established PInvoke/CIM/normal exit, no actual PG epoch claim.
exit 0
