param([Parameter(Mandatory)][string]$Source)
$ErrorActionPreference='Stop'
foreach($f in Get-ChildItem -LiteralPath $Source -Filter *.ps1 -Recurse){$t=$null;$e=$null;[Management.Automation.Language.Parser]::ParseFile($f.FullName,[ref]$t,[ref]$e)|Out-Null;if($e.Count){throw 'PowerShell source parse failed'}}
exit 0
