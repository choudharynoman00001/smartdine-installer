// Synthetic child, no private state. Runner owns exact Process handle.
import http from 'node:http';const s=http.createServer((q,r)=>{r.writeHead(200,{'content-type':'application/json'});r.end('{"synthetic":true}');});s.listen(8081,'127.0.0.1');
