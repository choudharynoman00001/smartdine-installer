import {AccountLogin} from './account-login.mjs';
import {writeOperatingShift} from './operating-shifts.mjs';
import {firstOwner} from './operating-onboarding.mjs';
// Loopback developer integration harness. No production listener/start command.
import {createActiveListener} from './active-listener.mjs';import {openRefreshStream} from './events.mjs';import {mergeOrders,splitOrder} from './merge-split.mjs';import {staffWrite} from './staff.mjs';import {updateSettings,createTable} from './settings.mjs';import {exportReport} from './reports-export.mjs';import {cancelOrder,discountOrder,moveOrder} from './order-ops.mjs';import {cashReport,cashCount} from './cash.mjs';import {updateIngredient,removeRecipe} from './inventory.mjs';import {catalogWrite} from './catalog.mjs';import {menuModel,orderList,numericRows} from './read-model.mjs';import crypto from 'node:crypto';import http from 'node:http';import {PostgresPinLogin} from './login.mjs';import {RestaurantRepository} from './repository.mjs';import {PostgresSessionStore} from './sessions.mjs';
export function createPostgresApi(pool,{loginKey,activeTls,backupProvider,staticHandler}={}){
 const repo=new RestaurantRepository(pool),sessions=new PostgresSessionStore(pool),login=loginKey?(staticHandler?new AccountLogin(pool,{bucketKey:loginKey}):new PostgresPinLogin(pool,{bucketKey:loginKey})):null;let loginReady;repo.securePolicy=!!staticHandler;
 const handler=async(req,res)=>{
  if(!req.url.startsWith('/api/')){if(staticHandler)return staticHandler(req,res);res.writeHead(404);return res.end();}
  const send=(code,data)=>{res.writeHead(code,{'content-type':'application/json','cache-control':'no-store','x-content-type-options':'nosniff'});res.end(JSON.stringify(data));};
  try{
   if(!staticHandler){const production=(await pool.query("SELECT to_regclass('smartdine_restaurant.operating_migrations') relation")).rows[0].relation;if(production)return send(503,{error:'Operating database requires the guarded operating entry; harness refused'});}
   // An analytical target contains copied table QR tokens but is NEVER an active
   // restaurant API. Refuse before public QR or credential/session routes.
   const replicaSchema=(await pool.query("SELECT to_regclass('smartdine_restaurant.replica_state') relation")).rows[0].relation;
   if(replicaSchema&&(await pool.query('SELECT 1 FROM smartdine_restaurant.replica_state WHERE id=1')).rowCount)return send(503,{error:'analytical replica is not an active restaurant server'});
   if(req.url==='/api/language'&&req.method==='GET'){const r=(await pool.query('SELECT default_language FROM smartdine_restaurant.restaurants WHERE id=1')).rows[0];return send(200,{default_language:r?.default_language||'en'});}
   if(req.url==='/api/setup'&&req.method==='GET')return send(200,{setup_required:Number((await pool.query('SELECT count(*) n FROM smartdine_restaurant.users')).rows[0].n)===0});
   if(req.url==='/api/setup'&&req.method==='POST'){
    if(!['127.0.0.1','::1','::ffff:127.0.0.1'].includes(req.socket.remoteAddress)||req.headers['forwarded']||req.headers['x-forwarded-for']||req.headers['x-real-ip'])return send(403,{error:'setup requires direct local access'});
    let size=0,chunks=[];for await(const chunk of req){size+=chunk.length;if(size>4096)return send(413,{error:'body too large'});chunks.push(chunk);}let b;try{b=JSON.parse(Buffer.concat(chunks));}catch{return send(400,{error:'invalid JSON'});}const result=await firstOwner(repo,b);if(result.token)res.setHeader('set-cookie','sd_session='+result.token+'; HttpOnly; SameSite=Strict; Path=/; Max-Age=43200');const {status,...data}=result;return send(status,data);
   }
   if(req.url==='/api/auth/login'&&req.method==='POST'){
    if(!login)return send(503,{error:'login key configuration required'});
    let size=0,chunks=[];for await(const chunk of req){size+=chunk.length;if(size>2048)return send(413,{error:'login body too large'});chunks.push(chunk);}let body;try{body=JSON.parse(Buffer.concat(chunks).toString('utf8'));}catch{return send(400,{error:'invalid JSON'});}
    loginReady??=login.initialize();await loginReady;const result=await login.login(body?.pin,req.socket.remoteAddress,body?.login_id);
    if(result.status===200)res.setHeader('set-cookie','sd_session='+result.token+'; HttpOnly; SameSite=Strict; Path=/; Max-Age=43200');
    const {status,...data}=result;return send(status,data);
   }
   const url=new URL(req.url,'http://localhost');
   const qr=url.pathname.match(/^\/api\/qr\/([a-f0-9]{32})(?:\/(orders)(?:\/([a-f0-9-]{36}))?)?$/);
   if(qr){
    const {rows:[table]}=await pool.query('SELECT id,label,floor FROM smartdine_restaurant.restaurant_tables WHERE qr_token=$1',[qr[1]]);if(!table)return send(404,{error:'table not found'});
    if(req.method==='GET'&&!qr[2]){
      const settings=(await pool.query('SELECT name,currency FROM smartdine_restaurant.restaurants WHERE id=1')).rows[0];
      const cats=(await pool.query('SELECT id,name_en,name_ur FROM smartdine_restaurant.categories ORDER BY sort,id')).rows;
      const items=(await pool.query('SELECT id,category_id,name_en,name_ur,description,price,photo FROM smartdine_restaurant.menu_items WHERE available=1 ORDER BY id')).rows;
      return send(200,{restaurant:settings,table:{label:table.label,floor:table.floor},categories:cats.map(c=>({...c,id:Number(c.id),items:items.filter(i=>i.category_id===c.id).map(i=>({...i,id:Number(i.id),price:Number(i.price)}))}))});
    }
    if(req.method==='GET'&&qr[2]){
      let receipts;try{receipts=JSON.parse(req.headers['x-smartdine-receipts']||'[]');}catch{return send(400,{error:'invalid receipts'});}
      if(!Array.isArray(receipts)||receipts.length>20||receipts.some(r=>!r||typeof r.id!=='string'||!/^[a-f0-9-]{36}$/.test(r.id)||typeof r.receipt!=='string'||!/^[a-f0-9]{64}$/.test(r.receipt)))return send(400,{error:'invalid receipts'});
      const orders=[];for(const receipt of receipts){if(qr[3]&&qr[3]!==receipt.id)continue;
       const o=(await pool.query("SELECT id,status,created_at,qr_receipt_hash FROM smartdine_restaurant.orders WHERE id=$1 AND table_id=$2 AND source='qr' AND created_at>=$3",[receipt.id,table.id,Date.now()-12*3600000])).rows[0];const hash=crypto.createHash('sha256').update('smartdine-qr-receipt-v1\0'+qr[1]+'\0'+receipt.receipt).digest('hex');
       if(!o?.qr_receipt_hash||!crypto.timingSafeEqual(Buffer.from(hash,'hex'),Buffer.from(o.qr_receipt_hash,'hex')))continue;
       delete o.qr_receipt_hash;o.created_at=Number(o.created_at);o.items=(await pool.query('SELECT name_snapshot name,qty FROM smartdine_restaurant.order_items WHERE order_id=$1 ORDER BY id',[o.id])).rows.map(i=>({...i,qty:Number(i.qty)}));orders.push(o);
      }
      if(qr[3])return orders.length?send(200,{order:orders[0]}):send(404,{error:'order not found'});
      return send(200,{table:table.label,orders});
    }
    if(req.method==='POST'&&qr[2]&&!qr[3]){
      let size=0,chunks=[];for await(const chunk of req){size+=chunk.length;if(size>131072)return send(413,{error:'body too large'});chunks.push(chunk);}let body;try{body=JSON.parse(Buffer.concat(chunks).toString('utf8'));}catch{return send(400,{error:'invalid JSON'});}
      if(!body||typeof body!=='object'||Array.isArray(body))return send(400,{error:'object body required'});
      if(typeof body.qr_receipt!=='string'||!/^[a-f0-9]{64}$/.test(body.qr_receipt))return send(400,{error:'private QR receipt required'});
      if(typeof body.idempotency_key!=='string'||!body.idempotency_key||body.idempotency_key.length>64)return send(400,{error:'idempotency key required, at most64 characters'});
      if(body.order_type&&body.order_type!=='dine-in')return send(400,{error:'QR orders are dine-in'});
      const order=await repo.createOrder({source:'qr',tableId:Number(table.id),idempotencyKey:'t'+table.id+':'+body.idempotency_key,items:Array.isArray(body.items)?body.items.map(i=>i&&({menuItemId:i.menu_item_id,qty:i.qty,expectedPrice:i.expected_unit_price,notes:i.notes})):null,note:body.note,actorName:'customer (QR)',qrReceiptHash:crypto.createHash('sha256').update('smartdine-qr-receipt-v1\0'+qr[1]+'\0'+body.qr_receipt).digest('hex')});
      // Do not return full staff order/customer/payment records to public clients.
      const saved=await repo.getOrder(order.id);return send(order.deduped?200:201,{order:{id:saved.id,status:saved.status,created_at:Number(saved.created_at),total:Number(saved.total),items:saved.items.map(i=>({name:i.name_snapshot,qty:Number(i.qty)}))},...(order.deduped?{deduped:true}:{})});
    }
    return send(404,{error:'not found'});
   }
   if(url.pathname.startsWith('/api/qr/'))return send(404,{error:'not found'});
   const bearer=String(req.headers.authorization||'');const token=bearer.startsWith('Bearer ')?bearer.slice(7):(/(?:^|;\s*)sd_session=([a-f0-9]{48})(?:;|$)/.exec(req.headers.cookie||'')?.[1]||'');const user=await sessions.get(token);if(!user)return send(401,{error:'unauthorized'});
   // Local assignments are checked per route; unknown roles fail closed.
   if(!['owner','manager','cashier','kitchen','waiter'].includes(user.role))return send(403,{error:'role not supported by this partial adapter'});
   const u=new URL(req.url,'http://localhost');let body={};
   if(['POST','PUT'].includes(req.method)){let bytes=0,chunks=[];for await(const chunk of req){bytes+=chunk.length;if(bytes>131072)return send(413,{error:'body too large'});chunks.push(chunk);}try{body=JSON.parse(Buffer.concat(chunks).toString('utf8'));}catch{return send(400,{error:'invalid JSON'});}}
   if(!body||typeof body!=='object'||Array.isArray(body))return send(400,{error:'object body required'});
   if(req.url==='/api/auth/me'&&req.method==='GET')return send(200,{user:{id:user.userId,name:user.name,role:user.role,...(staticHandler?{credential_upgrade_required:!(await pool.query('SELECT elevated_pin_ready FROM smartdine_restaurant.users WHERE id=$1',[user.userId])).rows[0]?.elevated_pin_ready}:{})}});
   if(req.url==='/api/auth/logout'&&req.method==='POST'){await sessions.revoke(token);res.setHeader('set-cookie','sd_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0');return send(200,{ok:true});}
   if(staticHandler&&u.pathname!=='/api/auth/me'&&u.pathname!=='/api/auth/pin'&&u.pathname!=='/api/auth/change-pin'&&u.pathname!=='/api/auth/logout'){const credential=(await pool.query('SELECT elevated_pin_ready FROM smartdine_restaurant.users WHERE id=$1',[user.userId])).rows[0];if(!credential?.elevated_pin_ready)return send(428,{error:'Legacy short PIN needs an explicit 6-8 digit PIN change in My PIN before privileged work. Existing PIN was not changed.'});}
   if(u.pathname==='/api/operations/remote-menu'&&req.method==='GET'){if(user.role!=='owner')return send(403,{error:'owner required'});return send(200,{configured:false,policy:null,status:{state:'not_configured'},notice:'Not configured in this PostgreSQL operating build'});}
   if(u.pathname==='/api/operations/status'&&req.method==='GET'){
    if(user.role!=='owner')return send(403,{error:'owner required'});
    const triggers=Number((await pool.query("SELECT count(*) n FROM pg_trigger t JOIN pg_class c ON c.oid=t.tgrelid JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname='smartdine_restaurant' AND t.tgname='smartdine_capture' AND t.tgenabled='O' AND NOT t.tgisinternal")).rows[0].n);
    return send(200,{mode:staticHandler?'postgres_single_authority':'normalized_private_backend_harness',transport:req.socket.encrypted?'https':'http_loopback',capture:{triggers,expected_triggers:14,configured:triggers===14,scope:'trigger_name_count_only'},cloud_deployment:'not_configured_by_this_build',analytical_transport:'developer_harness_not_installed',active_cloud_failover:false,physical_pilot:'not_certified',backup:{download_supported:!!backupProvider,method:backupProvider?'postgres_operator_envelope':'operator_pg_backup_required'},warnings:['Trigger counts do not prove trigger body integrity or a current remote copy.','PostgreSQL backup is an operator-managed workflow, not a SQLite file download.',staticHandler?'Private PostgreSQL operating candidate; no deployment certification.':'This harness is not a deployed restaurant service.']});
   }
   if(u.pathname==='/api/backup'&&req.method==='GET'){if(user.role!=='owner')return send(403,{error:'owner required'});if(!backupProvider)return send(501,{error:'operator backup not configured'});let bytes;try{bytes=await backupProvider();}catch{return send(503,{error:'PostgreSQL backup could not be prepared. Ask the operator to check the private snapshot-reader permissions, source identity, pg_dump availability and size limit; no download was confirmed.'});}res.writeHead(200,{'content-type':'application/octet-stream','cache-control':'no-store','content-disposition':'attachment; filename=smartdine-postgres-backup.sdpg'});return res.end(bytes);}
   if(u.pathname.startsWith('/api/menu/')&&['POST','PUT'].includes(req.method)){const {status,result,error}=await catalogWrite(repo,{path:u.pathname,method:req.method,body,user});return send(status,error?{error}:{result:numericRows(result)});}
   if(u.pathname==='/api/events'&&req.method==='GET')return await openRefreshStream(pool,sessions,token,res);
   if(u.pathname==='/api/staff-shifts'||/^\/api\/staff-shifts\/[0-9a-f-]+$/i.test(u.pathname)){
    if(!['owner','manager'].includes(user.role))return send(403,{error:'manager required'});
    if(u.pathname==='/api/staff-shifts'&&req.method==='GET')return send(200,{scope:'installation-local',shifts:(await pool.query('SELECT s.*,u.name staff_name FROM smartdine_restaurant.local_staff_shifts s JOIN smartdine_restaurant.users u ON u.id=s.user_id ORDER BY s.starts_at DESC,s.id')).rows.map(numericRows),staff:(await pool.query('SELECT id,name,role,active FROM smartdine_restaurant.users ORDER BY name,id')).rows.map(numericRows)});
    if(req.method==='POST'&&u.pathname==='/api/staff-shifts'||req.method==='PUT'&&u.pathname!=='/api/staff-shifts'){const {status,...result}=await writeOperatingShift(repo,{id:req.method==='POST'?body.id:u.pathname.split('/').pop(),body,user,update:req.method==='PUT'});return send(status,result);}
   }
   if(u.pathname==='/api/users'&&req.method==='GET'){if(user.role!=='owner')return send(403,{error:'owner required'});return send(200,{users:(await pool.query(`SELECT id,name,role,active${staticHandler?',login_id':''} FROM smartdine_restaurant.users ORDER BY id`)).rows.map(numericRows)});}
   if((u.pathname.startsWith('/api/users')||u.pathname==='/api/auth/pin'||u.pathname==='/api/auth/change-pin')&&['POST','PUT'].includes(req.method)){
    const {status,result,error}=await staffWrite(repo,{path:u.pathname==='/api/auth/change-pin'?'/api/auth/pin':u.pathname,method:u.pathname==='/api/auth/change-pin'?'PUT':req.method,body:u.pathname==='/api/auth/change-pin'?{current_pin:body.current_pin,new_pin:body.pin}:body,user});if(staticHandler&&!error&&status===200&&u.pathname.startsWith('/api/users/')){const id=Number(u.pathname.split('/')[3]);const row=(await pool.query('SELECT login_id FROM smartdine_restaurant.users WHERE id=$1',[id])).rows[0];if(row)await login.unlock(row.login_id);}return send(status,error?{error}:{user:numericRows(result)});
   }
   if(u.pathname==='/api/reports/export.csv'&&req.method==='GET'){
    if(!['owner','manager','cashier'].includes(user.role))return send(403,{error:'finance role required'});const type=u.searchParams.get('type')||'orders';const csv=await exportReport(repo,type);res.writeHead(200,{'content-type':'text/csv; charset=utf-8','cache-control':'no-store','content-disposition':'attachment; filename="smartdine-'+type+'.csv"'});return res.end(csv);
   }
   if(u.pathname==='/api/settings'&&req.method==='PUT'){if(user.role!=='owner')return send(403,{error:'owner required'});return send(200,{settings:numericRows(await updateSettings(repo,body,user))});}
   if(u.pathname==='/api/tables'&&req.method==='POST'){if(!['owner','manager'].includes(user.role))return send(403,{error:'manager required'});return send(201,{table:numericRows(await createTable(repo,body,user))});}
   if(u.pathname==='/api/audit'&&req.method==='GET'){if(!['owner','manager'].includes(user.role))return send(403,{error:'manager required'});return send(200,{logs:(await pool.query('SELECT id,actor_name,action,detail,at FROM smartdine_restaurant.audit_logs ORDER BY id DESC LIMIT 300')).rows.map(numericRows)});}
   if(u.pathname==='/api/menu'&&req.method==='GET')return send(200,{categories:await menuModel(pool)});
   if(u.pathname==='/api/settings'&&req.method==='GET')return send(200,{settings:numericRows((await pool.query('SELECT r.name,r.currency,r.tax_percent,r.service_charge_percent,r.default_language,i.instance_id database_id FROM smartdine_restaurant.restaurants r CROSS JOIN smartdine_restaurant.runtime_identity i WHERE r.id=1 AND i.id=1')).rows[0]||{})});
   if(u.pathname==='/api/orders'&&req.method==='GET')return send(200,{orders:await orderList(pool,user,{status:u.searchParams.get('status')||undefined})});
   if(u.pathname.startsWith('/api/inventory/')&&!['owner','manager'].includes(user.role))return send(403,{error:'manager required'});
   const ingredientEdit=u.pathname.match(/^\/api\/inventory\/ingredients\/(\d+)$/);
   if(ingredientEdit&&req.method==='PUT')return send(200,{ingredient:await updateIngredient(repo,Number(ingredientEdit[1]),body,user)});
   const recipeDelete=u.pathname.match(/^\/api\/inventory\/recipes\/(\d+)\/(\d+)$/);
   if(recipeDelete&&req.method==='DELETE')return send(200,await removeRecipe(repo,Number(recipeDelete[1]),Number(recipeDelete[2]),user));
   if(u.pathname==='/api/reports/cash'||u.pathname==='/api/reports/cash/count'){
    if(!['owner','manager','cashier'].includes(user.role))return send(403,{error:'finance role required'});
    if(u.pathname==='/api/reports/cash'&&req.method==='GET')return send(200,{cash:await cashReport(repo,{from:Number(u.searchParams.get('from')||0),to:Number(u.searchParams.get('to')||Number.MAX_SAFE_INTEGER)})});
    if(u.pathname==='/api/reports/cash/count'&&req.method==='POST')return send(201,await cashCount(repo,body,user));
   }
   if(u.pathname==='/api/inventory/ingredients'&&req.method==='GET'){
    const rows=(await pool.query('SELECT * FROM smartdine_restaurant.ingredients ORDER BY name,id')).rows;return send(200,{ingredients:rows.map(r=>({...r,id:Number(r.id),stock_qty:Number(r.stock_qty),reorder_threshold:Number(r.reorder_threshold),low_stock:Number(r.stock_qty)<=Number(r.reorder_threshold)}))});
   }
   if(u.pathname==='/api/inventory/ingredients'&&req.method==='POST')return send(201,{ingredient:await repo.createIngredient({name:body.name,unit:body.unit,supplier:body.supplier,opening:body.stock_qty??0,threshold:body.reorder_threshold??0})});
   if(u.pathname==='/api/inventory/movements'&&req.method==='POST')return send(201,{ingredient:await repo.moveStock({ingredientId:body.ingredient_id,kind:body.kind,qty:body.qty,unitCost:body.unit_cost??null,note:body.note})});
   if(u.pathname==='/api/inventory/movements'&&req.method==='GET'){
    const rows=(await pool.query('SELECT m.*,i.name ingredient_name FROM smartdine_restaurant.stock_movements m JOIN smartdine_restaurant.ingredients i ON i.id=m.ingredient_id ORDER BY m.id DESC LIMIT 200')).rows;return send(200,{movements:rows.map(numericRows)});
   }
   if(u.pathname==='/api/inventory/recipes'&&req.method==='POST'){await repo.setRecipe({menuItemId:body.menu_item_id,ingredientId:body.ingredient_id,qty:body.qty});return send(200,{ok:true});}
   if(u.pathname==='/api/inventory/recipes'&&req.method==='GET')return send(200,{recipes:(await pool.query('SELECT r.*,i.name ingredient_name,i.unit FROM smartdine_restaurant.recipes r JOIN smartdine_restaurant.ingredients i ON i.id=r.ingredient_id ORDER BY r.menu_item_id,r.ingredient_id')).rows.map(numericRows)});
   if(u.pathname==='/api/expenses'){
    if(!['owner','manager','cashier'].includes(user.role))return send(403,{error:'finance role required'});
    if(req.method==='POST'){
     if(!['owner','manager'].includes(user.role))return send(403,{error:'manager required'});
     if(typeof body.category!=='string'||!body.category.trim()||!Number.isSafeInteger(body.amount)||body.amount<=0)return send(400,{error:'category and positive whole PKR amount required'});
     const expense=await repo.transaction(async c=>{
      const row=(await c.query('INSERT INTO expenses(category,amount,spent_on,notes,actor_user_id,created_at) VALUES($1,$2,$3,$4,$5,$6) RETURNING *',[body.category.trim().slice(0,60),body.amount,String(body.spent_on||new Date().toISOString().slice(0,10)).slice(0,20),String(body.notes||'').slice(0,300),user.userId,Date.now()])).rows[0];
      await c.query('INSERT INTO audit_logs(actor_user_id,actor_name,action,detail,at) VALUES($1,$2,$3,$4,$5)',[user.userId,user.name,'expense.add','expense '+row.id,Date.now()]);return row;
     });return send(201,{expense});
    }
    if(req.method==='GET')return send(200,{expenses:(await pool.query('SELECT * FROM smartdine_restaurant.expenses ORDER BY id DESC LIMIT 500')).rows.map(numericRows)});
   }
   if(u.pathname==='/api/reports/summary'&&req.method==='GET'){
    if(!['owner','manager','cashier'].includes(user.role))return send(403,{error:'finance role required'});
    const from=Number(u.searchParams.get('from')||0),to=Number(u.searchParams.get('to')||Number.MAX_SAFE_INTEGER);if(!Number.isSafeInteger(from)||!Number.isSafeInteger(to)||from<0||to<from)return send(400,{error:'invalid report range'});
    const summary=await repo.transaction(async c=>{
     await c.query('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ');
     const sales=(await c.query("SELECT COUNT(*) orders,COALESCE(SUM(total),0) revenue,COALESCE(SUM(tax),0) tax,COALESCE(SUM(service_charge),0) service_charge,COALESCE(SUM(discount),0) discounts FROM orders WHERE status='paid' AND created_at BETWEEN $1 AND $2",[from,to])).rows[0];
     const expense=Number((await c.query('SELECT COALESCE(SUM(amount),0) total FROM expenses WHERE created_at BETWEEN $1 AND $2',[from,to])).rows[0].total);
     const payment=(await c.query("SELECT method,COUNT(*) count,COALESCE(SUM(amount),0) total FROM payments WHERE status='confirmed' AND created_at BETWEEN $1 AND $2 GROUP BY method",[from,to])).rows;
     const cost=(await c.query("SELECT COALESCE(SUM(usage.used*priced.cost),0) total,COUNT(*) FILTER(WHERE priced.cost IS NULL) unpriced FROM (SELECT id,ingredient_id,created_at,-qty used FROM stock_movements WHERE kind='usage' AND created_at BETWEEN $1 AND $2) usage LEFT JOIN LATERAL (SELECT SUM(qty*unit_cost)/NULLIF(SUM(qty),0) cost FROM stock_movements p WHERE p.ingredient_id=usage.ingredient_id AND p.kind='purchase' AND p.unit_cost IS NOT NULL AND p.qty>0 AND (p.created_at<usage.created_at OR (p.created_at=usage.created_at AND p.id<=usage.id))) priced ON true",[from,to])).rows[0];
     const tops=(await c.query("SELECT oi.name_snapshot name,SUM(oi.qty) qty,SUM(oi.qty*oi.price_snapshot) revenue FROM order_items oi JOIN orders o ON o.id=oi.order_id WHERE o.status='paid' AND o.created_at BETWEEN $1 AND $2 GROUP BY oi.menu_item_id,oi.name_snapshot ORDER BY SUM(oi.qty) DESC LIMIT 10",[from,to])).rows;
     const expenseCategories=(await c.query('SELECT category,SUM(amount) total FROM expenses WHERE created_at BETWEEN $1 AND $2 GROUP BY category ORDER BY total DESC',[from,to])).rows;
     const refunds=(await c.query("SELECT COUNT(*) count,COALESCE(SUM(amount),0) total FROM payments WHERE status='refunded' AND COALESCE(status_changed_at,created_at) BETWEEN $1 AND $2",[from,to])).rows[0];
     const refundMethods=(await c.query("SELECT method,COUNT(*) count,SUM(amount) total FROM payments WHERE status='refunded' AND COALESCE(status_changed_at,created_at) BETWEEN $1 AND $2 GROUP BY method",[from,to])).rows;
     const refundStaff=(await c.query("SELECT COALESCE(status_changed_by,recorded_by_name) staff,COUNT(*) count,SUM(amount) total FROM payments WHERE status='refunded' AND COALESCE(status_changed_at,created_at) BETWEEN $1 AND $2 GROUP BY COALESCE(status_changed_by,recorded_by_name)",[from,to])).rows;
     const counts=(await c.query("SELECT (SELECT COUNT(*) FROM orders WHERE status NOT IN ('paid','cancelled')) open_orders,(SELECT COUNT(*) FROM ingredients WHERE stock_qty<=reorder_threshold) low_stock_count")).rows[0];
     const nums=Object.fromEntries(Object.entries(sales).map(([k,v])=>[k,Number(v)]));
     return {...nums,open_orders:Number(counts.open_orders),low_stock_count:Number(counts.low_stock_count),top_items:tops.map(r=>({...r,qty:Number(r.qty),revenue:Number(r.revenue)})),expenses_by_category:expenseCategories.map(r=>({...r,total:Number(r.total)})),refunds:{count:Number(refunds.count),total:Number(refunds.total),by_method:refundMethods.map(r=>({...r,count:Number(r.count),total:Number(r.total)})),by_staff:refundStaff.map(r=>({...r,count:Number(r.count),total:Number(r.total)}))},aov:nums.orders?Math.round(nums.revenue/nums.orders):0,expenses:expense,net:nums.revenue-expense,payments_by_method:payment.map(p=>({...p,count:Number(p.count),total:Number(p.total)})),estimated_food_cost:Math.round(Number(cost.total)),estimated_food_cost_unpriced_movements:Number(cost.unpriced),estimated_food_cost_note:'quantity-weighted purchase cost known at usage; unpriced usage excluded; estimate not actual margin'};
    });return send(200,{summary});
   }
   if(['/api/reports/sales','/api/reports/staff'].includes(u.pathname)&&req.method==='GET'){
    if(!['owner','manager','cashier'].includes(user.role))return send(403,{error:'finance role required'});
    const from=Number(u.searchParams.get('from')||0),to=Number(u.searchParams.get('to')||Number.MAX_SAFE_INTEGER);if(!Number.isSafeInteger(from)||!Number.isSafeInteger(to)||from<0||to<from)return send(400,{error:'invalid report range'});
    if(u.pathname==='/api/reports/staff'){const rows=(await pool.query('SELECT actor_name staff,action,COUNT(*) count FROM smartdine_restaurant.audit_logs WHERE at BETWEEN $1 AND $2 GROUP BY actor_name,action ORDER BY COUNT(*) DESC LIMIT 300',[from,to])).rows;return send(200,{rows:rows.map(r=>({...r,count:Number(r.count)}))});}
    const group=u.searchParams.get('group')||'day';if(!['day','week','month'].includes(group))return send(400,{error:'invalid group'});
    const rows=(await pool.query("SELECT to_char(date_trunc($3,to_timestamp(created_at/1000.0) AT TIME ZONE 'UTC'),'YYYY-MM-DD') period,COUNT(*) orders,COALESCE(SUM(total),0) revenue,COALESCE(SUM(discount),0) discounts FROM smartdine_restaurant.orders WHERE status<>'cancelled' AND created_at BETWEEN $1 AND $2 GROUP BY period ORDER BY period DESC LIMIT 400",[from,to,group])).rows;
    return send(200,{rows:rows.map(r=>({...r,orders:Number(r.orders),revenue:Number(r.revenue),discounts:Number(r.discounts),aov:Number(r.orders)?Math.round(Number(r.revenue)/Number(r.orders)):0})),timezone:'UTC',basis:'non-cancelled order creation time; not confirmed collections'});
   }
   if(u.pathname==='/api/table-assignments/waiters'&&req.method==='GET'){if(!['owner','manager'].includes(user.role))return send(403,{error:'manager required'});return send(200,{waiters:(await pool.query("SELECT id,name FROM smartdine_restaurant.users WHERE active=1 AND role='waiter' ORDER BY name,id")).rows.map(numericRows)});}
   if(u.pathname==='/api/tables'&&req.method==='GET')return send(200,{tables:await repo.listAssignedTables(user)});
   const assignment=url.pathname.match(/^\/api\/tables\/(\d+)\/assignment$/);
   if(assignment&&req.method==='PUT'){
    if(!['manager','owner'].includes(user.role))return send(403,{error:'manager required'});
    if(!Object.hasOwn(body,'waiter_user_id'))return send(400,{error:'waiter_user_id required'});
    await repo.assignTable({tableId:Number(assignment[1]),waiterUserId:body.waiter_user_id,actorUserId:user.userId});return send(200,{ok:true,scope:'one-database-local-staff'});
   }
   if(u.pathname==='/api/orders'&&req.method==='POST'){
    if(!['owner','manager','cashier','waiter'].includes(user.role))return send(403,{error:'cashier/waiter role required'});
    if(user.role==='waiter'&&(body.table_id==null||!(await repo.listAssignedTables(user)).some(t=>t.id===body.table_id)))return send(403,{error:'table is not assigned'});
    const order=await repo.createOrder({tableId:body.table_id??null,items:Array.isArray(body.items)?body.items.map(i=>i&&({menuItemId:i.menu_item_id,qty:i.qty,expectedPrice:i.expected_unit_price,notes:i.notes})):null,idempotencyKey:body.idempotency_key,orderType:body.order_type??null,customerName:body.customer_name??'',note:body.note??'',actorName:user.name,actorUserId:user.userId,databaseId:body.database_id??null,attemptVersion:body.attempt_version??null});return send(order.deduped?200:201,{order});
   }
   if(u.pathname==='/api/orders/merge'&&req.method==='POST'){if(!['owner','manager'].includes(user.role))return send(403,{error:'manager required'});return send(200,{order:await mergeOrders(repo,{fromId:body.from_id,intoId:body.into_id,user})});}
   const split=u.pathname.match(/^\/api\/orders\/([a-f0-9-]{36})\/split$/);if(split&&req.method==='POST'){if(!['owner','manager','cashier'].includes(user.role))return send(403,{error:'cashier role required'});const result=await splitOrder(repo,{id:split[1],itemIds:body.item_ids,user});const [order]=await orderList(pool,user,{id:result.id}),[original]=await orderList(pool,user,{id:result.original_id});return send(201,{order,original});}
   let match=u.pathname.match(/^\/api\/orders\/([a-f0-9-]{36})$/);
   if(match&&req.method==='GET'){const orders=await orderList(pool,user,{id:match[1]});if(!orders.length)return send(user.role==='waiter'?403:404,{error:'order not found or not assigned'});return send(200,{order:orders[0]});}
   match=u.pathname.match(/^\/api\/orders\/([a-f0-9-]{36})\/(move|discount)$/);
   if(match&&req.method===(match[2]==='discount'?'PUT':'POST')){
    if(!(match[2]==='discount'?['owner','manager']:['owner','manager','waiter']).includes(user.role))return send(403,{error:'operation role required'});
    const order=match[2]==='move'?await moveOrder(repo,{id:match[1],tableId:body.table_id,user}):await discountOrder(repo,{id:match[1],amount:body.amount,user});return send(200,{order});
   }
   match=u.pathname.match(/^\/api\/orders\/([a-f0-9-]{36})\/status$/);
   if(match&&req.method==='POST'){if(body.status==='cancelled'){if(!['owner','manager'].includes(user.role))return send(403,{error:'manager required'});return send(200,{order:await cancelOrder(repo,{id:match[1],reason:body.reason,user})});}if(!({preparing:['kitchen','manager','owner'],ready:['kitchen','manager','owner'],delivered:['waiter','manager','owner'],billed:['cashier','manager','owner']}[body.status]||[]).includes(user.role))return send(403,{error:'role cannot set status'});return send(200,{order:await repo.setOrderStatus({orderId:match[1],status:body.status,role:user.role,actorName:user.name,actorUserId:user.userId})});}
   match=u.pathname.match(/^\/api\/orders\/([a-f0-9-]{36})\/payments$/);
   if(match&&req.method==='POST'){if(!['owner','manager','cashier'].includes(user.role))return send(403,{error:'cashier role required'});if(typeof body.idempotency_key!=='string'||!body.idempotency_key||body.idempotency_key.length>80)return send(400,{error:'payment idempotency key required'});if(typeof body.database_id!=='string')return send(400,{error:'payment database identity required'});if(!Number.isSafeInteger(body.amount)||body.amount<=0)return send(400,{error:'payment amount must be a positive whole PKR integer'});const payment=await repo.recordPayment({orderId:match[1],amount:body.amount,method:body.method,reference:body.reference,role:user.role,actorName:user.name,actorUserId:user.userId,idempotencyKey:body.idempotency_key,databaseId:body.database_id});const orders=await orderList(pool,user,{id:match[1]});return send(payment.deduped?200:201,{payment,order:orders[0],payment_id:Number(payment.id),operation_id:body.idempotency_key,deduped:!!payment.deduped});}
   match=u.pathname.match(/^\/api\/payments\/(\d+)\/(confirm|void|refund)$/);
   if(match&&req.method==='POST'){if(!(match[2]==='confirm'?['cashier','manager','owner']:['manager','owner']).includes(user.role))return send(403,{error:'approval role required'});return send(200,{payment:await repo.changePayment({paymentId:Number(match[1]),action:match[2],role:user.role,actorName:user.name,reason:body.reason||''})});}
   return send(404,{error:'route not implemented by partial Postgres adapter'});
  }catch(e){const message=String(e.message||'');const expected=/invalid|unavailable|required|exists|exceeds|closed|not found|not confirmable|not reversible|conflict|price changed|not assigned|requires|recorded payment|cannot deactivate|PIN already|last active|PIN must/.test(message);return send(expected?409:500,{error:expected?message:'adapter unavailable',...(e.notCommitted===true&&['menu_unavailable','price_changed'].includes(e.rejection)?{not_committed:true,rejection:e.rejection}:{})});}
 };return createActiveListener(handler,activeTls)||http.createServer(handler);
}
