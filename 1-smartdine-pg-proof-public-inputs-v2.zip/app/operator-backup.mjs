import {assertPrivate,protectPrivate} from './private-file.mjs';
// Private operator workflow. No HTTP endpoint, no destination provisioning.
import pg from 'pg';import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';import {spawnSync} from 'node:child_process';
const digest=file=>crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
export function backupConnection(connectionString){
 const u=new URL(connectionString);if(!['postgres:','postgresql:'].includes(u.protocol)||u.hash)throw new Error('PostgreSQL connection URL required');
 const allowed=new Set(['sslmode','sslrootcert','sslcert','sslkey']);for(const [key] of u.searchParams){if(!allowed.has(key)||u.searchParams.getAll(key).length!==1)throw new Error('unsupported or duplicate backup connection parameter: '+key);}
 const host=u.hostname.replace(/^\[|\]$/g,''),database=decodeURIComponent(u.pathname.slice(1)),user=decodeURIComponent(u.username),password=decodeURIComponent(u.password),port=Number(u.port||5432),local=['127.0.0.1','localhost','::1'].includes(host),mode=u.searchParams.get('sslmode')||(local?'disable':'');
 if(host.includes(',')||host.includes('%')||!host||!database||database.includes('/')||!user||!Number.isInteger(port)||port<1||port>65535)throw new Error('explicit host/user/database/port required');
 if(!['disable','verify-full'].includes(mode)||mode==='disable'&&!local)throw new Error('remote backup requires explicit sslmode=verify-full; weaker modes unsupported');
 const root=u.searchParams.get('sslrootcert'),cert=u.searchParams.get('sslcert'),key=u.searchParams.get('sslkey');if(mode==='disable'&&(root||cert||key)||Boolean(cert)!==Boolean(key))throw new Error('inconsistent backup TLS configuration');
 if(mode==='verify-full'&&!root)throw new Error('explicit sslrootcert required for verified backup TLS');
 const ssl=mode==='verify-full'?{rejectUnauthorized:true,ca:fs.readFileSync(root),...(cert?{cert:fs.readFileSync(cert),key:fs.readFileSync(key)}:{})}:false;
 // Remove ambient libpq overrides (service files, PGOPTIONS, alternate hosts).
 const env=Object.fromEntries(Object.entries(process.env).filter(([k])=>!k.startsWith('PG')));Object.assign(env,{PGHOST:host,PGPORT:String(port),PGUSER:user,PGPASSWORD:password,PGDATABASE:database,PGCONNECT_TIMEOUT:'10',PGSSLMODE:mode,PGSERVICEFILE:process.platform==='win32'?'NUL':'/dev/null',PGPASSFILE:process.platform==='win32'?'NUL':'/dev/null',PGSSLCERT:process.platform==='win32'?'NUL':'/nonexistent-smartdine-client-cert',PGSSLKEY:process.platform==='win32'?'NUL':'/nonexistent-smartdine-client-key'});
 if(root)env.PGSSLROOTCERT=root;if(cert){env.PGSSLCERT=cert;env.PGSSLKEY=key;}
 return {pool:{host,port,user,password,database,ssl,connectionTimeoutMillis:10000,max:1},env};
}

function run(command,args,env){const r=spawnSync(command,args,{env,encoding:'utf8',timeout:120000,maxBuffer:1024*1024});if(r.error||r.status!==0)throw new Error(command+' failed; inspect private operator logs before retrying');}
async function exportWithPool(pool,{connectionString,directory}){
 // Refuse replacement. Directory created private BEFORE any dump bytes exist.
 fs.mkdirSync(directory,{mode:0o700});protectPrivate(directory);const dump=path.join(directory,'restaurant.dump'),manifestFile=path.join(directory,'manifest.json');let complete=false;
 try{const state=(await pool.query('SELECT instance_id FROM smartdine_restaurant.runtime_identity WHERE id=1')).rows[0];if(!state)throw new Error('source identity required');const replica=(await pool.query("SELECT to_regclass('smartdine_restaurant.replica_state') relation")).rows[0].relation;if(replica&&(await pool.query('SELECT 1 FROM smartdine_restaurant.replica_state LIMIT 1')).rowCount)throw new Error('analytical replica is not an operating source backup');
  fs.closeSync(fs.openSync(dump,'wx',0o600));const started=Date.now();run('pg_dump',['--format=custom','--enable-row-security','--no-owner','--no-acl','--schema=smartdine_restaurant','--exclude-table-data=smartdine_restaurant.staff_sessions','--exclude-table-data=smartdine_restaurant.auth_attempts','--file='+dump],backupConnection(connectionString).env);
  const manifest={format:'smartdine-operator-backup-v1',source_database_id:state.instance_id,started_at:started,finished_at:Date.now(),bytes:fs.statSync(dump).size,sha256:digest(dump),sessions_excluded:true,auth_attempts_excluded:true,restore_notice:'Snapshot only. Reconcile orders/payments after backup time; never activate source and restored clone together.'};fs.writeFileSync(manifestFile,JSON.stringify(manifest,null,2)+'\n',{mode:0o600,flag:'wx'});complete=true;return manifest;
 }finally{if(!complete)fs.rmSync(directory,{recursive:true,force:true});}
}
async function restoreWithPool(pool,{connectionString,directory,confirmedSourceId}){
 const dump=path.join(directory,'restaurant.dump'),manifest=JSON.parse(fs.readFileSync(path.join(directory,'manifest.json'),'utf8'));
 if(manifest.format!=='smartdine-operator-backup-v1'||manifest.source_database_id!==confirmedSourceId||manifest.sessions_excluded!==true||manifest.auth_attempts_excluded!==true||manifest.bytes!==fs.statSync(dump).size||manifest.sha256!==digest(dump))throw new Error('backup identity/content verification failed');
 // Dedicated EMPTY target only; all user schemas rejected, no clean/drop route.
 const existing=await pool.query("SELECT nspname FROM pg_namespace WHERE nspname NOT IN ('public','information_schema') AND nspname NOT LIKE 'pg_%' UNION ALL SELECT n.nspname FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname='public' AND c.relkind IN ('r','v','m','S','f','p') UNION ALL SELECT n.nspname FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace WHERE n.nspname='public' UNION ALL SELECT n.nspname FROM pg_type t JOIN pg_namespace n ON n.oid=t.typnamespace WHERE n.nspname='public' UNION ALL SELECT extname FROM pg_extension WHERE extname<>'plpgsql'");if(existing.rowCount)throw new Error('restore target must be empty and stopped');
 // Transaction rolls back all restored schema/data on a late failure.
 run('pg_restore',['--no-owner','--no-acl','--single-transaction','--exit-on-error','--dbname='+backupConnection(connectionString).env.PGDATABASE,dump],backupConnection(connectionString).env);
 const identity=(await pool.query('SELECT instance_id FROM smartdine_restaurant.runtime_identity WHERE id=1')).rows[0]?.instance_id;if(identity!==confirmedSourceId)throw new Error('restored identity mismatch: do not start target');
 if((await pool.query('SELECT 1 FROM smartdine_restaurant.staff_sessions LIMIT 1')).rowCount||(await pool.query('SELECT 1 FROM smartdine_restaurant.auth_attempts LIMIT 1')).rowCount)throw new Error('restored auth state not empty: do not start target');
 return {restored:true,source_database_id:identity,activated:false,notice:'Re-provision private runtime grants. Reconcile physical orders/payments. Do not start both source and restored copy.'};
}

export async function exportOperatorBackup(options){const pool=new pg.Pool(backupConnection(options.connectionString).pool);try{return await exportWithPool(pool,options);}finally{await pool.end();}}
export async function restoreOperatorBackup(options){const pool=new pg.Pool(backupConnection(options.connectionString).pool);try{return await restoreWithPool(pool,options);}finally{await pool.end();}}
