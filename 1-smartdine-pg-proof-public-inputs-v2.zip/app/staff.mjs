import crypto from 'node:crypto';import {hashPin,verifyPin} from './login.mjs';
const roles=['owner','manager','cashier','waiter','kitchen'];
const elevated=(role,p)=>typeof p==='string'&&/^\d{6,8}$/.test(p);
const pinOk=p=>typeof p==='string'&&/^\d{4,8}$/.test(p);
export async function staffWrite(repo,{path,method,body,user}){
 return repo.transaction(async c=>{
  // All credential/owner mutations serialize, so cross-worker duplicate PINs and
  // concurrent removal of the last owner cannot both pass a preflight read.
  await c.query("SELECT pg_advisory_xact_lock(hashtextextended('staff-admin',0))");
  const actor=(await c.query('SELECT id,name,role,active,pin_hash FROM users WHERE id=$1 FOR UPDATE',[user.userId])).rows[0];if(!actor||Number(actor.active)!==1)throw new Error('active user required');
  const match=path.match(/^\/api\/users\/(\d+)\/(pin|active)$/);const targetId=match?Number(match[1]):null;
  if(path==='/api/auth/pin'&&method==='PUT'){
   const ts=Date.now(),key='self-pin:'+actor.id;
   const prior=(await c.query('SELECT window_at,failures FROM auth_attempts WHERE bucket_hash=$1 FOR UPDATE',[key])).rows[0];
   const start=prior&&ts-Number(prior.window_at)<15*60000?Number(prior.window_at):ts,used=prior&&start===Number(prior.window_at)?Number(prior.failures):0;
   if(used>=5)return {status:429,error:'PIN changes temporarily unavailable; try later or contact owner'};
   await c.query('INSERT INTO auth_attempts(bucket_hash,window_at,failures) VALUES($1,$2,$3) ON CONFLICT(bucket_hash) DO UPDATE SET window_at=EXCLUDED.window_at,failures=EXCLUDED.failures',[key,start,used+1]);
   if(!pinOk(body.current_pin)||!pinOk(body.new_pin)||repo.securePolicy&&!elevated(actor.role,body.new_pin))return {status:409,error:'invalid current or new PIN'};
   if(!verifyPin(body.current_pin,actor.pin_hash))return {status:409,error:'PIN change refused'};
   const others=repo.securePolicy?[]:(await c.query('SELECT pin_hash FROM users WHERE active=1 AND id!=$1',[actor.id])).rows;
   if(!repo.securePolicy&&others.some(u=>verifyPin(body.new_pin,u.pin_hash)))return {status:409,error:'PIN change refused'};
   await c.query('UPDATE users SET pin_hash=$1 WHERE id=$2',[hashPin(body.new_pin),actor.id]);if(repo.securePolicy)await c.query('UPDATE users SET elevated_pin_ready=true WHERE id=$1',[actor.id]);await c.query('DELETE FROM staff_sessions WHERE user_id=$1',[actor.id]);await audit(c,user,'user.pin','self PIN change, all sessions revoked');return {status:200,result:{ok:true,relogin_required:true}};
  }
  if(actor.role!=='owner')return {status:403,error:'owner required'};
  if(path==='/api/users'&&method==='POST'){
   if(repo.securePolicy&&!elevated(body.role,body.pin))throw Error('new staff PIN must be 6-8 digits');if(typeof body.name!=='string'||!body.name.trim()||body.name.length>60||!roles.includes(body.role)||!pinOk(body.pin))throw new Error('invalid staff user');if(!repo.securePolicy)await uniquePin(c,body.pin);
   const row=(await c.query(`INSERT INTO users(name,role,pin_hash,active,created_at) VALUES($1,$2,$3,1,$4) RETURNING id,name,role,active${repo.securePolicy?',login_id':''}`,[body.name.trim(),body.role,hashPin(body.pin),Date.now()])).rows[0];if(repo.securePolicy)await c.query('UPDATE users SET elevated_pin_ready=$1 WHERE id=$2',[body.pin.length>=6,row.id]);await audit(c,user,'user.create',body.name.trim()+' ('+body.role+')');return {status:201,result:row};
  }
  if(!match||method!=='PUT')return {status:404,error:'staff route not implemented'};
  const target=(await c.query('SELECT id,role,active FROM users WHERE id=$1 FOR UPDATE',[targetId])).rows[0];if(!target)throw new Error('user not found');
  if(repo.securePolicy&&(match[2]==='pin'||body.active===true)&&!elevated(target.role,body.pin))throw Error('new staff PIN must be 6-8 digits');
  if(match[2]==='pin'){if(!pinOk(body.pin))throw new Error('invalid new PIN');if(!repo.securePolicy)await uniquePin(c,body.pin,target.id);await c.query('UPDATE users SET pin_hash=$1 WHERE id=$2',[hashPin(body.pin),target.id]);await c.query('DELETE FROM staff_sessions WHERE user_id=$1',[target.id]);if(repo.securePolicy)await c.query('UPDATE users SET elevated_pin_ready=true WHERE id=$1',[target.id]);await audit(c,user,'user.pin','reset user '+target.id);return {status:200,result:{ok:true}};}
  if(typeof body.active!=='boolean')throw new Error('invalid active flag');
  if(!body.active){if(Number(target.id)===user.userId)throw new Error('cannot deactivate own account');if(target.role==='owner'&&Number((await c.query("SELECT COUNT(*) n FROM users WHERE role='owner' AND active=1")).rows[0].n)<=1)throw new Error('last active owner required');await c.query('UPDATE users SET active=0,pin_hash=$1 WHERE id=$2',['disabled$'+crypto.randomBytes(32).toString('hex'),target.id]);}
  else{if(!pinOk(body.pin))throw new Error('reactivation requires new PIN');if(!repo.securePolicy)await uniquePin(c,body.pin,target.id);await c.query('UPDATE users SET active=1,pin_hash=$1 WHERE id=$2',[hashPin(body.pin),target.id]);}
  await c.query('DELETE FROM staff_sessions WHERE user_id=$1',[target.id]);if(repo.securePolicy&&body.active)await c.query('UPDATE users SET elevated_pin_ready=true WHERE id=$1',[target.id]);await audit(c,user,'user.active','user '+target.id+' -> '+Number(body.active));return {status:200,result:{ok:true}};
 });
}
async function uniquePin(c,pin,exclude=null){const users=(await c.query('SELECT id,pin_hash FROM users WHERE active=1')).rows;if(users.some(u=>u.id!==exclude&&verifyPin(pin,u.pin_hash)))throw new Error('PIN already exists');}
async function audit(c,user,action,detail){await c.query('INSERT INTO audit_logs(actor_user_id,actor_name,action,detail,at) VALUES($1,$2,$3,$4,$5)',[user.userId,user.name,action,detail,Date.now()]);}
