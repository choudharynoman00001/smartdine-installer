import crypto from 'node:crypto';
const digest=t=>crypto.createHash('sha256').update(t).digest('hex');
export class PostgresSessionStore{
 constructor(pool,{ttlMs=12*3600*1000,clock=Date.now}={}){this.pool=pool;this.ttlMs=ttlMs;this.clock=clock;}
 async create(userId){
  if(!Number.isSafeInteger(userId)||userId<1)throw new Error('invalid user');
  const token=crypto.randomBytes(24).toString('hex'),now=this.clock();
  const result=await this.pool.query('INSERT INTO smartdine_restaurant.staff_sessions(token_hash,user_id,expires_at,created_at) SELECT $1,id,$2,$3 FROM smartdine_restaurant.users WHERE id=$4 AND active=1 RETURNING user_id',[digest(token),now+this.ttlMs,now,userId]);
  if(!result.rowCount)throw new Error('active user required');return token;
 }
 async get(token){
  if(typeof token!=='string'||!/^[a-f0-9]{48}$/.test(token))return null;
  const c=await this.pool.connect();const now=this.clock(),key=digest(token);
  try{
   await c.query('BEGIN');
   // Lock token row before refreshing. Revocation serializes against refresh, so a
   // deleted session cannot be accidentally re-inserted by an in-flight request.
   const {rows:[s]}=await c.query('SELECT ss.expires_at,u.id,u.name,u.role,u.active FROM smartdine_restaurant.staff_sessions ss JOIN smartdine_restaurant.users u ON u.id=ss.user_id WHERE ss.token_hash=$1 FOR UPDATE OF ss',[key]);
   if(!s||Number(s.expires_at)<=now||Number(s.active)!==1){await c.query('DELETE FROM smartdine_restaurant.staff_sessions WHERE token_hash=$1',[key]);await c.query('COMMIT');return null;}
   await c.query('UPDATE smartdine_restaurant.staff_sessions SET expires_at=$1 WHERE token_hash=$2',[now+this.ttlMs,key]);await c.query('COMMIT');
   return {userId:Number(s.id),name:s.name,role:s.role,expires:now+this.ttlMs};
  }catch(e){await c.query('ROLLBACK');throw e;}finally{c.release();}
 }
 async revoke(token){return(await this.pool.query('DELETE FROM smartdine_restaurant.staff_sessions WHERE token_hash=$1',[digest(token)])).rowCount;}
 async revokeUser(userId){return(await this.pool.query('DELETE FROM smartdine_restaurant.staff_sessions WHERE user_id=$1',[userId])).rowCount;}
 async clear(){return(await this.pool.query('DELETE FROM smartdine_restaurant.staff_sessions')).rowCount;}
 async purgeExpired(){return(await this.pool.query('DELETE FROM smartdine_restaurant.staff_sessions WHERE expires_at<=$1',[this.clock()])).rowCount;}
}
