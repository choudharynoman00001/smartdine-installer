// Normalized PostgreSQL repository groundwork. Not yet wired to HTTP app routes.
import crypto from 'node:crypto';
const int=(n,min=0)=>Number.isSafeInteger(n)&&n>=min;
const money=n=>{if(!int(n))throw new Error('money must be non-negative safe integer PKR');return n;};
export class RestaurantRepository{
 constructor(pool){this.pool=pool;}
 async refreshTable(c,tableId){if(tableId===null)return;await c.query("UPDATE restaurant_tables SET status=CASE WHEN EXISTS(SELECT 1 FROM orders WHERE table_id=$1 AND status='billed') THEN 'bill_pending' WHEN EXISTS(SELECT 1 FROM orders WHERE table_id=$1 AND status='ready') THEN 'order_ready' WHEN EXISTS(SELECT 1 FROM orders WHERE table_id=$1 AND status NOT IN ('paid','cancelled')) THEN 'occupied' ELSE 'available' END WHERE id=$1",[tableId]);}

 // Only database-local callbacks: retries occur after confirmed transaction abort,
 // never on uncertain COMMIT/network outcomes and never around external effects.
 async transaction(fn){for(let attempt=0;;attempt++){const c=await this.pool.connect();try{await c.query('BEGIN');await c.query('SET LOCAL search_path TO smartdine_restaurant,pg_catalog');const result=await fn(c);await c.query('COMMIT');return result;}catch(e){await c.query('ROLLBACK').catch(()=>{delete e.notCommitted;delete e.rejection;});if(attempt>=2||!['40001','40P01'].includes(e.code))throw e;await new Promise(r=>setTimeout(r,10+Math.floor(Math.random()*30)));}finally{c.release();}}}

 async createOrder({tableId=null,items,idempotencyKey,actorName='staff',source='pos',note='',actorUserId=null,qrReceiptHash=null,orderType=null,customerName='',databaseId=null,attemptVersion=null}){
  const bound=source==='pos'&&attemptVersion===2;const fingerprint=bound?crypto.createHash('sha256').update(JSON.stringify([tableId,orderType,customerName,note,items,databaseId])).digest('hex'):null;
  orderType??=tableId===null?'takeaway':'dine-in';if(!['dine-in','takeaway','delivery'].includes(orderType)||source==='qr'&&orderType!=='dine-in'||typeof customerName!=='string'||customerName.length>80||typeof note!=='string'||note.length>300)throw new Error('invalid order details');
  if(!['pos','qr'].includes(source)||source==='qr'&&tableId===null)throw new Error('invalid order source/table');
  if(typeof idempotencyKey!=='string'||!idempotencyKey||idempotencyKey.length>80)throw new Error('idempotency key required');
  if(source==='qr'&&(typeof qrReceiptHash!=='string'||!/^[a-f0-9]{64}$/.test(qrReceiptHash)))throw new Error('private QR receipt required');
  if(!Array.isArray(items)||!items.length||items.length>60||items.some(i=>!i||typeof i!=='object'||!int(i.menuItemId,1)||!int(i.qty,1)||i.qty>999))throw new Error('invalid items');
  return this.transaction(async c=>{
   if(databaseId!==null&&databaseId!==(await c.query('SELECT instance_id FROM runtime_identity WHERE id=1')).rows[0].instance_id)throw new Error('database identity conflict');
   if(actorUserId!==null){
    const actor=(await c.query('SELECT role,active FROM users WHERE id=$1 FOR SHARE',[actorUserId])).rows[0];if(!actor||Number(actor.active)!==1)throw new Error('active staff required');
    if(actor.role==='waiter'&&(tableId===null||!(await c.query('SELECT 1 FROM table_assignments WHERE table_id=$1 AND waiter_user_id=$2 FOR SHARE',[tableId,actorUserId])).rowCount))throw new Error('table is not assigned');
   }
   // Serialized idempotency scope; a unique key alone must not produce two orders.
   await c.query('SELECT pg_advisory_xact_lock(hashtextextended($1,0))',[idempotencyKey]);
   const existing=(await c.query('SELECT id FROM orders WHERE idempotency_key=$1',[idempotencyKey])).rows[0];
   if(existing){const binding=source==='pos'?(await c.query('SELECT * FROM local_pos_intents WHERE idempotency_key=$1',[idempotencyKey])).rows[0]:null;if(binding&&(!bound||Number(binding.user_id)!==actorUserId||binding.body_hash!==fingerprint)||bound&&!binding)throw new Error('saved POS operation identity conflict; manager reconciliation required');const row=(await c.query('SELECT source,table_id,qr_receipt_hash,created_at FROM orders WHERE id=$1',[existing.id])).rows[0];if(row.source!==source||source==='qr'&&Number(row.table_id)!==tableId)throw new Error('idempotency identity conflict');if(source==='qr'&&(row.qr_receipt_hash!==qrReceiptHash||Number(row.created_at)<Date.now()-12*3600000))throw new Error('private QR receipt conflict');if(actorUserId!==null){const actor=(await c.query('SELECT role FROM users WHERE id=$1',[actorUserId])).rows[0];if(actor.role==='waiter'&&(row.table_id===null||!(await c.query('SELECT 1 FROM table_assignments WHERE table_id=$1 AND waiter_user_id=$2 FOR SHARE',[row.table_id,actorUserId])).rowCount))throw new Error('order is not assigned');}return {id:existing.id,deduped:true};}
   if(bound){if(actorUserId===null||databaseId===null)throw new Error('POS operation scope required');if(items.some(i=>typeof i.expectedPrice!=='number'||!Number.isSafeInteger(i.expectedPrice)||i.expectedPrice<0))throw new Error('numeric expected price required');}
   const settings=(await c.query('SELECT * FROM restaurants WHERE id=1')).rows[0];if(!settings)throw new Error('restaurant not configured');
   if(tableId!==null){if(!int(tableId,1)||!(await c.query('SELECT id FROM restaurant_tables WHERE id=$1',[tableId])).rowCount)throw new Error('table not found');}
   const lines=[];let subtotal=0;
   for(const i of items){const row=(await c.query('SELECT * FROM menu_items WHERE id=$1 AND available=1 FOR SHARE',[i.menuItemId])).rows[0];if(!row){const e=new Error('item unavailable');e.notCommitted=true;e.rejection='menu_unavailable';throw e;}const price=money(Number(row.price));if(i.expectedPrice!==undefined&&i.expectedPrice!==price){const e=new Error('menu price changed; review current prices');e.notCommitted=true;e.rejection='price_changed';throw e;}subtotal=money(subtotal+price*i.qty);lines.push({...i,row,price});}
   if(bound)await c.query('INSERT INTO local_pos_intents(idempotency_key,user_id,body_hash) VALUES($1,$2,$3)',[idempotencyKey,actorUserId,fingerprint]);
   const tax=money(Math.round(subtotal*Number(settings.tax_percent)/100)),service=money(Math.round(subtotal*Number(settings.service_charge_percent)/100)),total=money(subtotal+tax+service);const id=crypto.randomUUID(),at=Date.now();
   await c.query("INSERT INTO orders(id,table_id,source,status,order_type,subtotal,tax,service_charge,total,idempotency_key,created_at) VALUES($1,$2,$10,'new',$3,$4,$5,$6,$7,$8,$9)",[id,tableId,orderType,subtotal,tax,service,total,idempotencyKey,at,source]);
   await c.query('UPDATE orders SET note=$1,qr_receipt_hash=$2,customer_name=$3 WHERE id=$4',[note,qrReceiptHash,customerName,id]);
   for(const i of lines)await c.query('INSERT INTO order_items(order_id,menu_item_id,name_snapshot,price_snapshot,qty,station,notes) VALUES($1,$2,$3,$4,$5,$6,$7)',[id,i.menuItemId,i.row.name_en,i.price,i.qty,i.row.station,String(i.notes||'').slice(0,200)]);
   await c.query("INSERT INTO order_events(order_id,status,actor_name,at,actor_user_id) VALUES($1,'new',$2,$3,$4)",[id,actorName,at,actorUserId]);
   await this.refreshTable(c,tableId);
   return {id,deduped:false,subtotal,tax,service_charge:service,total};
  });
 }
 async getOrder(id){return this.transaction(async c=>{const order=(await c.query('SELECT * FROM orders WHERE id=$1',[id])).rows[0];if(!order)return null;return {...order,items:(await c.query('SELECT * FROM order_items WHERE order_id=$1 ORDER BY id',[id])).rows,payments:(await c.query('SELECT * FROM payments WHERE order_id=$1 ORDER BY id',[id])).rows};});}
 async recordPayment({orderId,amount,method,reference='',actorName='staff',role,actorUserId=null,idempotencyKey=null,databaseId=null}){
  if(!['cashier','manager','owner'].includes(role))throw new Error('cashier role required');
  if(idempotencyKey!==null&&(typeof idempotencyKey!=='string'||!idempotencyKey||idempotencyKey.length>80))throw new Error('invalid payment idempotency key');
  const fingerprint=crypto.createHash('sha256').update(JSON.stringify([orderId,amount,method,reference,databaseId])).digest('hex');
  const status=method==='cash'?'confirmed':'pending';
  money(amount);if(amount===0||!['cash','card','digital'].includes(method)||!['pending','confirmed'].includes(status))throw new Error('invalid payment');
  return this.transaction(async c=>{
   if(databaseId!==null&&databaseId!==(await c.query('SELECT instance_id FROM runtime_identity WHERE id=1')).rows[0].instance_id)throw new Error('database identity conflict');
   if(actorUserId!==null){const actor=(await c.query('SELECT role,active FROM users WHERE id=$1 FOR SHARE',[actorUserId])).rows[0];if(!actor||Number(actor.active)!==1||!['cashier','manager','owner'].includes(actor.role))throw Error('active cashier role required');}
   const order=(await c.query('SELECT * FROM orders WHERE id=$1 FOR UPDATE',[orderId])).rows[0];if(!order)throw new Error('order not found');
   if(idempotencyKey!==null){
    await c.query('SELECT pg_advisory_xact_lock(hashtextextended($1,0))',['payment:'+idempotencyKey]);
    const existing=(await c.query('SELECT * FROM payments WHERE idempotency_key=$1',[idempotencyKey])).rows[0];
    if(existing){const intent=actorUserId===null?null:(await c.query('SELECT * FROM local_payment_intents WHERE idempotency_key=$1',[idempotencyKey])).rows[0];if(actorUserId!==null&&(!intent||Number(intent.user_id)!==actorUserId||intent.body_hash!==fingerprint||Number(intent.payment_id)!==Number(existing.id)))throw Error('payment identity conflict; reconciliation required');if(existing.order_id!==orderId||Number(existing.amount)!==amount||existing.method!==method||existing.reference!==String(reference).slice(0,120))throw new Error('payment idempotency conflict');const confirmed=Number((await c.query("SELECT COALESCE(SUM(amount),0) total FROM payments WHERE order_id=$1 AND status='confirmed'",[orderId])).rows[0].total);return {id:existing.id,confirmed_total:confirmed,deduped:true};}
   }
   if(['paid','cancelled'].includes(order.status))throw new Error('order closed');
   const paid=Number((await c.query("SELECT COALESCE(SUM(amount),0) total FROM payments WHERE order_id=$1 AND status IN ('pending','confirmed')",[orderId])).rows[0].total);
   if(amount>Number(order.total)-paid)throw new Error('amount exceeds outstanding balance');
   const result=(await c.query('INSERT INTO payments(order_id,amount,method,status,reference,recorded_by_name,created_at) VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING id',[orderId,amount,method,status,String(reference).slice(0,120),actorName,Date.now()])).rows[0];
   if(idempotencyKey!==null){if(actorUserId!==null&&!Number.isSafeInteger(actorUserId))throw Error('payment actor identity required');await c.query('UPDATE payments SET idempotency_key=$1 WHERE id=$2',[idempotencyKey,result.id]);if(actorUserId!==null)await c.query('INSERT INTO local_payment_intents(idempotency_key,user_id,order_id,body_hash,payment_id) VALUES($1,$2,$3,$4,$5)',[idempotencyKey,actorUserId,orderId,fingerprint,result.id]);}
   const confirmed=Number((await c.query("SELECT COALESCE(SUM(amount),0) total FROM payments WHERE order_id=$1 AND status='confirmed'",[orderId])).rows[0].total);
   if(confirmed===Number(order.total))await c.query("UPDATE orders SET status='paid' WHERE id=$1",[orderId]);
   await c.query('INSERT INTO audit_logs(actor_name,action,detail,at) VALUES($1,$2,$3,$4)',[actorName,'payment.add','order '+orderId+' '+method+' '+amount+' '+status,Date.now()]);
   await this.refreshTable(c,order.table_id);
   return {id:result.id,confirmed_total:confirmed};
  });
 }
 async createIngredient({name,unit='g',supplier='',opening=0,threshold=0}){
  if(typeof name!=='string'||!name.trim()||name.trim().length>80||typeof unit!=='string'||!unit.trim()||unit.trim().length>12||typeof supplier!=='string'||![opening,threshold].every(n=>typeof n==='number'&&Number.isFinite(n)&&n>=0&&n<=1e9))throw new Error('invalid ingredient');
  return this.transaction(async c=>{
   const clean=name.trim();await c.query('SELECT pg_advisory_xact_lock(hashtextextended($1,0))',['ingredient:'+clean.toLowerCase()]);
   if((await c.query('SELECT 1 FROM ingredients WHERE lower(trim(name))=lower($1)',[clean])).rowCount)throw new Error('ingredient name exists');
   const row=(await c.query('INSERT INTO ingredients(name,unit,stock_qty,reorder_threshold,supplier) VALUES($1,$2,$3,$4,$5) RETURNING *',[clean,unit.trim(),opening,threshold,supplier.trim().slice(0,80)])).rows[0];
   if(opening>0)await c.query("INSERT INTO stock_movements(ingredient_id,kind,qty,ref,note,created_at) VALUES($1,'adjustment',$2,'opening','Opening stock',$3)",[row.id,opening,Date.now()]);
   return row;
  });
 }
 async moveStock({ingredientId,kind,qty,unitCost=null,note=''}){
  if(!int(ingredientId,1)||!['purchase','wastage','adjustment'].includes(kind)||typeof qty!=='number'||!Number.isFinite(qty)||qty===0||Math.abs(qty)>1e6||(kind!=='adjustment'&&qty<0)||unitCost!==null&&(typeof unitCost!=='number'||!Number.isFinite(unitCost)||unitCost<0||unitCost>1e9))throw new Error('invalid stock movement');
  const change=kind==='wastage'?-qty:qty;
  return this.transaction(async c=>{
   const row=(await c.query('SELECT * FROM ingredients WHERE id=$1 FOR UPDATE',[ingredientId])).rows[0];if(!row)throw new Error('ingredient not found');
   // Decimal arithmetic is in PostgreSQL numeric, not binary floating point.
   const updated=(await c.query('UPDATE ingredients SET stock_qty=stock_qty+$1::numeric WHERE id=$2 AND stock_qty+$1::numeric>=0 RETURNING *',[change,ingredientId])).rows[0];if(!updated)throw new Error('insufficient stock');
   await c.query('INSERT INTO stock_movements(ingredient_id,kind,qty,unit_cost,note,created_at) VALUES($1,$2,$3,$4,$5,$6)',[ingredientId,kind,change,kind==='purchase'?unitCost:null,String(note).slice(0,200),Date.now()]);
   return updated;
  });
 }
 async setRecipe({menuItemId,ingredientId,qty}){
  if(!int(menuItemId,1)||!int(ingredientId,1)||typeof qty!=='number'||!Number.isFinite(qty)||qty<=0||qty>1e6)throw new Error('invalid recipe');
  return this.transaction(async c=>{
   if(!(await c.query('SELECT 1 FROM menu_items WHERE id=$1',[menuItemId])).rowCount)throw new Error('menu item not found');
   await c.query('INSERT INTO recipes(menu_item_id,ingredient_id,qty) VALUES($1,$2,$3) ON CONFLICT(menu_item_id,ingredient_id) DO UPDATE SET qty=EXCLUDED.qty',[menuItemId,ingredientId,qty]);
  });
 }

 async setOrderStatus({orderId,status,actorName='staff',role,actorUserId=null}){
  const transitions={preparing:{from:['new'],roles:['kitchen','manager','owner']},ready:{from:['preparing'],roles:['kitchen','manager','owner']},delivered:{from:['ready'],roles:['waiter','manager','owner']},billed:{from:['delivered'],roles:['cashier','manager','owner']}};
  const rule=transitions[status];if(!rule||!rule.roles.includes(role))throw new Error('role cannot set status');
  return this.transaction(async c=>{
   const order=(await c.query('SELECT * FROM orders WHERE id=$1 FOR UPDATE',[orderId])).rows[0];if(!order)throw new Error('order not found');if(!rule.from.includes(order.status))throw new Error('invalid status transition');
   if(role==='waiter'){
    if(!int(actorUserId,1)||order.table_id===null||!(await c.query("SELECT 1 FROM table_assignments a JOIN users u ON u.id=a.waiter_user_id WHERE a.table_id=$1 AND a.waiter_user_id=$2 AND u.active=1 AND u.role='waiter' FOR SHARE OF a,u",[order.table_id,actorUserId])).rowCount)throw new Error('order is not assigned');
   }
   const at=Date.now();
   if(status==='delivered'){
    const needs=(await c.query('SELECT r.ingredient_id,SUM(r.qty*oi.qty) used FROM order_items oi JOIN recipes r ON r.menu_item_id=oi.menu_item_id WHERE oi.order_id=$1 GROUP BY r.ingredient_id ORDER BY r.ingredient_id',[orderId])).rows;
    for(const need of needs){
     const stock=(await c.query('SELECT stock_qty FROM ingredients WHERE id=$1 FOR UPDATE',[need.ingredient_id])).rows[0];
     const short=Number(need.used)>Number(stock.stock_qty);
     await c.query('UPDATE ingredients SET stock_qty=GREATEST(0,stock_qty-$1::numeric) WHERE id=$2',[need.used,need.ingredient_id]);
     await c.query("INSERT INTO stock_movements(ingredient_id,kind,qty,ref,note,created_at) VALUES($1,'usage',-$2::numeric,$3,$4,$5)",[need.ingredient_id,need.used,'order:'+orderId,short?'STOCK SHORTAGE: usage exceeds stock':'delivered',at]);
     if(short)await c.query("INSERT INTO audit_logs(actor_name,action,detail,at) VALUES($1,'stock.shortage',$2,$3)",[actorName,'order '+orderId+' ingredient '+need.ingredient_id,at]);
    }
   }
   await c.query("UPDATE orders SET status=$1,delivered_at=CASE WHEN $1='delivered' THEN $2 ELSE delivered_at END WHERE id=$3",[status,at,orderId]);
   await c.query('INSERT INTO order_events(order_id,status,actor_name,at,actor_user_id) VALUES($1,$2,$3,$4,$5)',[orderId,status,actorName,at,actorUserId]);
   await c.query('INSERT INTO audit_logs(actor_name,action,detail,at) VALUES($1,$2,$3,$4)',[actorName,'order.'+status,orderId,at]);
   await this.refreshTable(c,order.table_id);
   return {id:orderId,status};
  });
 }

 async changePayment({paymentId,action,role,actorName='staff',reason=''}){
  if(!int(paymentId,1)||!['confirm','void','refund'].includes(action))throw new Error('invalid payment action');
  if(!(['void','refund'].includes(action)?['manager','owner']:['cashier','manager','owner']).includes(role))throw new Error('role cannot change payment');
  if(action!=='confirm'&&(!reason.trim()||reason.length>200))throw new Error('reason required');
  return this.transaction(async c=>{
   // Always lock order before payment to match recordPayment lock order.
   const snapshot=(await c.query('SELECT order_id FROM payments WHERE id=$1',[paymentId])).rows[0];if(!snapshot)throw new Error('payment not found');
   const order=(await c.query('SELECT * FROM orders WHERE id=$1 FOR UPDATE',[snapshot.order_id])).rows[0];
   const payment=(await c.query('SELECT * FROM payments WHERE id=$1 FOR UPDATE',[paymentId])).rows[0];
   if(action==='confirm'&&(payment.status!=='pending'||order.status==='cancelled'))throw new Error('payment not confirmable');
   if(action!=='confirm'&&payment.status!=='confirmed')throw new Error('payment not reversible');
   const status=action==='confirm'?'confirmed':action==='void'?'voided':'refunded';const at=Date.now();
   await c.query('UPDATE payments SET status=$1,status_changed_at=$2,status_changed_by=$3 WHERE id=$4',[status,at,actorName,paymentId]);
   const paid=Number((await c.query("SELECT COALESCE(SUM(amount),0) total FROM payments WHERE order_id=$1 AND status='confirmed'",[order.id])).rows[0].total);
   const next=paid>=Number(order.total)?'paid':order.status==='paid'?'billed':order.status;
   if(next!==order.status){await c.query('UPDATE orders SET status=$1 WHERE id=$2',[next,order.id]);await c.query('INSERT INTO order_events(order_id,status,actor_name,reason,at) VALUES($1,$2,$3,$4,$5)',[order.id,next,actorName,'payment '+action,at]);}
   await c.query('INSERT INTO audit_logs(actor_name,action,detail,at) VALUES($1,$2,$3,$4)',[actorName,'payment.'+action,'payment '+paymentId+': '+reason,at]);
   await this.refreshTable(c,order.table_id);
   return {id:paymentId,status,confirmed_total:paid,order_status:next};
  });
 }

 async assignTable({tableId,waiterUserId,actorUserId}){
  if(!int(tableId,1)||!int(actorUserId,1)||waiterUserId!==null&&!int(waiterUserId,1))throw new Error('invalid assignment');
  return this.transaction(async c=>{
   const actor=(await c.query('SELECT role,active FROM users WHERE id=$1 FOR SHARE',[actorUserId])).rows[0];if(!actor||Number(actor.active)!==1||!['owner','manager'].includes(actor.role))throw new Error('manager required');
   if(!(await c.query('SELECT id FROM restaurant_tables WHERE id=$1 FOR UPDATE',[tableId])).rowCount)throw new Error('table not found');
   if(waiterUserId===null)await c.query('DELETE FROM table_assignments WHERE table_id=$1',[tableId]);
   else{
    const waiter=(await c.query('SELECT role,active FROM users WHERE id=$1 FOR SHARE',[waiterUserId])).rows[0];if(!waiter||Number(waiter.active)!==1||waiter.role!=='waiter')throw new Error('active waiter required');
    await c.query('INSERT INTO table_assignments(table_id,waiter_user_id,assigned_at,assigned_by) VALUES($1,$2,$3,$4) ON CONFLICT(table_id) DO UPDATE SET waiter_user_id=EXCLUDED.waiter_user_id,assigned_at=EXCLUDED.assigned_at,assigned_by=EXCLUDED.assigned_by',[tableId,waiterUserId,Date.now(),actorUserId]);
   }
   await c.query('INSERT INTO audit_logs(actor_user_id,actor_name,action,detail,at) VALUES($1,$2,$3,$4,$5)',[actorUserId,'manager','table.assign','table '+tableId+' local waiter '+waiterUserId,Date.now()]);
  });
 }
 async listAssignedTables(user){
  return this.transaction(async c=>{
   const query="SELECT t.id,t.label,t.floor,t.status,t.qr_token,a.waiter_user_id assigned_waiter_id,u.name assigned_waiter_name FROM restaurant_tables t LEFT JOIN table_assignments a ON a.table_id=t.id LEFT JOIN users u ON u.id=a.waiter_user_id";
   const result=await c.query(query+(user.role==='waiter'?" WHERE a.waiter_user_id=$1 AND u.active=1 AND u.role='waiter'":'')+' ORDER BY t.floor,t.label',user.role==='waiter'?[user.userId]:[]);
   return result.rows.map(r=>{if(!['owner','manager'].includes(user.role))delete r.qr_token;return {...r,id:Number(r.id),assigned_waiter_id:r.assigned_waiter_id===null?null:Number(r.assigned_waiter_id)};});
  });
 }
 async waiterCanRead({orderId,userId}){
  return this.transaction(async c=>(await c.query("SELECT 1 FROM orders o JOIN table_assignments a ON a.table_id=o.table_id JOIN users u ON u.id=a.waiter_user_id WHERE o.id=$1 AND a.waiter_user_id=$2 AND u.active=1 AND u.role='waiter'",[orderId,userId])).rowCount>0);
 }

}
