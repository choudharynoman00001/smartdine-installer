-- Internal normalized PG change capture groundwork, not an external sync grant.
-- NEVER install on another database or expose this schema to anonymous clients.
CREATE TABLE IF NOT EXISTS smartdine_restaurant.change_cursor(id integer PRIMARY KEY CHECK(id=1),value bigint NOT NULL DEFAULT 0);
INSERT INTO smartdine_restaurant.change_cursor(id) VALUES(1) ON CONFLICT DO NOTHING;
CREATE TABLE IF NOT EXISTS smartdine_restaurant.change_outbox(seq bigint PRIMARY KEY,op_id uuid NOT NULL UNIQUE DEFAULT gen_random_uuid(),database_id uuid NOT NULL,table_name text NOT NULL,row_id text NOT NULL,kind text NOT NULL CHECK(kind IN('INSERT','UPDATE','DELETE')),payload jsonb NOT NULL,created_at timestamptz NOT NULL DEFAULT clock_timestamp(),transaction_id bigint NOT NULL);
ALTER TABLE smartdine_restaurant.change_cursor ENABLE ROW LEVEL SECURITY;
ALTER TABLE smartdine_restaurant.change_outbox ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON smartdine_restaurant.change_cursor,smartdine_restaurant.change_outbox FROM PUBLIC;
CREATE OR REPLACE FUNCTION smartdine_restaurant.capture_change() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog AS $$
DECLARE
 next_seq bigint;
 value jsonb;
 identity uuid;
BEGIN
 -- Singleton row lock serializes allocation through COMMIT, unlike a sequence.
 -- Any rollback returns the counter and event with the rest of its transaction.
 UPDATE smartdine_restaurant.change_cursor SET value=change_cursor.value+1 WHERE id=1 RETURNING change_cursor.value INTO next_seq;
 SELECT instance_id INTO STRICT identity FROM smartdine_restaurant.runtime_identity WHERE id=1;
 IF TG_OP='DELETE' THEN value=to_jsonb(OLD);ELSE value=to_jsonb(NEW);END IF;
 IF TG_TABLE_NAME='restaurant_tables' THEN value=jsonb_set(value,'{qr_token}',to_jsonb('analytical-disabled:'||(value->>'id')));END IF;
 IF TG_TABLE_NAME='orders' THEN value=jsonb_set(value,'{qr_receipt_hash}','null'::jsonb);END IF;
 -- Analytical target has no QR customer access need. No staff
 -- sessions, PIN hashes, users, assignment identity or auth attempts are captured.
 INSERT INTO smartdine_restaurant.change_outbox(seq,database_id,table_name,row_id,kind,payload,transaction_id) VALUES(next_seq,identity,TG_TABLE_NAME,value->>'id',TG_OP,value,txid_current());
 RETURN NULL;
END $$;

REVOKE ALL ON FUNCTION smartdine_restaurant.capture_change() FROM PUBLIC;
-- Read-only service baseline lock: no direct counter UPDATE grant needed.
CREATE OR REPLACE FUNCTION smartdine_restaurant.lock_capture_cursor() RETURNS bigint LANGUAGE sql SECURITY DEFINER SET search_path=pg_catalog AS $$ SELECT value FROM smartdine_restaurant.change_cursor WHERE id=1 FOR SHARE $$;
REVOKE ALL ON FUNCTION smartdine_restaurant.lock_capture_cursor() FROM PUBLIC;
