const positiveId=n=>Number.isSafeInteger(n)&&n>0;
const text=(v,max)=>typeof v==='string'&&v.trim().length>0&&v.trim().length<=max;
export async function catalogWrite(repo,{path,method,body,user}){
 if(!['owner','manager'].includes(user.role))return {status:403,error:'manager required'};
 return repo.transaction(async c=>{
  let result,action;
  if(path==='/api/menu/categories'&&method==='POST'){
   if(!text(body.name_en,80)||typeof(body.name_ur??'')!=='string'||(body.name_ur||'').length>80)throw new Error('invalid category');
   result=(await c.query('INSERT INTO categories(name_en,name_ur) VALUES($1,$2) RETURNING *',[body.name_en.trim(),body.name_ur||''])).rows[0];action='category.create';
  }else if(path==='/api/menu/items'&&method==='POST'){
   if(!text(body.name_en,80)||!positiveId(body.category_id)||!Number.isSafeInteger(body.price)||body.price<0||typeof(body.name_ur??'')!=='string'||(body.name_ur||'').length>80)throw new Error('invalid menu item');
   if(!(await c.query('SELECT 1 FROM categories WHERE id=$1',[body.category_id])).rowCount)throw new Error('category not found');
   result=(await c.query('INSERT INTO menu_items(category_id,name_en,name_ur,price) VALUES($1,$2,$3,$4) RETURNING *',[body.category_id,body.name_en.trim(),body.name_ur||'',body.price])).rows[0];action='menu.create';
  }else if(/^\/api\/menu\/items\/\d+$/.test(path)&&method==='PUT'){
   const id=Number(path.split('/').at(-1));const row=(await c.query('SELECT * FROM menu_items WHERE id=$1 FOR UPDATE',[id])).rows[0];if(!row)throw new Error('menu item not found');
   const allowed=['name_en','name_ur','description','price','photo','available','station'];if(Object.keys(body).some(k=>!allowed.includes(k))||!Object.keys(body).length)throw new Error('invalid menu fields');
   if(body.price!==undefined&&(!Number.isSafeInteger(body.price)||body.price<0))throw new Error('invalid price');
   if(body.available!==undefined&&typeof body.available!=='boolean')throw new Error('invalid availability');
   for(const field of ['name_en','name_ur','description','photo','station'])if(body[field]!==undefined&&(typeof body[field]!=='string'||body[field].length>({photo:250000,description:1000}[field]||80)))throw new Error('invalid text');
   if(body.name_en!==undefined&&!body.name_en.trim()||body.station!==undefined&&!body.station.trim())throw new Error('invalid name/station');
   const next={...row,...body};result=(await c.query('UPDATE menu_items SET name_en=$1,name_ur=$2,description=$3,price=$4,photo=$5,available=$6,station=$7 WHERE id=$8 RETURNING *',[next.name_en,next.name_ur,next.description,next.price,next.photo,Number(next.available),next.station,id])).rows[0];action='menu.update';
  }else return {status:404,error:'catalog route not implemented'};
  await c.query('INSERT INTO audit_logs(actor_user_id,actor_name,action,detail,at) VALUES($1,$2,$3,$4,$5)',[user.userId,user.name,action,String(result.id),Date.now()]);return {status:method==='POST'?201:200,result};
 });
}
