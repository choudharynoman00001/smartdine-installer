export async function updateIngredient(repo,id,body,user){
 if('stock_qty'in body||'unit'in body)throw new Error('invalid ingredient edit: use stock movements, unit immutable');
 return repo.transaction(async c=>{
  const row=(await c.query('SELECT * FROM ingredients WHERE id=$1 FOR UPDATE',[id])).rows[0];if(!row)throw new Error('ingredient not found');
  const name=body.name===undefined?row.name:typeof body.name==='string'?body.name.trim():'';const threshold=body.reorder_threshold??Number(row.reorder_threshold),supplier=body.supplier??row.supplier;
  if(!name||name.length>80||typeof supplier!=='string'||supplier.length>80||typeof threshold!=='number'||!Number.isFinite(threshold)||threshold<0||threshold>1e9)throw new Error('invalid ingredient');
  await c.query('SELECT pg_advisory_xact_lock(hashtextextended($1,0))',['ingredient:'+name.toLowerCase()]);if((await c.query('SELECT 1 FROM ingredients WHERE id<>$1 AND lower(trim(name))=lower($2)',[id,name])).rowCount)throw new Error('ingredient name exists');
  const updated=(await c.query('UPDATE ingredients SET name=$1,supplier=$2,reorder_threshold=$3 WHERE id=$4 RETURNING *',[name,supplier,threshold,id])).rows[0];
  await c.query('INSERT INTO audit_logs(actor_user_id,actor_name,action,detail,at) VALUES($1,$2,$3,$4,$5)',[user.userId,user.name,'ingredient.update',String(id),Date.now()]);return updated;
 });
}
export async function removeRecipe(repo,itemId,ingredientId,user){return repo.transaction(async c=>{const row=await c.query('DELETE FROM recipes WHERE menu_item_id=$1 AND ingredient_id=$2',[itemId,ingredientId]);if(!row.rowCount)throw new Error('recipe not found');await c.query('INSERT INTO audit_logs(actor_user_id,actor_name,action,detail,at) VALUES($1,$2,$3,$4,$5)',[user.userId,user.name,'recipe.remove',itemId+':'+ingredientId,Date.now()]);return {ok:true};});}
