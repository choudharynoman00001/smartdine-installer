import crypto from 'node:crypto';import {PostgresSessionStore} from './sessions.mjs';
export const hashPin=pin=>{const salt=crypto.randomBytes(16).toString('hex');return 'scrypt$'+salt+'$'+crypto.scryptSync(String(pin),Buffer.from(salt,'hex'),32).toString('hex');};
export function verifyPin(pin,stored){const [alg,salt,hash]=String(stored).split('$');if(alg!=='scrypt'||!/^[a-f0-9]{32}$/.test(salt)||!/^[a-f0-9]{64}$/.test(hash))return false;const got=crypto.scryptSync(pin,Buffer.from(salt,'hex'),32);return crypto.timingSafeEqual(got,Buffer.from(hash,'hex'));}
export class PostgresPinLogin{
 constructor(pool,{clock=Date.now,maxFailures=10,lockMs=15*60000,ipLimit=20,bucketKey,securePolicy=false}={}){if(!Buffer.isBuffer(bucketKey)||bucketKey.length<32)throw new Error('login bucket secret required');this.securePolicy=securePolicy;this.bucketKey=bucketKey;this.pool=pool;this.clock=clock;this.maxFailures=maxFailures;this.lockMs=lockMs;this.ipLimit=ipLimit;this.sessions=new PostgresSessionStore(pool,{clock});}
 async initialize(){await this.pool.query('SELECT bucket_hash,failures,locked_until,window_at FROM smartdine_restaurant.auth_attempts LIMIT 0');}
 async login(pin,ip){
  const validShape=typeof pin==='string'&&/^\d{4,8}$/.test(pin);
  const c=await this.pool.connect(),now=this.clock();let user;
  try{
   await c.query('BEGIN');
   await c.query("SELECT pg_advisory_xact_lock(hashtextextended('staff-admin',0))");
   if(this.securePolicy){const key='global-login-budget';await c.query('SELECT pg_advisory_xact_lock(hashtextextended($1,0))',[key]);const r=(await c.query('SELECT * FROM smartdine_restaurant.auth_attempts WHERE bucket_hash=$1 FOR UPDATE',[key])).rows[0];if(r&&Number(r.locked_until)>now){await c.query('COMMIT');return {status:429,error:'login temporarily locked; retry after 15 minutes or use an existing staff session'};}}
   const key=validShape?crypto.createHmac('sha256',this.bucketKey).update('pin:'+pin).digest('hex'):null,ipKey=crypto.createHmac('sha256',this.bucketKey).update('ip:'+String(ip)).digest('hex');
   await c.query('DELETE FROM smartdine_restaurant.auth_attempts WHERE window_at<$1 AND locked_until<=$2',[now-24*3600000,now]);
   // IP lock before PIN lock, same order on all workers, persisted across restarts.
   await c.query('SELECT pg_advisory_xact_lock(hashtextextended($1,0))',['login-ip:'+ipKey]);
   let ipRow=(await c.query('SELECT * FROM smartdine_restaurant.auth_attempts WHERE bucket_hash=$1 FOR UPDATE',[ipKey])).rows[0];
   if(!ipRow||now-Number(ipRow.window_at)>=60000)ipRow={failures:0,window_at:now};
   if(Number(ipRow.failures)>=this.ipLimit){await c.query('COMMIT');return {status:429,error:'too many attempts'};}
   await c.query('INSERT INTO smartdine_restaurant.auth_attempts(bucket_hash,failures,window_at) VALUES($1,$2,$3) ON CONFLICT(bucket_hash) DO UPDATE SET failures=EXCLUDED.failures,window_at=EXCLUDED.window_at',[ipKey,Number(ipRow.failures)+1,ipRow.window_at]);
   if(!validShape){await c.query('COMMIT');return {status:401,error:'invalid PIN'};}
   const bucketCount=Number((await c.query('SELECT COUNT(*) n FROM smartdine_restaurant.auth_attempts')).rows[0].n);
   if(bucketCount>=100000){await c.query('COMMIT');return {status:429,error:'too many attempts'};}
   await c.query('SELECT pg_advisory_xact_lock(hashtextextended($1,0))',['login-pin:'+key]);
   const row=(await c.query('SELECT * FROM smartdine_restaurant.auth_attempts WHERE bucket_hash=$1 FOR UPDATE',[key])).rows[0];
   if(row&&Number(row.locked_until)>now){await c.query('COMMIT');return {status:429,error:'too many attempts'};}
   const users=(await c.query('SELECT id,name,role,pin_hash FROM smartdine_restaurant.users WHERE active=1')).rows;
   user=users.find(u=>verifyPin(pin,u.pin_hash));
   if(!user){if(this.securePolicy){const key='global-login-budget',r=(await c.query('SELECT * FROM smartdine_restaurant.auth_attempts WHERE bucket_hash=$1 FOR UPDATE',[key])).rows[0],start=r&&now-Number(r.window_at)<15*60000?Number(r.window_at):now,count=start===Number(r?.window_at)?Number(r.failures)+1:1;await c.query('INSERT INTO smartdine_restaurant.auth_attempts(bucket_hash,failures,locked_until,window_at) VALUES($1,$2,$3,$4) ON CONFLICT(bucket_hash) DO UPDATE SET failures=EXCLUDED.failures,locked_until=EXCLUDED.locked_until,window_at=EXCLUDED.window_at',[key,count,count>=10?now+15*60000:0,start]);}const n=(row&&Number(row.locked_until)>0&&Number(row.locked_until)<=now?0:Number(row?.failures||0))+1;await c.query('INSERT INTO smartdine_restaurant.auth_attempts(bucket_hash,failures,locked_until,window_at) VALUES($1,$2,$3,$4) ON CONFLICT(bucket_hash) DO UPDATE SET failures=EXCLUDED.failures,locked_until=EXCLUDED.locked_until,window_at=EXCLUDED.window_at',[key,n>=this.maxFailures?0:n,n>=this.maxFailures?now+this.lockMs:0,now]);await c.query('COMMIT');return {status:401,error:'invalid PIN'};}
   if(this.securePolicy)await c.query('UPDATE smartdine_restaurant.users SET elevated_pin_ready=$1 WHERE id=$2',[pin.length>=6,user.id]);await c.query('DELETE FROM smartdine_restaurant.auth_attempts WHERE bucket_hash=$1',[key]);await c.query('INSERT INTO smartdine_restaurant.audit_logs(actor_user_id,actor_name,action,detail,at) VALUES($1,$2,$3,$4,$5)',[user.id,user.name,'auth.login','successful PIN verification',now]);const token=crypto.randomBytes(24).toString('hex');await c.query('INSERT INTO smartdine_restaurant.staff_sessions(token_hash,user_id,expires_at,created_at) VALUES($1,$2,$3,$4)',[crypto.createHash('sha256').update(token).digest('hex'),user.id,now+12*3600000,now]);await c.query('COMMIT');return {status:200,token,user:{id:Number(user.id),name:user.name,role:user.role}};
  }catch(e){await c.query('ROLLBACK');throw e;}finally{c.release();}

 }
}
