ALTER TABLE smartdine_restaurant.users ADD COLUMN login_id text;
UPDATE smartdine_restaurant.users SET login_id=replace(gen_random_uuid()::text,'-','') WHERE login_id IS NULL;
ALTER TABLE smartdine_restaurant.users ALTER COLUMN login_id SET NOT NULL;
ALTER TABLE smartdine_restaurant.users ALTER COLUMN login_id SET DEFAULT replace(gen_random_uuid()::text,'-','');
CREATE UNIQUE INDEX users_login_id ON smartdine_restaurant.users(login_id);
-- gen_random_bytes requires pgcrypto. Use core gen_random_uuid to avoid extension.
