// Private server read models. No browser role or caller-supplied SQL identifiers.
export function numericRows(row){return Object.fromEntries(Object.entries(row).map(([k,v])=>[k,typeof v==='string'&&/^-?\d+(?:\.\d+)?$/.test(v)&&['id','table_id','category_id','menu_item_id','order_item_id','amount','subtotal','tax','service_charge','discount','total','price','price_snapshot','qty','created_at','delivered_at','at','available','active','stock_qty','reorder_threshold','unit_cost','ingredient_id','waiter_user_id','assigned_at','sort','user_id','starts_at','ends_at','version','created_by','updated_at','tax_percent','service_charge_percent'].includes(k)?Number(v):v]));}
export async function menuModel(pool){
 const c=await pool.connect();try{await c.query('BEGIN ISOLATION LEVEL REPEATABLE READ');const cats=(await c.query('SELECT id,name_en,name_ur,sort FROM smartdine_restaurant.categories ORDER BY sort,id')).rows;const items=(await c.query('SELECT id,category_id,name_en,name_ur,description,price,photo,available,station FROM smartdine_restaurant.menu_items ORDER BY id')).rows;await c.query('COMMIT');return cats.map(cat=>({...numericRows(cat),items:items.filter(i=>i.category_id===cat.id).map(numericRows)}));}catch(e){await c.query('ROLLBACK');throw e;}finally{c.release();}
}
export async function orderList(pool,user,{status,id}={}){
 if(status&&!['new','preparing','ready','delivered','billed','paid','cancelled'].includes(status))throw new Error('invalid status filter');
 const c=await pool.connect();try{
  await c.query('BEGIN ISOLATION LEVEL REPEATABLE READ');
  const predicates=[],values=[];
  if(user.role==='waiter'){values.push(user.userId);predicates.push("EXISTS(SELECT 1 FROM smartdine_restaurant.table_assignments a JOIN smartdine_restaurant.users u ON u.id=a.waiter_user_id WHERE a.table_id=o.table_id AND a.waiter_user_id=$1 AND u.active=1 AND u.role='waiter')");}
  if(id){values.push(id);predicates.push('o.id=$'+values.length);}
  if(status){values.push(status);predicates.push('o.status=$'+values.length);}
  const rows=(await c.query('SELECT o.*,t.label table_label,t.floor table_floor FROM smartdine_restaurant.orders o LEFT JOIN smartdine_restaurant.restaurant_tables t ON t.id=o.table_id'+(predicates.length?' WHERE '+predicates.join(' AND '):'')+' ORDER BY o.created_at DESC,o.id LIMIT 200',values)).rows;
  const ids=rows.map(r=>r.id);const items=(await c.query('SELECT * FROM smartdine_restaurant.order_items WHERE order_id=ANY($1::text[]) ORDER BY id',[ids])).rows;
  const financial=!['waiter','kitchen'].includes(user.role);
  const payments=financial?(await c.query('SELECT * FROM smartdine_restaurant.payments WHERE order_id=ANY($1::text[]) ORDER BY id',[ids])).rows:[];
  const events=(await c.query('SELECT id,order_id,status,actor_name,reason,at FROM smartdine_restaurant.order_events WHERE order_id=ANY($1::text[]) ORDER BY id',[ids])).rows;
  await c.query('COMMIT');
  return rows.map(row=>{
   const order=numericRows(row);delete order.qr_receipt_hash;delete order.idempotency_key;
   order.items=items.filter(i=>i.order_id===row.id).map(i=>{const item=numericRows(i);if(!financial)delete item.price_snapshot;return item;});order.events=events.filter(e=>e.order_id===row.id).map(numericRows);
   if(financial){order.payments=payments.filter(p=>p.order_id===row.id).map(p=>{const payment=numericRows(p);delete payment.idempotency_key;return payment;});order.paid_total=order.payments.filter(p=>p.status==='confirmed').reduce((n,p)=>n+p.amount,0);order.pending_total=order.payments.filter(p=>p.status==='pending').reduce((n,p)=>n+p.amount,0);order.overpaid_amount=Math.max(0,order.paid_total-order.total);order.reconciliation_required=order.overpaid_amount>0;}
   else for(const key of ['subtotal','tax','service_charge','discount','total','customer_name'])delete order[key];
   return order;
  });
 }catch(e){await c.query('ROLLBACK');throw e;}finally{c.release();}
}
