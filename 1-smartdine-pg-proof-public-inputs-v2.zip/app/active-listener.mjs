// Explicit single-authority HTTPS operating API. No replica promotion/failover.
import https from 'node:https';import fs from 'node:fs';import tls from 'node:tls';import {X509Certificate} from 'node:crypto';
export function createActiveListener(handler,configuration){
 if(!configuration)return null;const {certFile,keyFile,origin}=configuration;const u=new URL(origin);if(u.protocol!=='https:'||u.pathname!=='/'||u.username||u.password||u.search||u.hash)throw new Error('exact active HTTPS origin required');const cert=fs.readFileSync(certFile),key=fs.readFileSync(keyFile),x=new X509Certificate(cert);tls.createSecureContext({cert,key});if(Date.now()<Date.parse(x.validFrom)||Date.now()>=Date.parse(x.validTo))throw new Error('active TLS certificate date invalid');
 return https.createServer({cert,key,minVersion:'TLSv1.2'},(req,res)=>{
  res.setHeader('strict-transport-security','max-age=86400');
  if(req.headers.host!==u.host){res.writeHead(421,{'content-type':'application/json'});return res.end(JSON.stringify({error:'configured origin required'}));}
  if(!['GET','HEAD','OPTIONS'].includes(req.method)&&(req.headers['sec-fetch-site']==='cross-site'||req.headers.origin&&req.headers.origin!==u.origin)){res.writeHead(403,{'content-type':'application/json'});return res.end(JSON.stringify({error:'cross-origin write refused'}));}
  // Cookies are set by the operating API; TLS is not inferred from forwarding.
  const secure=value=>Array.isArray(value)?value.map(secure):/;\s*Secure(?:;|$)/i.test(String(value))?value:String(value)+'; Secure';
  const set=res.setHeader.bind(res);res.setHeader=(name,value)=>set(name,String(name).toLowerCase()==='set-cookie'?secure(value):value);
  const write=res.writeHead.bind(res);res.writeHead=(status,...args)=>{const n=args.length-1,headers=args[n];if(headers&&typeof headers==='object'){if(Array.isArray(headers)){const updated=[...headers];for(let i=0;i<updated.length;i+=2)if(String(updated[i]).toLowerCase()==='set-cookie')updated[i+1]=secure(updated[i+1]);args[n]=updated;}else{args[n]={...headers};for(const name of Object.keys(headers))if(name.toLowerCase()==='set-cookie')args[n][name]=secure(headers[name]);}}return write(status,...args);};

  return handler(req,res);
 });
}
