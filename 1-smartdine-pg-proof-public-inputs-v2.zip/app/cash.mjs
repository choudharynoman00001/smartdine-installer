export async function cashReport(repo,{from=0,to=Number.MAX_SAFE_INTEGER}={}){
 if(!Number.isSafeInteger(from)||!Number.isSafeInteger(to)||from<0||to<from)throw new Error('invalid report range');
 return repo.transaction(async c=>{
  await c.query('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ');
  // Refunded collections were originally received, then paid back. Include both
  // legs at their own times. Voided mistaken records do not imply a cash transfer.
  const cashIn=Number((await c.query("SELECT COALESCE(SUM(amount),0) n FROM payments WHERE method='cash' AND status IN ('confirmed','refunded') AND created_at BETWEEN $1 AND $2",[from,to])).rows[0].n);
  const refunds=Number((await c.query("SELECT COALESCE(SUM(amount),0) n FROM payments WHERE method='cash' AND status='refunded' AND COALESCE(status_changed_at,created_at) BETWEEN $1 AND $2",[from,to])).rows[0].n);
  const expenses=Number((await c.query('SELECT COALESCE(SUM(amount),0) n FROM expenses WHERE created_at BETWEEN $1 AND $2',[from,to])).rows[0].n);
  const latest=(await c.query('SELECT * FROM cash_counts WHERE counted_at BETWEEN $1 AND $2 ORDER BY counted_at DESC,id DESC LIMIT 1',[from,to])).rows[0];
  const expected=cashIn-refunds-expenses;
  return {cash_in:cashIn,cash_refunded:refunds,expenses,expenses_assumed_cash:true,expected_drawer:expected,last_count:latest?{...latest,id:Number(latest.id),amount:Number(latest.amount),counted_at:Number(latest.counted_at)}:null,variance:latest?Number(latest.amount)-expected:null,basis:'recorded cash movements; expenses assumed drawer cash; no opening float or processor verification'};
 });
}
export async function cashCount(repo,body,user){
 if(!Number.isSafeInteger(body.amount)||body.amount<0||body.amount>1e9||typeof(body.note??'')!=='string')throw new Error('invalid cash count');
 return repo.transaction(async c=>{await c.query('INSERT INTO cash_counts(amount,note,actor_name,counted_at) VALUES($1,$2,$3,$4)',[body.amount,(body.note||'').slice(0,200),user.name,Date.now()]);await c.query('INSERT INTO audit_logs(actor_user_id,actor_name,action,detail,at) VALUES($1,$2,$3,$4,$5)',[user.userId,user.name,'cash.count','counted '+body.amount,Date.now()]);return {ok:true};});
}
