CREATE OR REPLACE FUNCTION smartdine_restaurant.guard_payment_history() RETURNS trigger LANGUAGE plpgsql SET search_path=pg_catalog AS $$
BEGIN
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'payment history deletion refused';END IF;
 IF (to_jsonb(NEW)-ARRAY['status','status_changed_at','status_changed_by','idempotency_key']) IS DISTINCT FROM (to_jsonb(OLD)-ARRAY['status','status_changed_at','status_changed_by','idempotency_key']) THEN RAISE EXCEPTION 'payment history rewrite refused';END IF;
 IF OLD.idempotency_key IS NOT NULL AND NEW.idempotency_key IS DISTINCT FROM OLD.idempotency_key THEN RAISE EXCEPTION 'payment identity rewrite refused';END IF;
 IF NEW.status IS DISTINCT FROM OLD.status AND NOT (OLD.status='pending' AND NEW.status='confirmed' OR OLD.status='confirmed' AND NEW.status IN ('refunded','voided')) THEN RAISE EXCEPTION 'payment status transition refused';END IF;
 IF NEW.status IS NOT DISTINCT FROM OLD.status AND (NEW.status_changed_at IS DISTINCT FROM OLD.status_changed_at OR NEW.status_changed_by IS DISTINCT FROM OLD.status_changed_by) THEN RAISE EXCEPTION 'payment status metadata rewrite refused';END IF;
 RETURN NEW;
END $$;
REVOKE ALL ON FUNCTION smartdine_restaurant.guard_payment_history() FROM PUBLIC;
CREATE TRIGGER payment_history_guard BEFORE UPDATE OR DELETE ON smartdine_restaurant.payments FOR EACH ROW EXECUTE FUNCTION smartdine_restaurant.guard_payment_history();
CREATE OR REPLACE FUNCTION smartdine_restaurant.guard_append_history() RETURNS trigger LANGUAGE plpgsql SET search_path=pg_catalog AS $$ BEGIN RAISE EXCEPTION 'append-only history mutation refused';END $$;
REVOKE ALL ON FUNCTION smartdine_restaurant.guard_append_history() FROM PUBLIC;
CREATE TRIGGER append_history_guard BEFORE UPDATE OR DELETE ON smartdine_restaurant.audit_logs FOR EACH ROW EXECUTE FUNCTION smartdine_restaurant.guard_append_history();
CREATE TRIGGER append_history_guard BEFORE UPDATE OR DELETE ON smartdine_restaurant.order_events FOR EACH ROW EXECUTE FUNCTION smartdine_restaurant.guard_append_history();
CREATE TRIGGER append_history_guard BEFORE UPDATE OR DELETE ON smartdine_restaurant.cash_counts FOR EACH ROW EXECUTE FUNCTION smartdine_restaurant.guard_append_history();
ALTER TABLE smartdine_restaurant.users ADD COLUMN elevated_pin_ready boolean NOT NULL DEFAULT false;
-- Dedicated restaurant database only: no inherited public-schema CREATE.
REVOKE CREATE ON SCHEMA public FROM PUBLIC;
