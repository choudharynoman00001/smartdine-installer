// sync.mjs - cloud-sync engine core (blueprint p3 "implement and test cloud synchronization",
// p5 "queue cloud sync with unique operation IDs and server-side conflict rules").
//
// Model: op-replay between two SmartDine nodes over authenticated HTTP.
// - Every local mutation is appended to a durable outbox (sync_ops) in the SAME SQLite
//   transaction as the mutation itself, so a crash can never lose or half-record an op.
// - Each op carries a globally unique op_id (UUID) + origin node_id; receivers apply
//   idempotently by op_id and by natural entity ids (duplicate submissions safe).
// - Conflict rules are server-side: last-writer-wins per entity using (at, node_id)
//   via sync_entity_clock; event logs are append-only with (order_id,status,at,actor) dedupe.
// - Retries with exponential backoff; recovery after power loss is automatic because
//   outbox, cursors and clocks all live in the same SQLite file.
//
// v1 scope: single configured peer (restaurant LAN server <-> one cloud peer). Staff/users
// and PINs NEVER sync (credentials stay local per node). Cash-drawer counts stay local.
// PRIMARY/REPLICA WRITE GATES (not a partition-safe single-writer guarantee):
// - Each node has a persisted role: 'primary' (accepts mutations) or 'replica' (read-only;
//   every mutating /api route returns 409 replica_read_only). With sync configured the
//   default role is REPLICA - a node must explicitly claim primary (SMARTDINE_NODE_ROLE or
//   owner-authed POST /api/sync/promote).
// - Dual-primary split-brain: the worker compares peer role each cycle; if both are primary
//   at the same epoch, the node with the lexicographically LARGER node_id demotes itself to
//   replica (persisted) AFTER CONTACT. Both can write during a network partition.
// - Takeover fencing: promote bumps a persisted cluster epoch stamped on every op. A node
//   that learns a newer epoch from its peer (push 409 or pull header) fences itself
//   (fenced=1, all mutations 409) so a stale old primary can never write again; epoch-
//   mismatching ops are rejected whole-batch. Recovery of a fenced node = re-sync from the
//   current primary (operator procedure), never automatic.
// - Defense in depth: payment replay verifies (order_id, amount, method) identity before
//   update; op replay rejects the node's own node_id (loop guard); per-op SAVEPOINT.
// Simulated-peer tested only: this does not certify Supabase/Vercel or physical devices.
import crypto from 'node:crypto';

export function initSync(db) {
  db.exec(`
CREATE TABLE IF NOT EXISTS sync_node(
  id INTEGER PRIMARY KEY CHECK (id = 1),
  node_id TEXT NOT NULL,
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS sync_ops(
  seq INTEGER PRIMARY KEY AUTOINCREMENT,
  op_id TEXT NOT NULL UNIQUE,
  node_id TEXT NOT NULL,
  kind TEXT NOT NULL,
  payload TEXT NOT NULL,
  at INTEGER NOT NULL,
  pushed INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS sync_entity_clock(
  entity TEXT NOT NULL,
  entity_id TEXT NOT NULL,
  at INTEGER NOT NULL,
  node_id TEXT NOT NULL,
  PRIMARY KEY (entity, entity_id)
);
CREATE TABLE IF NOT EXISTS sync_id_map(
  origin_node TEXT NOT NULL,
  table_name TEXT NOT NULL,
  origin_id INTEGER NOT NULL,
  local_id INTEGER NOT NULL,
  PRIMARY KEY (origin_node, table_name, origin_id)
);
CREATE TABLE IF NOT EXISTS sync_deadletter(
  op_id TEXT PRIMARY KEY,
  node_id TEXT NOT NULL,
  kind TEXT NOT NULL,
  payload TEXT NOT NULL,
  at INTEGER NOT NULL,
  epoch INTEGER NOT NULL,
  reason TEXT NOT NULL,
  attempts INTEGER NOT NULL DEFAULT 1,
  next_try INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS sync_state(
  id INTEGER PRIMARY KEY CHECK (id = 1),
  pull_cursor INTEGER NOT NULL DEFAULT 0,
  failures INTEGER NOT NULL DEFAULT 0,
  next_try INTEGER NOT NULL DEFAULT 0,
  role TEXT NOT NULL DEFAULT 'primary',
  epoch INTEGER NOT NULL DEFAULT 1,
  fenced INTEGER NOT NULL DEFAULT 0
);
INSERT OR IGNORE INTO sync_state(id) VALUES(1);`);
  // upgrade path for delta-dev DBs created before role/epoch/fenced existed
  for (const ddl of ["ALTER TABLE sync_state ADD COLUMN role TEXT NOT NULL DEFAULT 'primary'",
    'ALTER TABLE sync_state ADD COLUMN epoch INTEGER NOT NULL DEFAULT 1',
    'ALTER TABLE sync_state ADD COLUMN fenced INTEGER NOT NULL DEFAULT 0',
    'ALTER TABLE sync_ops ADD COLUMN epoch INTEGER NOT NULL DEFAULT 1']) {
    try { db.exec(ddl); } catch { /* column already present */ }
  }
  // role resolution: explicit env wins each boot (operator intent); otherwise persisted;
  // with sync configured a never-configured node defaults to REPLICA (safe: read-only
  // until someone explicitly claims primary); standalone (no sync token) defaults primary.
  const envRole = String(process.env.SMARTDINE_NODE_ROLE || '').toLowerCase();
  if (envRole === 'primary' || envRole === 'replica') {
    db.prepare('UPDATE sync_state SET role=? WHERE id=1').run(envRole);
  } else {
    const cur = db.prepare('SELECT role FROM sync_state WHERE id=1').get();
    const fresh = db.prepare('SELECT COUNT(*) n FROM sync_ops').get().n === 0 && cur.role === 'primary';
    if (fresh && process.env.SMARTDINE_SYNC_TOKEN && !process.env.SMARTDINE_NODE_ROLE)
      db.prepare("UPDATE sync_state SET role='replica' WHERE id=1").run();
  }
  let row = db.prepare('SELECT node_id FROM sync_node WHERE id = 1').get();
  if (!row) {
    row = { node_id: crypto.randomUUID() };
    db.prepare('INSERT INTO sync_node(id,node_id,created_at) VALUES(1,?,?)').run(row.node_id, Date.now());
  }
  return row.node_id;
}

// Append an op to the durable outbox. Call INSIDE the mutation's transaction.
export function recordOp(db, nodeId, kind, payload) {
  const epoch = db.prepare('SELECT epoch FROM sync_state WHERE id=1').get().epoch;
  db.prepare('INSERT INTO sync_ops(op_id,node_id,kind,payload,at,epoch) VALUES(?,?,?,?,?,?)')
    .run(crypto.randomUUID(), nodeId, kind, JSON.stringify(payload), Date.now(), epoch);
}

// Write gate for the router: returns null when writes are allowed, else a reason string.
export function syncWriteBlock(db) {
  if (!syncEnabled()) return null;
  const st = db.prepare('SELECT role, fenced, epoch FROM sync_state WHERE id=1').get();
  if (st.fenced) return `sync fenced: a newer primary took over (this node is stale at epoch ${st.epoch}). Re-sync from the current primary before writing`;
  if (st.role !== 'primary') return 'sync replica: this node is read-only; write to the primary or promote this node (POST /api/sync/promote)';
  return null;
}

// Deliberate operator takeover: become primary at a NEW epoch. Fences every other node
// that learns this epoch. Owner-authed at the route layer.
export function promoteToPrimary(db) {
  db.prepare('UPDATE sync_state SET role=?, epoch=epoch+1, fenced=0 WHERE id=1').run('primary');
  return db.prepare('SELECT role, epoch FROM sync_state WHERE id=1').get();
}

function setFenced(db) { db.prepare('UPDATE sync_state SET fenced=1 WHERE id=1').run(); }
function demoteToReplica(db) { db.prepare("UPDATE sync_state SET role='replica' WHERE id=1").run(); }

// Last-writer-wins clock: true (and records) when (at,nodeId) beats the stored clock.
function clockWins(db, entity, entityId, at, nodeId) {
  const row = db.prepare('SELECT at, node_id FROM sync_entity_clock WHERE entity = ? AND entity_id = ?').get(entity, String(entityId));
  if (!row || at > row.at || (at === row.at && nodeId > row.node_id)) {
    db.prepare('INSERT INTO sync_entity_clock(entity,entity_id,at,node_id) VALUES(?,?,?,?) ON CONFLICT(entity,entity_id) DO UPDATE SET at=excluded.at, node_id=excluded.node_id')
      .run(entity, String(entityId), at, nodeId);
    return true;
  }
  return false;
}

const COLS = {
  orders: ['id','table_id','source','status','order_type','customer_name','note','subtotal','tax','service_charge','discount','total','idempotency_key','created_at','delivered_at'],
  order_items: ['id','order_id','menu_item_id','name_snapshot','price_snapshot','qty','notes','station'],
  order_events: ['order_id','status','actor_user_id','actor_name','reason','at'],
  payments: ['id','order_id','amount','method','status','reference','recorded_by','recorded_by_name','created_at','status_changed_at','status_changed_by'],
  categories: ['sync_key','id','name_en','name_ur','sort'],
  menu_items: ['sync_key','id','category_id','name_en','name_ur','description','price','photo','available','station'],
  restaurant_tables: ['sync_key','id','label','floor','qr_token','status'],
  expenses: ['id','category','amount','spent_on','notes','actor_user_id','created_at'],
  ingredients: ['sync_key','id','name','unit','stock_qty','reorder_threshold','supplier'],
  stock_movements: ['id','ingredient_id','kind','qty','ref','note','actor_user_id','created_at','unit_cost'],
};
function insertRow(db, table, row) {
  const cols = COLS[table].filter(c => row[c] !== undefined);
  db.prepare(`INSERT INTO ${table}(${cols.join(',')}) VALUES(${cols.map(() => '?').join(',')})`)
    .run(...cols.map(c => row[c]));
}

// ---- identity remap: origin (node,table,integer id) -> local id ----------------------
// Local autoincrement ids are per-node. Only immutable, persisted seed keys
// identify twins. Same ids/names are NOT identity. Legacy unkeyed rows need a
// deliberate initial snapshot/pairing; we never guess their provenance.
const IDENTITY_TABLES = new Set(['menu_items','categories','ingredients','restaurant_tables']);

function mapGet(db, originNode, table, originId) {
  const m = db.prepare('SELECT local_id FROM sync_id_map WHERE origin_node=? AND table_name=? AND origin_id=?')
    .get(originNode, table, originId);
  return m ? m.local_id : null;
}
function mapPut(db, originNode, table, originId, localId) {
  db.prepare('INSERT OR IGNORE INTO sync_id_map(origin_node,table_name,origin_id,local_id) VALUES(?,?,?,?)')
    .run(originNode, table, originId, localId);
}
// Resolve a referenced entity. With a payload row, an unmapped same-id row whose identity
// column matches is a seed twin and maps 1:1. Without a match: dependency missing.
function requireMapping(db, originNode, table, originId, row) {
  const existing = mapGet(db, originNode, table, originId);
  if (existing != null) return existing;
  if (row?.sync_key && IDENTITY_TABLES.has(table)) {
    const local = db.prepare(`SELECT id FROM ${table} WHERE sync_key=?`).get(row.sync_key);
    if (local) {
      mapPut(db, originNode, table, originId, local.id);
      return local.id;
    }
  }
  throw new Error(`dependency missing: ${table}#${originId} from ${originNode}`);
}
// Insert a remote row under a FRESH local id (never clobbering a different local row),
// or return the existing mapping on redelivery. extra overrides columns (e.g. remapped FKs).
function insertMapped(db, originNode, table, row, extra = {}) {
  const existing = mapGet(db, originNode, table, row.id);
  if (existing != null) return { localId: existing, inserted: false };
  const merged = { ...row, ...extra };
  const cols = COLS[table].filter(c => c !== 'id' && merged[c] !== undefined);
  const r = db.prepare(`INSERT INTO ${table}(${cols.join(',')}) VALUES(${cols.map(() => '?').join(',')})`)
    .run(...cols.map(c => merged[c]));
  const localId = Number(r.lastInsertRowid);
  mapPut(db, originNode, table, row.id, localId);
  return { localId, inserted: true };
}

// Apply one remote op. Idempotent: caller has already inserted the op row (op_id UNIQUE).
// Throws on missing dependencies or conflicts; the caller dead-letters and retries, so
// ops arriving before their dependencies resolve on a later cycle. Never calls recordOp.
export function applyOp(db, op) {
  const p = JSON.parse(op.payload);
  const at = p.at || op.at;
  const origin = op.node_id;
  switch (op.kind) {
    case 'order.create': {
      if (db.prepare('SELECT 1 FROM orders WHERE id = ?').get(p.order.id)) return; // duplicate
      if (p.order.idempotency_key != null) {
        const clash = db.prepare('SELECT id FROM orders WHERE idempotency_key = ?').get(p.order.idempotency_key);
        if (clash && clash.id !== p.order.id) return; // same logical order already here under another id
      }
      const localTable = p.order.table_id != null ? requireMapping(db, origin, 'restaurant_tables', p.order.table_id, p.table || null) : null;
      insertRow(db, 'orders', { ...p.order, table_id: localTable });
      for (const it of p.items || []) {
        const localItem = requireMapping(db, origin, 'menu_items', it.menu_item_id, (p.menu || []).find(m => m.id === it.menu_item_id) || null);
        insertMapped(db, origin, 'order_items', it, { order_id: p.order.id, menu_item_id: localItem });
      }
      for (const ev of p.events || []) applyEvent(db, ev, origin);
      clockWins(db, 'orders', p.order.id, at, origin);
      refreshReplicaTable(db, localTable);
      return;
    }
    case 'order.event': {
      requireOrder(db, p.event.order_id);
      applyEvent(db, p.event, origin);
      // order status follows the newest event across all nodes (clock differences tolerated
      // by the (at, node_id) total order; equal clocks break ties deterministically)
      if (clockWins(db, 'orders', p.event.order_id, p.event.at, origin)) {
        db.prepare("UPDATE orders SET status = ?, delivered_at = CASE WHEN ? = 'delivered' THEN ? ELSE delivered_at END WHERE id = ?")
          .run(p.event.status, p.event.status, p.event.at, p.event.order_id);
      }
      const t = db.prepare('SELECT table_id FROM orders WHERE id=?').get(p.event.order_id);
      if (t) refreshReplicaTable(db, t.table_id);
      return;
    }
    case 'order.money': {
      requireOrder(db, p.order_id);
      if (!clockWins(db, 'order_money', p.order_id, at, origin)) return;
      db.prepare('UPDATE orders SET subtotal=?, tax=?, service_charge=?, discount=?, total=? WHERE id=?')
        .run(p.subtotal, p.tax, p.service_charge, p.discount, p.total, p.order_id);
      return;
    }
    case 'order.move': {
      requireOrder(db, p.order_id);
      if (!clockWins(db, 'order_table', p.order_id, at, origin)) return;
      const localTable = requireMapping(db, origin, 'restaurant_tables', p.table_id, p.table || null);
      const before = db.prepare('SELECT table_id FROM orders WHERE id=?').get(p.order_id);
      db.prepare('UPDATE orders SET table_id=? WHERE id=?').run(localTable, p.order_id);
      if (before) refreshReplicaTable(db, before.table_id);
      refreshReplicaTable(db, localTable);
      return;
    }
    case 'order.split': {
      if (db.prepare('SELECT 1 FROM orders WHERE id = ?').get(p.new_order.id)) return; // already split here
      const localTable = p.new_order.table_id != null ? requireMapping(db, origin, 'restaurant_tables', p.new_order.table_id, p.table || null) : null;
      insertRow(db, 'orders', { ...p.new_order, table_id: localTable });
      const localIds = (p.moved_item_ids || []).map(id => requireMapping(db, origin, 'order_items', id, null));
      if (localIds.length) db.prepare(`UPDATE order_items SET order_id=? WHERE id IN (${localIds.map(() => '?').join(',')})`).run(p.new_order.id, ...localIds);
      for (const ev of p.events || []) applyEvent(db, ev, origin);
      refreshReplicaTable(db, localTable);
      return;
    }
    case 'order.merge': {
      requireOrder(db, p.from_id); requireOrder(db, p.into_id);
      const from = db.prepare('SELECT 1 FROM orders WHERE id=? AND status != \'cancelled\'').get(p.from_id);
      if (!from) return; // already merged/cancelled here
      db.prepare('UPDATE order_items SET order_id=? WHERE order_id=?').run(p.into_id, p.from_id);
      db.prepare("UPDATE orders SET status='cancelled' WHERE id=?").run(p.from_id);
      for (const ev of p.events || []) applyEvent(db, ev, origin);
      clockWins(db, 'orders', p.from_id, at, origin);
      const t1 = db.prepare('SELECT table_id FROM orders WHERE id=?').get(p.from_id);
      const t2 = db.prepare('SELECT table_id FROM orders WHERE id=?').get(p.into_id);
      if (t1) refreshReplicaTable(db, t1.table_id);
      if (t2) refreshReplicaTable(db, t2.table_id);
      return;
    }
    case 'payment.upsert': {
      requireOrder(db, p.row.order_id);
      if (!clockWins(db, 'payments', `${origin}:${p.row.id}`, at, origin)) return;
      const localId = mapGet(db, origin, 'payments', p.row.id);
      if (localId != null) {
        const cur = db.prepare('SELECT order_id, amount, method FROM payments WHERE id=?').get(localId);
        if (cur.order_id !== p.row.order_id || cur.amount !== p.row.amount || cur.method !== p.row.method)
          throw new Error(`payment ${p.row.id} from ${origin} identity mismatch - refusing to overwrite local ${localId}`);
        db.prepare('UPDATE payments SET status=?, status_changed_at=?, status_changed_by=? WHERE id=?')
          .run(p.row.status, p.row.status_changed_at, p.row.status_changed_by, localId);
      } else {
        // recorded_by nulled: users are local-only, the FK target does not replicate
        insertMapped(db, origin, 'payments', p.row, { recorded_by: null });
      }
      return;
    }
    case 'menu.category.upsert': return upsertMappedLww(db, origin, 'categories', p.row, at);
    case 'menu.item.upsert': {
      const extra = {};
      if (p.row.category_id != null) extra.category_id = requireMapping(db, origin, 'categories', p.row.category_id, p.category || null);
      return upsertMappedLww(db, origin, 'menu_items', p.row, at, extra);
    }
    case 'table.upsert': return upsertMappedLww(db, origin, 'restaurant_tables', p.row, at);
    case 'ingredient.upsert': return upsertMappedLww(db, origin, 'ingredients', p.row, at);
    case 'recipe.set': {
      const localItem = requireMapping(db, origin, 'menu_items', p.menu_item_id, p.menu_item || null);
      if (!clockWins(db, 'recipes', `${origin}:${p.menu_item_id}`, at, origin)) return;
      db.prepare('DELETE FROM recipes WHERE menu_item_id=?').run(localItem);
      for (const r of p.rows || []) {
        const ingRow = (p.ingredients || []).find(i => i.id === r.ingredient_id) || null;
        const localIng = requireMapping(db, origin, 'ingredients', r.ingredient_id, ingRow);
        db.prepare('INSERT OR IGNORE INTO recipes(menu_item_id,ingredient_id,qty) VALUES(?,?,?)').run(localItem, localIng, r.qty);
      }
      return;
    }
    case 'expense.create': {
      insertMapped(db, origin, 'expenses', p.row, { actor_user_id: null });
      return;
    }
    case 'inventory.movement': {
      const localIng = requireMapping(db, origin, 'ingredients', p.row.ingredient_id, p.ingredient || null);
      const r = insertMapped(db, origin, 'stock_movements', p.row, { ingredient_id: localIng, actor_user_id: null });
      if (!r.inserted) return; // redelivery: effect already replayed exactly once
      // honest stock arithmetic: NO clamping - a deficit stays visible as negative stock
      // (order-independent: final stock = creation value + sum of all movement deltas)
      db.prepare('UPDATE ingredients SET stock_qty = stock_qty + ? WHERE id=?').run(p.row.qty, localIng);
      return;
    }
    case 'settings.update': {
      if (!clockWins(db, 'restaurants', 1, at, origin)) return;
      db.prepare('UPDATE restaurants SET name=?, currency=?, tax_percent=?, service_charge_percent=?, default_language=?, updated_at=? WHERE id=1')
        .run(p.row.name, p.row.currency, p.row.tax_percent, p.row.service_charge_percent, p.row.default_language, at);
      return;
    }
    default:
      throw new Error('unknown op kind: ' + op.kind);
  }
}
function requireOrder(db, id) {
  if (!db.prepare('SELECT 1 FROM orders WHERE id=?').get(id)) throw new Error('dependency missing: order ' + id);
}
function applyEvent(db, ev, nodeId) {
  requireOrder(db, ev.order_id);
  const dup = db.prepare('SELECT 1 FROM order_events WHERE order_id=? AND status=? AND at=? AND actor_name=?')
    .get(ev.order_id, ev.status, ev.at, ev.actor_name || '');
  if (!dup) {
    db.prepare('INSERT INTO order_events(order_id,status,actor_user_id,actor_name,reason,at) VALUES(?,?,?,?,?,?)')
      .run(ev.order_id, ev.status, null, ev.actor_name || '', ev.reason || '', ev.at);
  }
}
// LWW upsert keyed by ORIGIN identity: the clock and the map are both (node,id), so two
// nodes' rows with the same integer id are different entities, never silently merged.
function upsertMappedLww(db, origin, table, row, at, extra = {}) {
  if (!clockWins(db, table, `${origin}:${row.id}`, at, origin)) return;
  const localId = mapGet(db, origin, table, row.id)
    ?? (() => { try { return requireMapping(db, origin, table, row.id, row); } catch { return null; } })();
  if (localId != null) {
    // ingredients: stock_qty is EXCLUDED - absolute snapshots would clobber movement
    // replay on the peer; stock converges through stock_movements ops only.
    const skip = new Set(['id', 'sync_key', ...(table === 'ingredients' ? ['stock_qty'] : []), ...Object.keys(extra)]);
    const cols = COLS[table].filter(c => !skip.has(c) && row[c] !== undefined);
    if (cols.length) db.prepare(`UPDATE ${table} SET ${cols.map(c => c + '=?').join(',')} WHERE id=?`).run(...cols.map(c => row[c]), localId);
    for (const [k, v] of Object.entries(extra)) db.prepare(`UPDATE ${table} SET ${k}=? WHERE id=?`).run(v, localId);
  } else {
    insertMapped(db, origin, table, row, extra);
  }
}

// Replica-side floor truthfulness: same rule as server.mjs refreshTableStatus, kept local
// here so applied remote order ops update the floor map without re-entering the outbox.
function refreshReplicaTable(db, tableId) {
  if (!tableId) return;
  const open = db.prepare("SELECT status FROM orders WHERE table_id = ? AND status NOT IN ('paid','cancelled')").all(tableId);
  let st = 'available';
  if (open.some(o => o.status === 'billed')) st = 'bill_pending';
  else if (open.some(o => o.status === 'ready')) st = 'order_ready';
  else if (open.length) st = 'occupied';
  db.prepare('UPDATE restaurant_tables SET status = ? WHERE id = ?').run(st, tableId);
}

// ---- dead letter: a failed op is preserved with its reason and retried every cycle ----
export function deadletter(db, op, reason) {
  db.prepare(`INSERT INTO sync_deadletter(op_id,node_id,kind,payload,at,epoch,reason,attempts,next_try) VALUES(?,?,?,?,?,?,?,1,?)
    ON CONFLICT(op_id) DO UPDATE SET reason=excluded.reason, attempts=attempts+1, next_try=excluded.next_try`)
    .run(op.op_id, String(op.node_id || ''), op.kind, op.payload, Number(op.at) || Date.now(), Number(op.epoch) || 1,
      String(reason).slice(0, 300), Date.now() + 2000); // first retry quickly; backoff grows per attempt
}
// Retry due dead-lettered ops; resolves automatically once dependencies have arrived.
export function retryDeadletter(db, nodeId, log = () => {}) {
  const myEpoch = db.prepare('SELECT epoch FROM sync_state WHERE id=1').get().epoch;
  const due = db.prepare('SELECT * FROM sync_deadletter WHERE next_try <= ? ORDER BY at LIMIT 50').all(Date.now());
  let resolved = 0;
  for (const op of due) {
    if (db.prepare('SELECT 1 FROM sync_ops WHERE op_id=?').get(op.op_id)) {
      db.prepare('DELETE FROM sync_deadletter WHERE op_id=?').run(op.op_id); // already applied meanwhile
      resolved++;
      continue;
    }
    if (String(op.node_id) === nodeId || op.epoch !== myEpoch) {
      db.prepare('DELETE FROM sync_deadletter WHERE op_id=?').run(op.op_id); // own op or fenced epoch: unactionable
      continue;
    }
    db.exec('SAVEPOINT retry_op');
    try {
      applyOp(db, op);
      db.prepare('INSERT OR IGNORE INTO sync_ops(op_id,node_id,kind,payload,at,pushed,epoch) VALUES(?,?,?,?,?,1,?)')
        .run(op.op_id, op.node_id, op.kind, op.payload, op.at, op.epoch);
      db.prepare('DELETE FROM sync_deadletter WHERE op_id=?').run(op.op_id);
      resolved++;
      db.exec('RELEASE retry_op');
      log('sync: dead-lettered op resolved', op.kind, op.op_id);
    } catch (e) {
      db.exec('ROLLBACK TO retry_op'); db.exec('RELEASE retry_op');
      const n = op.attempts + 1;
      db.prepare('UPDATE sync_deadletter SET attempts=?, next_try=? WHERE op_id=?')
        .run(n, Date.now() + Math.min(60000, 1000 * 2 ** Math.min(n, 6)), op.op_id);
    }
  }
  return resolved;
}

// ---- operator takeover recovery (explicit, never automatic, never claimed lossless) ----
export function exportUnpushedOps(db, nodeId) {
  return db.prepare('SELECT op_id,node_id,kind,payload,at,epoch FROM sync_ops WHERE node_id=? AND pushed=0 ORDER BY seq').all(nodeId);
}
// Adopt a fenced node's stranded ops into the CURRENT epoch on a healthy primary.
// Identities are preserved via the id map, so recovered rows never collide with rows
// created after takeover. Already-replicated ops dedupe by op_id.
export function importOps(db, nodeId, ops) {
  const st = db.prepare('SELECT role, epoch, fenced FROM sync_state WHERE id=1').get();
  if (st.fenced || st.role !== 'primary') throw new Error('import requires a healthy primary node');
  let imported = 0, skipped = 0, failed = 0;
  db.exec('BEGIN IMMEDIATE');
  try {
    for (const op of (Array.isArray(ops) ? ops : []).slice(0, 2000)) {
      if (!op || !op.op_id || !op.kind || typeof op.payload !== 'string' || op.payload.length > 262144) { skipped++; continue; }
      if (String(op.node_id || '') === nodeId) { skipped++; continue; } // never re-import own ops
      db.exec('SAVEPOINT sync_op');
      try {
        const r = db.prepare('INSERT OR IGNORE INTO sync_ops(op_id,node_id,kind,payload,at,pushed,epoch) VALUES(?,?,?,?,?,1,?)')
          .run(op.op_id, String(op.node_id || ''), op.kind, op.payload, Number(op.at) || Date.now(), st.epoch);
        if (r.changes) { applyOp(db, op); imported++; } else skipped++;
        db.exec('RELEASE sync_op');
      } catch (e) {
        db.exec('ROLLBACK TO sync_op'); db.exec('RELEASE sync_op');
        deadletter(db, { ...op, epoch: st.epoch }, 'import: ' + String(e.message || e));
        failed++;
      }
    }
    db.exec('COMMIT');
  } catch (e) { db.exec('ROLLBACK'); throw e; }
  return { imported, skipped, failed };
}

// Explicit owner-selected legacy identity pairing. No names/row ranges infer identity.
// This does not authenticate a recovery file: operator must verify its source offline.
export function pairLegacyRows(db, source, mappings, commit = false) {
  const allowed = new Set(['categories','menu_items','ingredients','restaurant_tables']);
  if (!source || !Array.isArray(mappings) || !mappings.length || mappings.length > 500) throw new Error('source and 1-500 explicit mappings required');
  const planned = []; const targets = new Set();
  for (const m of mappings) {
    if (!allowed.has(m.table) || !Number.isSafeInteger(m.origin_id) || !Number.isSafeInteger(m.local_id) || m.origin_id < 1 || m.local_id < 1) throw new Error('invalid mapping');
    const row = db.prepare(`SELECT * FROM ${m.table} WHERE id=?`).get(m.local_id);
    if (!row || row.sync_key !== m.local_sync_key) throw new Error('local identity changed or missing; preview current rows again');
    const existing = mapGet(db,source,m.table,m.origin_id);
    if (existing != null && existing !== m.local_id) throw new Error('existing mapping conflict; replacement forbidden');
    const target = m.table + ':' + m.local_id;
    if (targets.has(target)) throw new Error('two source rows cannot map to one local row');
    targets.add(target);
    const reverse = db.prepare('SELECT origin_id FROM sync_id_map WHERE origin_node=? AND table_name=? AND local_id=?').get(source,m.table,m.local_id);
    if (reverse && reverse.origin_id !== m.origin_id) throw new Error('target already paired with another source row');
    planned.push({table:m.table,origin_id:m.origin_id,local_id:m.local_id,local_sync_key:row.sync_key,label:row.name_en || row.name || row.label});
  }
  if (commit) {
    db.exec('BEGIN IMMEDIATE');
    try { for (const m of planned) mapPut(db,source,m.table,m.origin_id,m.local_id); db.exec('COMMIT'); }
    catch(e) { db.exec('ROLLBACK'); throw e; }
  }
  return planned;
}

// ---- HTTP peer protocol (both nodes run the same code) ----
export function syncEnabled() { return !!process.env.SMARTDINE_SYNC_TOKEN; }
function tokenOk(req) {
  const a = req.headers.authorization || '';
  const t = process.env.SMARTDINE_SYNC_TOKEN || '';
  const got = a.startsWith('Bearer ') ? a.slice(7) : '';
  return t.length >= 16 && got.length === t.length && crypto.timingSafeEqual(Buffer.from(got), Buffer.from(t));
}
export function handleSyncApi(req, res, u, raw, db, send, nodeId) {
  if (!syncEnabled()) return send(res, 404, { error: 'sync not configured' });
  if (!tokenOk(req)) return send(res, 401, { error: 'bad sync token' });
  const p = u.pathname;
  if (p === '/api/sync/push' && req.method === 'POST') {
    let body; try { body = JSON.parse(raw); } catch { return send(res, 400, { error: 'invalid JSON' }); }
    const myEpoch = db.prepare('SELECT epoch FROM sync_state WHERE id=1').get().epoch;
    const senderEpoch = Number(body.epoch) || 0;
    if (senderEpoch !== myEpoch) {
      // whole-batch fence: epoch mismatch means one side is stale after a takeover
      if (senderEpoch > myEpoch) setFenced(db);
      return send(res, 409, { error: 'epoch_mismatch', epoch: myEpoch });
    }
    const ops = Array.isArray(body.ops) ? body.ops.slice(0, 200) : [];
    let applied = 0, skipped = 0;
    const failed = [];
    db.exec('BEGIN IMMEDIATE');
    try {
      for (const op of ops) {
        if (!op.op_id || !op.kind || typeof op.payload !== 'string' || op.payload.length > 262144) { skipped++; continue; }
        if (String(op.node_id || '') === nodeId) { skipped++; continue; } // loop guard: own ops bounced back
        if ((Number(op.epoch) || senderEpoch) !== myEpoch) { skipped++; continue; } // per-op epoch fence
        db.exec('SAVEPOINT sync_op');
        try {
          const r = db.prepare('INSERT OR IGNORE INTO sync_ops(op_id,node_id,kind,payload,at,pushed,epoch) VALUES(?,?,?,?,?,1,?)')
            .run(op.op_id, String(op.node_id || ''), op.kind, op.payload, Number(op.at) || Date.now(), Number(op.epoch) || senderEpoch);
          if (r.changes) { applyOp(db, op); applied++; } else skipped++;
          db.exec('RELEASE sync_op');
        } catch (e) {
          db.exec('ROLLBACK TO sync_op'); db.exec('RELEASE sync_op');
          // dead-letter, do NOT wedge: receiver owns the retry; sender marks accounted
          deadletter(db, op, String(e.message || e));
          failed.push({ op_id: op.op_id, kind: op.kind, error: String(e.message || e).slice(0, 200) });
        }
      }
      db.exec('COMMIT');
    } catch (e) { db.exec('ROLLBACK'); throw e; }
    if (failed.length) console.error('sync push: dead-lettered ops', JSON.stringify(failed));
    return send(res, 200, { applied, skipped, deadlettered: failed.length, failed: failed.length });
  }
  if (p === '/api/sync/pull' && req.method === 'GET') {
    const since = Number(u.searchParams.get('since')) || 0;
    const requester = String(u.searchParams.get('node') || '');
    const st = db.prepare('SELECT role, epoch FROM sync_state WHERE id=1').get();
    const ops = db.prepare('SELECT op_id, node_id, kind, payload, at, seq, epoch FROM sync_ops WHERE seq > ? AND node_id != ? ORDER BY seq LIMIT 200')
      .all(since, requester);
    return send(res, 200, { ops, role: st.role, epoch: st.epoch, node_id: nodeId });
  }
  if (p === '/api/sync/status' && req.method === 'GET') {
    const st = db.prepare('SELECT * FROM sync_state WHERE id=1').get();
    const pending = db.prepare('SELECT COUNT(*) n FROM sync_ops WHERE node_id=? AND pushed=0').get(nodeId).n;
    const dl = db.prepare('SELECT COUNT(*) n, MAX(reason) r FROM sync_deadletter').get();
    const pairing = db.prepare("SELECT DISTINCT node_id,reason FROM sync_deadletter WHERE reason LIKE '%dependency missing: menu_items#%' OR reason LIKE '%dependency missing: categories#%' OR reason LIKE '%dependency missing: restaurant_tables#%' OR reason LIKE '%dependency missing: ingredients#%' LIMIT 20").all();
    return send(res, 200, { node_id: nodeId, role: st.role, epoch: st.epoch, fenced: !!st.fenced,
      pending_push: pending, pull_cursor: st.pull_cursor, failures: st.failures,
      deadletter: dl.n, deadletter_last_reason: dl.r,
      pairing_review_required: pairing.length > 0, pairing_dependencies: pairing,
      pairing_help: pairing.length ? 'Missing catalog/table identity mapping. Owner must compare source and target rows and preview /api/sync/pair-legacy. Never guess by equal IDs or names.' : null,
      converged: pending === 0 && dl.n === 0 });
  }
  return send(res, 404, { error: 'not found' });
}

// ---- background worker: push outbox, pull peer, retry with backoff, resume after crash ----
export function startSyncWorker(db, nodeId, log = () => {}) {
  const peer = process.env.SMARTDINE_SYNC_PEER;
  if (!peer || !syncEnabled()) return null;
  const interval = Math.max(500, Number(process.env.SMARTDINE_SYNC_INTERVAL_MS) || 5000);
  const H = { 'content-type': 'application/json', authorization: 'Bearer ' + process.env.SMARTDINE_SYNC_TOKEN };
  let busy = false;
  async function cycle() {
    if (busy) return;
    const st = db.prepare('SELECT * FROM sync_state WHERE id=1').get();
    if (Date.now() < st.next_try) return;
    busy = true;
    try {
      retryDeadletter(db, nodeId, log);
      const me = db.prepare('SELECT role, epoch FROM sync_state WHERE id=1').get();
      const ops = db.prepare('SELECT op_id,node_id,kind,payload,at,seq,epoch FROM sync_ops WHERE node_id=? AND pushed=0 ORDER BY seq LIMIT 200').all(nodeId);
      if (ops.length) {
        const r = await fetch(peer + '/api/sync/push', { method: 'POST', headers: H, body: JSON.stringify({ epoch: me.epoch, node_id: nodeId, role: me.role, ops }) });
        if (r.status === 409) {
          const j = await r.json().catch(() => ({}));
          if ((Number(j.epoch) || 0) > me.epoch) { setFenced(db); log('sync: peer is at newer epoch', j.epoch, '- this node is now FENCED (stale after takeover)'); }
          return; // epoch mismatch: never mark pushed, never pull - operator must reconcile
        }
        if (!r.ok) throw new Error('push HTTP ' + r.status);
        const j = await r.json();
        // receiver accounts every op (applied, skipped, or dead-lettered for ITS retry):
        // the sender makes progress; dead-lettered ops are NOT falsely converged -
        // they surface in /api/sync/status (deadletter count + reason) until resolved
        if ((j.applied || 0) + (j.skipped || 0) + (j.deadlettered || 0) >= ops.length) {
          db.prepare(`UPDATE sync_ops SET pushed=1 WHERE node_id=? AND seq<=?`).run(nodeId, ops[ops.length - 1].seq);
        }
      }
      const cur = db.prepare('SELECT pull_cursor FROM sync_state WHERE id=1').get().pull_cursor;
      const r2 = await fetch(`${peer}/api/sync/pull?since=${cur}&node=${nodeId}`, { headers: H });
      if (!r2.ok) throw new Error('pull HTTP ' + r2.status);
      const r2j = await r2.json();
      const remote = r2j.ops || [];
      // peer-state enforcement: newer epoch fences us; dual-primary at equal epoch demotes
      // the node with the larger node_id (deterministic single-writer resolution)
      const me2 = db.prepare('SELECT role, epoch FROM sync_state WHERE id=1').get();
      if ((Number(r2j.epoch) || 0) > me2.epoch) {
        setFenced(db);
        log('sync: peer', r2j.node_id, 'at newer epoch', r2j.epoch, '- this node is now FENCED (stale after takeover)');
        return;
      }
      if (r2j.role === 'primary' && me2.role === 'primary' && r2j.epoch === me2.epoch && String(r2j.node_id || '') > nodeId) {
        demoteToReplica(db);
        log('sync: dual primary detected with peer', r2j.node_id, '- this node demoted itself to replica (single-writer rule)');
      }
      if (remote.length) {
        let maxSeq = cur;
        db.exec('BEGIN IMMEDIATE');
        try {
          for (const op of remote) {
            if ((Number(op.epoch) || 1) !== me2.epoch) continue; // never apply stale-epoch ops
            db.exec('SAVEPOINT sync_op');
            try {
              const ins = db.prepare('INSERT OR IGNORE INTO sync_ops(op_id,node_id,kind,payload,at,pushed,epoch) VALUES(?,?,?,?,?,1,?)')
                .run(op.op_id, op.node_id, op.kind, op.payload, op.at, Number(op.epoch) || 1);
              if (ins.changes) applyOp(db, op);
              db.exec('RELEASE sync_op');
            } catch (e) {
              db.exec('ROLLBACK TO sync_op'); db.exec('RELEASE sync_op');
              deadletter(db, op, String(e.message || e));
              log('sync pull: dead-lettered op', op.kind, op.op_id, e.message);
            }
            if (op.seq > maxSeq) maxSeq = op.seq;
          }
          db.prepare('UPDATE sync_state SET pull_cursor=? WHERE id=1').run(maxSeq);
          db.exec('COMMIT');
        } catch (e) { db.exec('ROLLBACK'); throw e; }
      }
      db.prepare('UPDATE sync_state SET failures=0, next_try=0 WHERE id=1').run();
    } catch (e) {
      const f = db.prepare('SELECT failures FROM sync_state WHERE id=1').get().failures + 1;
      const backoff = Math.min(60000, 1000 * 2 ** Math.min(f, 6)); // capped exponential backoff
      db.prepare('UPDATE sync_state SET failures=?, next_try=? WHERE id=1').run(f, Date.now() + backoff);
      log('sync cycle failed:', e.message, `(retry in ${backoff}ms)`);
    } finally { busy = false; }
  }
  const t = setInterval(cycle, interval);
  t.unref();
  cycle(); // first cycle immediately
  return t;
}
