' SmartDine POS stop - terminates ONLY the SmartDine server process (the node.exe
' installed under this install's own folder); never touches other node or browser
' processes.
Option Explicit
Dim sh, base, svc, procs, p, killed
Set sh = CreateObject("WScript.Shell")
base = sh.ExpandEnvironmentStrings("%LOCALAPPDATA%") & "\SmartDine"
killed = False
Set svc = GetObject("winmgmts:root\cimv2")
Set procs = svc.ExecQuery("SELECT ProcessId, ExecutablePath, CommandLine FROM Win32_Process WHERE Name = 'node.exe'")
For Each p In procs
  If InStr(LCase(p.ExecutablePath & ""), LCase(base & "\node\node.exe")) > 0 _
     And InStr(p.CommandLine & "", "server.mjs") > 0 Then
    p.Terminate()
    killed = True
  End If
Next
If killed Then
  MsgBox "SmartDine server band kar diya gaya hai.", 64, "SmartDine POS"
Else
  MsgBox "SmartDine server abhi chal nahi raha tha.", 64, "SmartDine POS"
End If
