# appwindow-proof.ps1 - CI proof for the SmartDine app-window launcher (windows-latest).
# Proves: (1) launcher.vbs parses and selects a real Chromium --app command (log-only
# mode); (2) a REAL browser process launches in --app mode with a unique CI-owned
# profile dir; (3) cleanup terminates ONLY processes carrying that unique profile dir.
# NOT proven (impossible headless): visible window chrome, icon, title - those remain
# physical-PC items. Requires: SmartDine server already running on 127.0.0.1:8080.
param([string]$InstallDir = "$env:LOCALAPPDATA\SmartDine")
$ErrorActionPreference = 'Stop'
$log = "$InstallDir\app\data\last-launch.txt"

# 1) selection logic: run launcher in automation mode (no window, log only)
Remove-Item $log -ErrorAction SilentlyContinue
$env:SMARTDINE_NO_BROWSER = '1'
$env:SMARTDINE_LAUNCH_LOG_ONLY = '1'
$c = Start-Process cscript.exe -ArgumentList "//nologo `"$InstallDir\launcher.vbs`"" -PassThru -WindowStyle Hidden
if (-not $c.WaitForExit(60000)) { throw 'launcher selection timed out' }
if ($c.ExitCode -ne 0) { throw "launcher.vbs exited $($c.ExitCode)" }
$entry = Get-Content $log -Tail 1
if ($entry -notmatch '--app=http://127\.0\.0\.1:8080/') { throw "expected --app selection, got: $entry" }
if ($entry -notmatch 'app-window') { throw "expected app-window mode in log, got: $entry" }
$m = [regex]::Match($entry, '"([^"]+(?:msedge|chrome)\.exe)"')
if (-not $m.Success -or -not (Test-Path $m.Groups[1].Value)) { throw "no real browser path in: $entry" }
$browser = $m.Groups[1].Value

# 2) real process proof: launch the logged command shape with a UNIQUE CI profile dir
$tag = "sd-ci-" + [guid]::NewGuid().ToString('N')
$profile = Join-Path $env:TEMP $tag
$env:SMARTDINE_APP_PROFILE = $profile
Remove-Item Env:SMARTDINE_NO_BROWSER, Env:SMARTDINE_LAUNCH_LOG_ONLY -ErrorAction SilentlyContinue
$proc = Start-Process cscript.exe -ArgumentList "//nologo `"$InstallDir\launcher.vbs`"" -PassThru
if (-not $proc.WaitForExit(60000)) { throw 'real launcher timed out' }
if ($proc.ExitCode -ne 0) { throw "real launcher failed $($proc.ExitCode)" }
Start-Sleep -Seconds 4
$owned = Get-CimInstance Win32_Process -Filter "Name='msedge.exe' OR Name='chrome.exe'" |
  Where-Object { $_.CommandLine -and $_.CommandLine.Contains($tag) -and $_.CommandLine.Contains('--app=') }
if (-not $owned) { throw "no owned --app browser process found for profile $tag" }
Write-Host "OWNED-APP-PROCESS-OK pid(s): $(($owned | ForEach-Object ProcessId) -join ',') browser=$browser"

# 3) scoped cleanup: terminate ONLY processes whose command line carries our unique tag
Get-CimInstance Win32_Process -Filter "Name='msedge.exe' OR Name='chrome.exe'" | Where-Object { $_.CommandLine -and $_.CommandLine.Contains($tag) } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
Start-Sleep -Seconds 2
$left = Get-CimInstance Win32_Process -Filter "Name='msedge.exe' OR Name='chrome.exe'" |
  Where-Object { $_.CommandLine -and $_.CommandLine.Contains($tag) }
if ($left) { throw "cleanup failed: owned processes remain" }
Remove-Item $profile -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item Env:SMARTDINE_NO_BROWSER, Env:SMARTDINE_LAUNCH_LOG_ONLY, Env:SMARTDINE_APP_PROFILE -ErrorAction SilentlyContinue
Write-Host "APPWINDOW-PROOF-OK (selection argv + real owned --app process + scoped cleanup; visible chrome not provable headless)"
