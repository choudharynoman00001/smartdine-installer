; SmartDine POS - Windows installer (NSIS)
; Portable Node runtime + app, per-user install (no admin required).
!include "MUI2.nsh"

Name "SmartDine POS"
OutFile "SmartDinePOS-Setup.exe"
InstallDir "$LOCALAPPDATA\SmartDine"
RequestExecutionLevel user

!define MUI_ABORTWARNING
!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_DIRECTORY
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_PAGE_FINISH
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES
!insertmacro MUI_LANGUAGE "English"

Section "Install"
  SetOutPath "$INSTDIR"
  File /r "stage\*.*"
  ; launcher: starts the server hidden and opens the app in a dedicated app window
  ; (Chromium --app mode when Edge/Chrome is installed; default-browser fallback
  ; otherwise - browser engine either way, never claimed native)
  SetOutPath "$INSTDIR"
  File "launcher.vbs"
  File "stop.vbs"
  CreateDirectory "$SMPROGRAMS\SmartDine"
  CreateShortcut "$SMPROGRAMS\SmartDine\SmartDine POS.lnk" "$SYSDIR\wscript.exe" '"$INSTDIR\launcher.vbs"' "$INSTDIR\node\node.exe" 0
  CreateShortcut "$DESKTOP\SmartDine POS.lnk" "$SYSDIR\wscript.exe" '"$INSTDIR\launcher.vbs"' "$INSTDIR\node\node.exe" 0
  CreateShortcut "$SMPROGRAMS\SmartDine\Stop SmartDine.lnk" "$SYSDIR\wscript.exe" '"$INSTDIR\stop.vbs"' "$INSTDIR\node\node.exe" 0
  WriteUninstaller "$INSTDIR\Uninstall.exe"
SectionEnd

Section "Uninstall"
  Delete "$SMPROGRAMS\SmartDine\SmartDine POS.lnk"
  Delete "$SMPROGRAMS\SmartDine\Stop SmartDine.lnk"
  RMDir "$SMPROGRAMS\SmartDine"
  Delete "$DESKTOP\SmartDine POS.lnk"
  RMDir /r "$INSTDIR"
SectionEnd
